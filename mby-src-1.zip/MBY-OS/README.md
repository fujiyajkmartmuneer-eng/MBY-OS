# MBY OS — സുരക്ഷിതമായ ലിനക്സ് ഓപ്പറേറ്റിംഗ് സിസ്റ്റം

Debian 12 അടിസ്ഥാനമാക്കിയ, പൂർണ്ണ ഡെസ്ക്ടോപ്പ് ഉള്ള, പരമാവധി സുരക്ഷയുള്ള OS.

## ഫയലുകൾ

| ഫയൽ | എന്താണ് |
|---|---|
| `mby-harden.sh` | നിലവിലുള്ള Ubuntu/Debian-നെ MBY സുരക്ഷാ നിലയിലേക്ക് മാറ്റുന്ന സ്ക്രിപ്റ്റ് |
| `build-iso/build.sh` | ബൂട്ട് ചെയ്യാവുന്ന MBY OS ISO നിർമ്മിക്കുന്നു |
| `build-iso/packages.list` | OS-ൽ ഉള്ള എല്ലാ സോഫ്റ്റ്‌വെയറുകളും |
| `build-iso/rootfs/` | MBY തീം: വാൾപേപ്പർ, ലോഗോ, ബൂട്ട് സ്ക്രീൻ, ഡാർക്ക് മോഡ്, പ്രൈവസി സെറ്റിംഗ്സ് |

## പേരുകൾ — Windows-ലെ പോലെ

| Windows-ൽ | MBY OS-ൽ (അതേ പേര്) |
|---|---|
| Start മെനു | **Start** (Win കീ / ടാസ്ക്ബാറിലെ ⋮⋮⋮) — എല്ലാ ആപ്പുകളും |
| Search | **Search** — Win കീ അമർത്തി ടൈപ്പ് ചെയ്യുക |
| Taskbar | **ടാസ്ക്ബാർ** — താഴെ നടുവിൽ |
| Action Center / Quick Settings | **Quick Settings** — മുകളിൽ വലത് |
| Notifications | **Notifications** — മുകളിൽ നടുവിലെ ക്ലോക്ക് / Win+N |
| File Explorer | **File Explorer** |
| Task Manager | **Task Manager** (Ctrl+Shift+Esc) |
| Microsoft Store | **App Store** |
| Device Manager | **Device Manager** |
| Disk Management / Disk Cleanup / Storage | **Disk Management** / **Disk Cleanup** / **Storage (Disk Usage)** |
| System Information / Event Viewer | **System Information** / **Event Viewer** |
| System Restore / File History | **System Restore** / **Backup (File History)** |
| Windows Security / Firewall / Defender | **Security Center** / **Firewall** / **Antivirus** |
| Credential Manager | **Credential Manager** |
| Snipping Tool | **Snipping Tool (Screenshot)** |
| Notepad / Calculator / Paint-Photos | **Notepad** / **Calculator** / **Photos**, **Photo Viewer** |
| Media Player / Camera / Voice Recorder | **Media Player** / **Camera** / **Voice Recorder** |
| Alarms & Clock / People / To Do / Character Map | **Alarms & Clock** / **People** / **To Do** / **Character Map** |
| Remote Desktop Connection / Cast | **Remote Desktop Connection** / **Cast to TV** |
| Command Prompt | **Terminal (Command Prompt)** |
| Power mode | **Power Mode (Performance)** |

(Recycle Bin-ന്റെ പേര് സിസ്റ്റത്തിൽ "Trash" എന്ന് തന്നെ കാണിക്കും — അതേ ജോലി.)

## വഴി 1 — MBY OS ISO ഉണ്ടാക്കുക (പുതിയ OS)

ആവശ്യം: Debian 12 ഉള്ള കമ്പ്യൂട്ടർ അല്ലെങ്കിൽ VM, ഇന്റർനെറ്റ്, 20 GB ഫ്രീ സ്പേസ്.

```bash
cd build-iso
sudo bash build.sh
```

30–60 മിനിറ്റിനു ശേഷം `build-iso/work/MBY-OS-amd64.iso` ലഭിക്കും.
USB-യിലേക്ക് എഴുതാൻ: **balenaEtcher** അല്ലെങ്കിൽ **Rufus** (DD mode) ഉപയോഗിക്കുക.
USB-യിൽ നിന്ന് ബൂട്ട് ചെയ്ത് "Install MBY OS" → **"Encrypt system"** ടിക്ക് ചെയ്യുക.

## വഴി 1-B — Debian കമ്പ്യൂട്ടർ ഇല്ലാതെ, GitHub-ൽ ISO ഉണ്ടാക്കുക (എളുപ്പം)

1. github.com-ൽ ഒരു **Public** റിപ്പോ ഉണ്ടാക്കി ഈ `MBY-OS` ഫോൾഡർ മുഴുവൻ അപ്‌ലോഡ് ചെയ്യുക
   (`.github` ഫോൾഡർ ഉൾപ്പെടെ).
2. **Actions** ടാബ് → **Build MBY OS ISO** → **Run workflow**.
3. 1–2 മണിക്കൂറിന് ശേഷം അതേ പേജിൽ താഴെ **MBY-OS-amd64** ഡൗൺലോഡ് ചെയ്യുക (7 ദിവസം ലഭ്യം).
   പരാജയപ്പെട്ടാൽ **build-log** ഡൗൺലോഡ് ചെയ്ത് എനിക്ക് അയച്ചു തരിക — ഞാൻ ശരിയാക്കി തരാം.

(Private റിപ്പോയിൽ സൗജന്യ സ്റ്റോറേജ് പരിധി കുറവായതിനാൽ ISO അപ്‌ലോഡ് പരാജയപ്പെടാം — Public ഉപയോഗിക്കുക.)

## വഴി 2 — ഇപ്പോഴുള്ള Linux-നെ സുരക്ഷിതമാക്കുക

```bash
sudo bash mby-harden.sh              # സാധാരണ
sudo bash mby-harden.sh --firejail   # ആപ്പുകളെ sandbox-ൽ ഇടാനും
```

കഴിഞ്ഞാൽ റീബൂട്ട് ചെയ്യുക. ലോഗ്: `/var/log/mby-harden.log`. പഴയ സെറ്റിംഗ്സിന്റെ ബാക്കപ്പ്: `/var/backups/`.

## സുരക്ഷാ സംവിധാനങ്ങൾ

- **ഫുൾ ഡിസ്ക് എൻക്രിപ്ഷൻ** (LUKS2) — ലാപ്ടോപ്പ് മോഷണം പോയാലും ഡാറ്റ വായിക്കാൻ കഴിയില്ല
- **ഫയർവാൾ** — പുറത്തു നിന്നുള്ള എല്ലാ കണക്ഷനുകളും തടയുന്നു
- **AppArmor** — ഓരോ പ്രോഗ്രാമിനും അനുവദിച്ചത് മാത്രം ചെയ്യാം
- **കേർണൽ ഹാർഡനിംഗ്** — മെമ്മറി ക്ലിയറിംഗ്, kernel lockdown, exploit തടയൽ
- **ഓട്ടോമാറ്റിക് സെക്യൂരിറ്റി അപ്ഡേറ്റ്** — ദിവസവും
- **Fail2ban** — പാസ്‌വേഡ് ഊഹിച്ച് കയറാൻ ശ്രമിക്കുന്നവരെ ബ്ലോക്ക് ചെയ്യുന്നു
- **Audit log** — users, sudo, SSH മാറ്റങ്ങൾ രേഖപ്പെടുത്തുന്നു
- **ശക്തമായ പാസ്‌വേഡ് നിയമം** — കുറഞ്ഞത് 12 അക്ഷരം
- **Wi-Fi MAC randomization** — നെറ്റ്‌വർക്കുകളിൽ ട്രാക്ക് ചെയ്യാൻ കഴിയില്ല
- **Secure Boot** പിന്തുണ, core dumps ഓഫ്, USB autorun ഓഫ്
- ടൂളുകൾ: KeePassXC, Tor Browser, ClamAV, Lynis, rkhunter, Firejail

## എല്ലാം പ്രവർത്തിക്കും

GNOME ഡെസ്ക്ടോപ്പ്, Wi-Fi, Bluetooth, പ്രിന്റർ, USB, ശബ്ദം, Firefox, Thunderbird,
LibreOffice, VLC, GIMP, Flatpak ആപ്പ് സ്റ്റോർ, മലയാളം ഫോണ്ടുകൾ.

## macOS ഡിസൈനും ഫംഗ്ഷനുകളും

രൂപം: WhiteSur ലൈറ്റ് "glassy" തീം + Blur My Shell (ഫ്രോസ്റ്റഡ് ഗ്ലാസ് ഇഫക്റ്റ്, കാണുക screenshots/05-file-explorer.png), പച്ചപ്പ് വാൾപേപ്പർ (ChatGPT ഉണ്ടാക്കിയത്; ഡാർക്ക് മോഡിൽ സൂര്യാസ്തമയം), ഇടതുവശത്ത് ചുവപ്പ്/മഞ്ഞ/പച്ച വിൻഡോ ബട്ടണുകൾ, താഴെ നടുവിൽ ടാസ്ക്ബാർ,
Inter ഫോണ്ട്, natural scrolling, tap-to-click, Night Shift. Apple ലോഗോയ്ക്ക് പകരം MBY ലോഗോ.

| macOS-ൽ | MBY OS-ൽ |
|---|---|
| Finder | Files (Nautilus) |
| Search (⌘ Space) | Super കീ → ടൈപ്പ് ചെയ്യുക (ആപ്പുകൾ, ഫയലുകൾ, കാൽക്കുലേറ്റർ) |
| Start | ടാസ്ക്ബാറിലെ ആപ്പ് ഗ്രിഡ് ബട്ടൺ |
| Mission Control | Super കീ / മൂന്ന് വിരൽ സ്വൈപ്പ് |
| Quick Settings | മുകളിൽ വലതുവശത്തെ മെനു (Wi-Fi, Bluetooth, ശബ്ദം, ഡാർക്ക് മോഡ്) |
| Quick Look (Space) | Files-ൽ ഫയൽ തിരഞ്ഞെടുത്ത് Space |
| Time Machine | Backups (Déjà Dup) + Timeshift സിസ്റ്റം സ്നാപ്പ്ഷോട്ട് |
| AirDrop / iPhone link | GSConnect (Android ഫോണുമായി ഫയൽ, ക്ലിപ്ബോർഡ്, നോട്ടിഫിക്കേഷൻ) |
| App Store | Software (Debian + Flathub ആപ്പുകൾ) |
| Safari / Mail | Firefox / Thunderbird |
| Calendar, Contacts, Maps, Weather, Clock, Calculator | GNOME Calendar, Contacts, Maps, Weather, Clocks, Calculator |
| Photos / Music | Shotwell / Rhythmbox |
| Pages, Numbers, Keynote | LibreOffice Writer, Calc, Impress |
| Preview / TextEdit | Document Viewer / Text Editor |
| Keychain Access | Passwords and Keys (Seahorse) + KeePassXC |
| Activity Monitor / Disk Utility | System Monitor / Disks |
| Photo Booth / Voice Memos | Cheese / Sound Recorder |
| Screen Sharing | Connections |
| Parallels | Boxes (വെർച്വൽ മെഷീൻ) |
| iCloud Drive | Nextcloud |
| FileVault | LUKS2 ഫുൾ ഡിസ്ക് എൻക്രിപ്ഷൻ |
| Screenshot (⌘⇧5) | Print Screen കീ (സ്ക്രീൻഷോട്ട് + സ്ക്രീൻ റെക്കോർഡിംഗ്) |

### ഓഫീസ്, വീഡിയോ, ഫോട്ടോ

| ആവശ്യം | MBY OS-ലെ ആപ്പ് (ഇൻസ്റ്റാൾ ചെയ്തത്) |
|---|---|
| Word (.docx) | LibreOffice Writer |
| Excel (.xlsx) | LibreOffice Calc |
| PowerPoint (.pptx) | LibreOffice Impress |
| Access / Visio | LibreOffice Base / Draw |
| MS Office പോലെ കൂടുതൽ സാമ്യം വേണമെങ്കിൽ | Software → **OnlyOffice** (Flathub, ഒരു ക്ലിക്ക്) അല്ലെങ്കിൽ Firefox-ൽ Microsoft 365 |
| Calibri/Cambria/Arial ഫോണ്ടുകൾ | Carlito, Caladea, Liberation (അതേ വലിപ്പം — ലേഔട്ട് മാറില്ല) |
| PDF എഡിറ്റ്, ഒപ്പിടൽ, ചേർക്കൽ | PDF Arranger, Xournal++ |
| പോസ്റ്റർ / ബുക്ക് ഡിസൈൻ | Scribus |
| വീഡിയോ എഡിറ്റിംഗ് (Premiere / Final Cut പോലെ) | Kdenlive, Shotcut, OpenShot |
| സ്ക്രീൻ റെക്കോർഡിംഗ് / ലൈവ് സ്ട്രീം | OBS Studio |
| വീഡിയോ കൺവേർട്ട് | HandBrake, FFmpeg |
| ഓഡിയോ എഡിറ്റിംഗ് | Audacity |
| ഫോട്ടോ എഡിറ്റിംഗ് (Photoshop പോലെ) | GIMP, Krita |
| RAW ഫോട്ടോ (Lightroom പോലെ) | darktable, RawTherapee |
| Illustrator പോലെ (വെക്ടർ, ലോഗോ) | Inkscape |
| 3D / ആനിമേഷൻ | Blender |
| MP4, MKV, MP3 തുടങ്ങി എല്ലാ ഫോർമാറ്റും | VLC, mpv + എല്ലാ കോഡെക്കുകളും |

Windows പ്രോഗ്രാമുകൾ (.exe) വേണമെങ്കിൽ: Software → **Bottles** ഇൻസ്റ്റാൾ ചെയ്യുക.
(സുരക്ഷയ്ക്കായി ഇത് ഡിഫോൾട്ടായി ഇല്ല.)

ഇത്രയും ആപ്പുകൾ ഉള്ളതിനാൽ ISO ഏകദേശം 4–5 GB ആകും — **16 GB USB** ഉപയോഗിക്കുക.
ഇൻസ്റ്റാൾ ചെയ്യാൻ കുറഞ്ഞത് 64 GB ഡിസ്ക്, 8 GB RAM നല്ലത്.

Siri, iMessage, FaceTime, Find My എന്നിവ Apple സേവനങ്ങൾ ആയതിനാൽ ലഭ്യമല്ല;
വീഡിയോ കോളിന് Firefox-ൽ Google Meet / Zoom / WhatsApp Web ഉപയോഗിക്കാം.

## Performance — Eco / Auto / Boost (Fn + Q)

ടാസ്ക്ബാറിലെ **Performance** ആപ്പിൽ CPU താപനില കാണിക്കുന്ന ഡയലും മൂന്ന് മോഡുകളും ഉണ്ട്:

| മോഡ് | നിറം | എന്ത് ചെയ്യും |
|---|---|---|
| **Eco** | നീല | ബാറ്ററി ലാഭിക്കും, ഫാൻ ശബ്ദം കുറയും (power-saver) |
| **Auto** | പച്ച | MBY തനിയെ തീരുമാനിക്കും (താഴെ കാണുക) |
| **Boost** | ഓറഞ്ച് | മുഴുവൻ വേഗത — ഗെയിം, വീഡിയോ എഡിറ്റിംഗ് (performance) |

**Auto എങ്ങനെ പ്രവർത്തിക്കും** (ഓരോ 4 സെക്കൻഡിലും പരിശോധിക്കും):
- CPU 88°C കടന്നാൽ → ഉടൻ Eco (തണുപ്പിക്കാൻ)
- ബാറ്ററിയിൽ 25%-ൽ താഴെ → Eco
- 80°C-ന് മുകളിൽ → Balanced
- ചാർജറിൽ കുത്തി, കനത്ത ജോലി (വീഡിയോ റെൻഡർ, ഗെയിം) → **Boost**
- ബാക്കി സമയം → Balanced

**Fn + Q:** ഓരോ തവണ അമർത്തുമ്പോഴും Eco → Auto → Boost മാറും, സ്ക്രീനിൽ പോപ്പ്-അപ്പ് വരും.
- Lenovo, ASUS പോലുള്ള ലാപ്ടോപ്പുകളിൽ Fn + Q ഹാർഡ്‌വെയർ തന്നെ കൈകാര്യം ചെയ്യുന്നു — MBY അത് തനിയെ പിന്തുടരും.
- മറ്റ് ലാപ്ടോപ്പുകളിൽ (Fn കീ സോഫ്റ്റ്‌വെയറിന് കാണാൻ കഴിയില്ല) **Super + Q** അമർത്തുക.
- ടെർമിനലിൽ: `mby-power-cycle`, `mby-power-cycle boost`

മുകളിലെ ഓൺ/ഓഫ് സ്വിച്ച് Auto Boost സർവീസ് ഓഫ് ചെയ്യാനാണ്.

## Quick Settings (മുകളിൽ വലതുവശത്ത്)

മുകളിലെ ബാറിന്റെ വലതുവശത്ത് ക്ലിക്ക് ചെയ്യുമ്പോൾ ഗ്ലാസ് Quick Settings തുറക്കും (കാണുക `screenshots/08-quick-settings.png`):
- യൂസർ, Settings, Power (ഷട്ട്ഡൗൺ / റീസ്റ്റാർട്ട് / ലോക്ക്)
- Wi-Fi, Bluetooth, Phone link (GSConnect — AirDrop പോലെ)
- Do Not Disturb, Dark mode, Night shift, Performance (Eco/Auto/Boost)
- സ്ക്രീൻ ബ്രൈറ്റ്നസ്, ശബ്ദം (ഓരോ ആപ്പിനും വെവ്വേറെ വോളിയം), ഔട്ട്പുട്ട് മാറ്റൽ
- ഇപ്പോൾ പ്ലേ ചെയ്യുന്ന പാട്ട്/വീഡിയോ — Play, Next (Spotify, VLC, YouTube in Firefox...)
- Screen Mirroring: **Network Displays** ആപ്പ് വഴി TV / Miracast ഡിസ്പ്ലേയിലേക്ക് സ്ക്രീൻ
- കീബോർഡ് ലൈറ്റ്: ലാപ്ടോപ്പിലെ കീബോർഡ് ലൈറ്റ് കീകൾ (സ്ക്രീനിൽ പോപ്പ്-അപ്പ് വരും)

ഇത് GNOME-ന്റെ Quick Settings + Quick Settings Tweaks + WhiteSur + Blur My Shell ചേർന്നതാണ്;
അതുകൊണ്ട് എല്ലാം സിസ്റ്റവുമായി നേരിട്ട് പ്രവർത്തിക്കും. ലേഔട്ട് ചിത്രത്തിൽ കാണുന്നതുപോലെ
ഏകദേശം ആയിരിക്കും, ഓരോ ബോക്സിന്റെയും സ്ഥാനം അല്പം വ്യത്യാസപ്പെടാം.

## നോട്ടിഫിക്കേഷനുകൾ — സ്ക്രീനിന്റെ മുകളിൽ നടുവിൽ

- പുതിയ മെയിൽ, WhatsApp Web, കലണ്ടർ, അപ്ഡേറ്റുകൾ — എല്ലാ നോട്ടിഫിക്കേഷനും **മുകളിൽ നടുവിൽ**
  ഗ്ലാസ് ബാനറായി വരും (`screenshots/09-notification-banner.png`).
- മുകളിൽ നടുവിലെ **ക്ലോക്കിൽ ക്ലിക്ക്** ചെയ്താൽ Notifications: എല്ലാ നോട്ടിഫിക്കേഷനും + കലണ്ടർ +
  Do Not Disturb + Clear all (`screenshots/10-notifications.png`). ഷോർട്ട്കട്ട്: **Win + N**.
- **മെയിൽ:** Mail ആപ്പ് (Geary) ലോഗിൻ ചെയ്യുമ്പോൾ തന്നെ ബാക്ക്ഗ്രൗണ്ടിൽ പ്രവർത്തിക്കും — ആപ്പ് അടച്ചിരുന്നാലും
  പുതിയ മെയിൽ വന്നാൽ അറിയിക്കും. Gmail, Outlook, Yahoo, ഏത് IMAP അക്കൗണ്ടും ചേർക്കാം
  (Settings → Online Accounts). Thunderbird ഉപയോഗിക്കുന്നവർക്കും അതേ ബാനർ വരും.
- Firefox-ലെ Gmail / WhatsApp Web നോട്ടിഫിക്കേഷൻ അനുവദിച്ചാൽ അവയും ഇവിടെ തന്നെ വരും.
- സ്വകാര്യതയ്ക്കായി ലോക്ക് സ്ക്രീനിൽ മെസേജ് ഉള്ളടക്കം കാണിക്കില്ല.
- ഓരോ ആപ്പിനും നിയന്ത്രണം: Settings → Notifications.

## Chrome, Brave, Microsoft Office, PDF എഡിറ്റർ

| ആപ്പ് | വിവരം |
|---|---|
| **Google Chrome** | Google-ന്റെ ഔദ്യോഗിക റിപ്പോയിൽ നിന്ന് — ഓട്ടോമാറ്റിക്കായി അപ്ഡേറ്റ് ആകും |
| **Brave Browser** | പരസ്യവും ട്രാക്കറുകളും തടയുന്ന ബ്രൗസർ — ഓട്ടോ അപ്ഡേറ്റ് |
| Firefox | Start-ൽ ഉണ്ട് |
| **Word, Excel, PowerPoint, Outlook, OneDrive, Teams** | Microsoft 365 — സ്വന്തം വിൻഡോയിൽ തുറക്കും, Microsoft അക്കൗണ്ട് ഉപയോഗിച്ച് ലോഗിൻ ചെയ്യുക (സൗജന്യ അക്കൗണ്ടിലും അടിസ്ഥാന ഫീച്ചറുകൾ ലഭിക്കും). ഇന്റർനെറ്റ് വേണം. |
| **OnlyOffice** | ഇന്റർനെറ്റ് ഇല്ലാതെ — MS Office പോലെയുള്ള രൂപം, .docx / .xlsx / .pptx ഏറ്റവും കൃത്യമായി തുറക്കും; **PDF എഡിറ്ററും** ഇതിൽ ഉണ്ട് |
| LibreOffice | ഇതും ഉണ്ട് (ഓഫ്‌ലൈൻ) |
| **Microsoft ഫോണ്ടുകൾ** | Arial, Times New Roman, Verdana, Georgia തുടങ്ങിയവ |
| **PDF എഡിറ്റർ** | OnlyOffice PDF Editor (ടെക്സ്റ്റ്, ഫോമുകൾ), Okular (ഹൈലൈറ്റ്, കമന്റ്, ഫോം പൂരിപ്പിക്കൽ, ഡിജിറ്റൽ ഒപ്പ്), PDF Arranger (പേജ് ചേർക്കൽ/മാറ്റൽ), Xournal++ (കൈയൊപ്പ്), LibreOffice Draw (PDF ടെക്സ്റ്റ് എഡിറ്റ്) |

ശ്രദ്ധിക്കുക: Microsoft-ന്റെ ഡെസ്ക്ടോപ്പ് Office ആപ്പ് Linux-ന് Microsoft ഇറക്കിയിട്ടില്ല; അതുകൊണ്ടാണ്
Microsoft 365 വെബ് ആപ്പുകളും OnlyOffice-ഉം ചേർത്തത്. Chrome, Brave, Microsoft ഫോണ്ടുകൾ എന്നിവ
അവരുടെ ലൈസൻസ് നിബന്ധനകൾക്ക് വിധേയമാണ് — ISO സ്വന്തം ഉപയോഗത്തിന് പ്രശ്നമില്ല, പക്ഷേ പൊതുവായി
വിതരണം ചെയ്യുന്നതിന് മുമ്പ് ലൈസൻസുകൾ പരിശോധിക്കുക.

## HP പ്രിന്റർ (DeskJet GT 5810 / 5820 ഉൾപ്പെടെ)

HP-യുടെ ഔദ്യോഗിക Linux ഡ്രൈവർ **HPLIP** + സ്കാനർ ഡ്രൈവർ + driverless (IPP Everywhere) എല്ലാം ഉൾപ്പെടുത്തിയിട്ടുണ്ട്.

1. പ്രിന്റർ USB കേബിൾ വഴി കണക്റ്റ് ചെയ്ത് ഓൺ ചെയ്യുക — മിക്കവാറും **തനിയെ ആഡ് ആകും**.
2. ആയില്ലെങ്കിൽ Start → **HP Printer Setup** → പ്രിന്റർ തിരഞ്ഞെടുക്കുക → Add Printer.
   (ടെർമിനലിൽ: `mby-printer-setup`)
3. സ്കാൻ ചെയ്യാൻ: **Document Scanner** ആപ്പ്.
4. ഇങ്ക് ലെവൽ, ക്ലീനിംഗ്, അലൈൻമെന്റ്: Start → **HP Device Manager**.

സ്വന്തം മോഡൽ HPLIP പിന്തുണയ്ക്കുന്നുണ്ടോ എന്ന് developers.hp.com-ലെ "Supported Printers" ലിസ്റ്റിൽ നോക്കാം.
ചില പഴയ/വിലകുറഞ്ഞ മോഡലുകൾക്ക് HP-യുടെ അധിക പ്ലഗിൻ വേണം — HP Printer Setup അത് ചോദിച്ചാൽ "Download" അമർത്തുക.

## കൂടുതൽ സൗകര്യങ്ങൾ

| സൗകര്യം | എങ്ങനെ |
|---|---|
| **Welcome സ്ക്രീൻ** | ഇൻസ്റ്റാൾ ചെയ്ത ശേഷം ആദ്യ ലോഗിനിൽ: ഭാഷ, കീബോർഡ്, Wi-Fi, പ്രൈവസി, ഓൺലൈൻ അക്കൗണ്ടുകൾ, ഒരു ചെറിയ ടൂർ |
| **മലയാളം / അറബി ടൈപ്പിംഗ്** | **Super + Space** അമർത്തി മാറ്റുക: English → العربية → മലയാളം (Inscript) → **മലയാളം Mozhi** (Manglish: `ammaa` → അമ്മ) |
| **Security Center** | ടാസ്ക്ബാറിലെ ഷീൽഡ് ഐക്കൺ: സ്കോർ, ഓരോ സുരക്ഷയും On/Off, ഒറ്റ ക്ലിക്ക് "Repair", അപ്ഡേറ്റ് പരിശോധന |
| **ഗ്രാഫിക്സ് ഡ്രൈവർ** | Start → **Graphics Drivers** — NVIDIA കാർഡ് കണ്ടാൽ ഡ്രൈവർ തനിയെ ഇൻസ്റ്റാൾ ചെയ്യും; Intel/AMD ഡ്രൈവറുകൾ നേരത്തേ ഉണ്ട് |
| **ഗെയിമിംഗ്** | **Steam** (Windows ഗെയിമുകൾക്ക് Proton സഹിതം) + GameMode |
| **Windows പ്രോഗ്രാമുകൾ (.exe)** | **Bottles** — sandbox-ൽ സുരക്ഷിതമായി |
| **Android ആപ്പുകൾ** | Start → **Android Apps Setup** (ഒരിക്കൽ മാത്രം, ~1 GB ഡൗൺലോഡ്). NVIDIA ഗ്രാഫിക്സിൽ പ്രവർത്തിക്കില്ല. |
| **VPN** | Settings → Network → VPN: WireGuard, OpenVPN, Cisco (vpnc) |
| **പരസ്യം തടയൽ** | സിസ്റ്റം മുഴുവൻ പരസ്യം, ട്രാക്കർ, അപകടകരമായ സൈറ്റുകൾ തടയുന്നു (AdGuard DNS, എൻക്രിപ്റ്റ് ചെയ്തത്). ഓഫ് ചെയ്യാൻ: `mby-adblock off` |
| **സമയം അനുസരിച്ച് വാൾപേപ്പർ** | 7 AM–5 PM പച്ചപ്പ് (മൂന്നാർ ശൈലി), പിന്നീട് പതുക്കെ സൂര്യാസ്തമയത്തിലേക്ക് |
| **നമസ്കാര സമയം** | മുകളിലെ ബാറിൽ അടുത്ത നമസ്കാര സമയം, ഹിജ്റി തീയതി, അദാൻ നോട്ടിഫിക്കേഷൻ — ആദ്യം അതിന്റെ സെറ്റിംഗ്സിൽ നഗരം (Riyadh) തിരഞ്ഞെടുക്കുക |
| **കുട്ടികൾക്കുള്ള നിയന്ത്രണം** | Settings → Users → കുട്ടിയുടെ അക്കൗണ്ട് → **Parental Controls**: ആപ്പുകളും വെബ്സൈറ്റുകളും പരിമിതപ്പെടുത്താം |
| **അപ്ഡേറ്റുകൾ** | സുരക്ഷാ അപ്ഡേറ്റുകൾ തനിയെ; മറ്റുള്ളവ Software → Updates അല്ലെങ്കിൽ Security Center → Check for updates |
| **കാലാവസ്ഥ, ക്ലോക്ക്, കലണ്ടർ** | ക്ലോക്കിൽ ക്ലിക്ക് ചെയ്യുമ്പോഴുള്ള Notifications-ൽ (Weather ആപ്പിൽ നഗരം ചേർക്കുക) |

**ഉൾപ്പെടുത്താത്തവ:**
- ലാപ്ടോപ്പ് കണ്ടെത്തൽ (Find My) — ഇതിന് നിങ്ങളുടെ ലൊക്കേഷൻ പുറത്തുള്ള സെർവറിലേക്ക് അയക്കണം, അതിനാൽ ഡിഫോൾട്ടായി ഇല്ല.
  ഡിസ്ക് എൻക്രിപ്ഷൻ ഉള്ളതിനാൽ മോഷണം പോയാലും ഡാറ്റ സുരക്ഷിതമാണ്. വേണമെങ്കിൽ preyproject.com-ന്റെ Linux ക്ലയന്റ് ഇൻസ്റ്റാൾ ചെയ്യാം.
- ഡെസ്ക്ടോപ്പിൽ നേരിട്ടുള്ള വിഡ്ജറ്റുകൾ — ഈ GNOME പതിപ്പിൽ വിശ്വസനീയമായി പ്രവർത്തിക്കില്ല; അവയ്ക്ക് പകരം Notifications ഉപയോഗിക്കുക.

## MBY ഐക്കണുകൾ (ChatGPT ഉണ്ടാക്കിയത്)

Performance, Security Center, Graphics Drivers, HP Printer Setup — പച്ച ഗ്ലാസ് കൺസെപ്റ്റ് ഐക്കണുകൾ,
16 മുതൽ 512 പിക്സൽ വരെ എല്ലാ വലിപ്പത്തിലും (`/usr/share/icons/hicolor`). വലിയ ഒറിജിനലുകൾ:
`build-iso/icon-sources/`. പ്രിവ്യൂ: `screenshots/MBY-new-icons-dock.png`.

## ടാസ്ക്ബാറിലെ Downloads ഫോൾഡർ

ടാസ്ക്ബാറിന്റെ വലതുവശത്ത്, ട്രാഷിന് തൊട്ടടുത്ത് **Downloads**: ക്ലിക്ക് ചെയ്താൽ ഫോൾഡർ തുറക്കും;
റൈറ്റ്-ക്ലിക്ക് → **Open the newest download** (പകുതി ഡൗൺലോഡ് ആയ ഫയലുകൾ ഒഴിവാക്കും).

## ഇന്ത്യ + ബഹ്റൈൻ സമയം (World Clock)

മുകളിലെ ബാറിൽ എപ്പോഴും കാണുന്ന ചെറിയ ഗ്ലാസ് പിൽ: 🇮🇳 IST · 🇧🇭 AST. ക്ലിക്ക് ചെയ്താൽ രണ്ട് സ്ഥലത്തെയും
തീയതിയും സമയവും വലുതായി; "Open Clocks" → Clocks ആപ്പ് (അലാറം, ടൈമർ). ഇതേ രണ്ട് നഗരങ്ങൾ
Notifications-ലും (ക്ലോക്കിൽ ക്ലിക്ക്) കാണാം. മറ്റ് നഗരങ്ങൾ ചേർക്കാൻ: Clocks ആപ്പ് → World → +.

## Windows പോലുള്ള ഷോർട്ട്കട്ടുകൾ

| കീ | എന്ത് ചെയ്യും |
|---|---|
| **Win + Tab** | Task View — തുറന്ന എല്ലാ വിൻഡോകളും ഡെസ്ക്ടോപ്പുകളും (`screenshots/19-task-view.png`) |
| **Alt + Tab** | വിൻഡോകൾക്കിടയിൽ മാറുക (Windows പോലെ ഓരോ വിൻഡോയും) |
| Win (ഒറ്റയ്ക്ക്) | Search തിരയൽ / Task View |
| Win + D | ഡെസ്ക്ടോപ്പ് കാണിക്കുക |
| Win + E | Files (File Explorer) |
| Win + L | സ്ക്രീൻ ലോക്ക് |
| Win + ← / → / ↑ / ↓ | വിൻഡോ ഇടത്/വലത് പകുതി, മാക്സിമൈസ്, ചെറുതാക്കൽ |
| Win + Ctrl + ← / → | ഡെസ്ക്ടോപ്പുകൾക്കിടയിൽ മാറുക |
| Win + Shift + S / Print Screen | സ്ക്രീൻഷോട്ട് (ഏരിയ / വിൻഡോ / സ്ക്രീൻ / വീഡിയോ റെക്കോർഡ്) |
| **Win + V** | ക്ലിപ്ബോർഡ് ഹിസ്റ്ററി (കോപ്പി ചെയ്ത അവസാന 30 എണ്ണം) |
| Win + N | Notifications |
| Win + C / Calculator കീ | കാൽക്കുലേറ്റർ |
| Win + Q | Performance മോഡ് (Eco → Auto → Boost) |
| Win + Space | കീബോർഡ് ഭാഷ (English / العربية / മലയാളം) |
| Alt + F4 | വിൻഡോ അടയ്ക്കുക |

## Screenshot (ടാസ്ക്ബാറിൽ)

ടാസ്ക്ബാറിലെ **Screenshot** ബട്ടൺ → സ്ക്രീൻ / വിൻഡോ / ഏരിയ തിരഞ്ഞെടുക്കുക → ചെറിയ വിൻഡോ:
**PNG** (മികച്ച ക്വാളിറ്റി) അല്ലെങ്കിൽ **JPG** (ചെറിയ ഫയൽ, ക്വാളിറ്റി സ്ലൈഡർ) → **Save / Copy / Open folder**.
സേവ് ആകുന്നത്: Pictures/Screenshots. റൈറ്റ്-ക്ലിക്ക് → "Open the Screenshots folder".
ഏത് ചിത്രവും Files-ൽ റൈറ്റ്-ക്ലിക്ക് → **Scripts → Convert to JPG / Convert to PNG** (ഒറിജിനലിന് അടുത്ത് പുതിയ ഫയൽ).

## Windows പോലെ കീബോർഡും മൗസും

- **മൗസ് / ടച്ച്പാഡ്:** സ്ക്രോൾ ദിശ Windows പോലെ; ടച്ച്പാഡിന്റെ താഴെ വലത് മൂല = റൈറ്റ്-ക്ലിക്ക്;
  ടാപ്പ് = ക്ലിക്ക്; ടൈപ്പ് ചെയ്യുമ്പോൾ ടച്ച്പാഡ് ഓഫ്; മിഡിൽ-ക്ലിക്ക് പേസ്റ്റ് ഓഫ്; ഫയൽ ഡബിൾ-ക്ലിക്ക് ചെയ്ത് തുറക്കൽ.
- **ഡെസ്ക്ടോപ്പ്:** Home, Downloads, Trash, ഫയലുകൾ ഡെസ്ക്ടോപ്പിൽ; റൈറ്റ്-ക്ലിക്ക് → New Folder / New Document /
  Change Background / Display Settings.
- **ടൈറ്റിൽ ബാർ:** ഡബിൾ-ക്ലിക്ക് = മാക്സിമൈസ്, റൈറ്റ്-ക്ലിക്ക് = മെനു.
- **കൂടുതൽ കീകൾ:** Ctrl+Shift+Esc = Task Manager, Win+R = Run, Win+I = Settings, Win+M = ഡെസ്ക്ടോപ്പ്,
  Win+. = ഇമോജി, Ctrl+Alt+Del = ലോഗൗട്ട്/ഷട്ട്ഡൗൺ മെനു, Win+1…9 = ടാസ്ക്ബാറിലെ ആപ്പുകൾ; Num Lock എപ്പോഴും ഓൺ.

## സാധാരണ OS സൗകര്യങ്ങളുടെ പരിശോധന (53 / 53)

Windows / macOS-ൽ ഉള്ള അടിസ്ഥാന സൗകര്യങ്ങൾ എല്ലാം MBY-ൽ ഉണ്ട് — പരിശോധനാ പട്ടിക: `build-iso/feature-audit.txt`.
അവസാനം ചേർത്തവ: ക്ലിപ്ബോർഡ് ഹിസ്റ്ററി (**Win+V**), പുതിയ WinRAR (RAR5) ഫയലുകൾ, **Disk Cleanup** (BleachBit),
**System Information** (HardInfo), **Disk Usage**, **Logs**, **Characters**, **To Do** ലിസ്റ്റ്, സ്ക്രീൻ റീഡർ (Orca),
മലയാളം / അറബി സ്പെൽ ചെക്ക്.

## Private Folder (പാസ്‌വേഡ് ഉള്ള ഫോൾഡർ)

- ടാസ്ക്ബാറിലെ പച്ച പൂട്ട് ഫോൾഡർ: **Private Folder**. ആദ്യ തവണ പാസ്‌വേഡ് (കുറഞ്ഞത് 8 അക്ഷരം) സെറ്റ് ചെയ്യുക →
  ഒരു **Recovery key** കാണിക്കും — **എഴുതി സൂക്ഷിക്കുക** (പാസ്‌വേഡ് മറന്നാൽ ഇത് മാത്രമാണ് വഴി).
- പിന്നീട് ക്ലിക്ക് ചെയ്യുമ്പോൾ പാസ്‌വേഡ് ചോദിക്കും → ശരിയാണെങ്കിൽ മാത്രം തുറക്കും (`screenshots/22-private-folder.png`).
- ഫയലുകൾ **എൻക്രിപ്റ്റ്** ചെയ്താണ് സൂക്ഷിക്കുന്നത് (gocryptfs, AES-256) — ഡിസ്ക് മറ്റൊരു കമ്പ്യൂട്ടറിൽ വെച്ചാലും തുറക്കാൻ കഴിയില്ല.
- തനിയെ ലോക്ക്: 15 മിനിറ്റ് ഉപയോഗിക്കാതിരുന്നാൽ, സ്ക്രീൻ ലോക്ക് ചെയ്യുമ്പോൾ, ലോഗൗട്ട് ചെയ്യുമ്പോൾ.
  റൈറ്റ്-ക്ലിക്ക് → **Lock now** / **Change password**. 5 തവണ തെറ്റായ പാസ്‌വേഡ് → താൽക്കാലികമായി തടയും.
- തുറന്നിരിക്കുമ്പോൾ Files-ന്റെ സൈഡ്ബാറിൽ "Private Folder (unlocked)" കാണാം; ലോക്ക് ചെയ്താൽ മറയും.

## Samsung, iPhone, USB

- **Samsung / Android:** USB കേബിൾ കുത്തുക → ഫോണിൽ നോട്ടിഫിക്കേഷൻ താഴേക്ക് വലിച്ച് **USB → File transfer** →
  ഡെസ്ക്ടോപ്പിൽ ഫോണിന്റെ ഐക്കൺ വരും, Files തനിയെ തുറക്കും: DCIM (ഫോട്ടോ), Download, WhatsApp... (`screenshots/23-phones-usb.png`).
- **iPhone:** കേബിൾ കുത്തി ഫോൺ അൺലോക്ക് ചെയ്ത് **Trust** അമർത്തുക → ഫോട്ടോകളും ഫയലുകളും; HEIC ഫോട്ടോകൾ നേരിട്ട് തുറക്കും.
- **USB ഡ്രൈവ് / മെമ്മറി കാർഡ്:** ഡെസ്ക്ടോപ്പിൽ ഐക്കൺ + Files തനിയെ തുറക്കും. Windows-ൽ ഫോർമാറ്റ് ചെയ്തവയും (NTFS, exFAT, FAT32) പ്രവർത്തിക്കും.
  ഊരുന്നതിന് മുമ്പ് ⏏ (Eject) അമർത്തുക. സുരക്ഷയ്ക്കായി USB-യിലെ പ്രോഗ്രാമുകൾ തനിയെ റൺ ആകില്ല.
- വയർലെസ്സായി: GSConnect (Android) — ഫയൽ, ക്ലിപ്ബോർഡ്, നോട്ടിഫിക്കേഷൻ.

## ഫോൾഡർ ഹൈഡ് / അൺഹൈഡ്, റീനെയിം

- **ഹൈഡ്:** ഫോൾഡറിൽ/ഫയലിൽ റൈറ്റ്-ക്ലിക്ക് → **Scripts → Hide** (ഒന്നിലധികം ഒരുമിച്ചും). പേര് മാറില്ല.
- **ഹൈഡ് ചെയ്തവ കാണാൻ:** **Ctrl + H** (വീണ്ടും Ctrl + H = മറയ്ക്കുക).
- **അൺഹൈഡ്:** Ctrl + H → ഫോൾഡറിൽ റൈറ്റ്-ക്ലിക്ക് → **Scripts → Unhide**.
- **റീനെയിം:** **F2** അല്ലെങ്കിൽ റൈറ്റ്-ക്ലിക്ക് → Rename; പല ഫയലുകൾ തിരഞ്ഞെടുത്ത് F2 = ഒരുമിച്ച് പേര് മാറ്റൽ.
- ശ്രദ്ധിക്കുക: ഹൈഡ് ചെയ്യുന്നത് കാഴ്ചയിൽ നിന്ന് മറയ്ക്കൽ മാത്രമാണ് — പാസ്‌വേഡ് സംരക്ഷണം അല്ല.

## WhatsApp 1, 2, 3, 4 (നാല് നമ്പറുകൾ ഒരേ സമയം)

WhatsApp-ന് ഔദ്യോഗിക Linux ആപ്പ് ഇല്ല; അതിനാൽ WhatsApp Web-ന്റെ നാല് വെവ്വേറെ ആപ്പുകൾ — ഓരോന്നിനും
സ്വന്തം ലോഗിൻ, അതുകൊണ്ട് നാല് വ്യത്യസ്ത നമ്പറുകൾ ഒരുമിച്ച് ഉപയോഗിക്കാം (`screenshots/21-whatsapp.png`).

1. Start → **WhatsApp 1** (ഡോക്കിലും ഉണ്ട്) → QR കോഡ് വരും.
2. ഫോണിൽ WhatsApp → ⋮ / Settings → **Linked devices** → **Link a device** → QR സ്കാൻ ചെയ്യുക.
3. അടുത്ത നമ്പറിന് **WhatsApp 2**, 3, 4 — ഓരോന്നിലും അതേ പോലെ.
- ആദ്യ തവണ "Allow notifications" ചോദിച്ചാൽ **Allow** — പുതിയ മെസേജുകൾ മുകളിൽ നടുവിൽ ബാനറായി വരും
  (ആ WhatsApp വിൻഡോ തുറന്നിരിക്കണം; മിനിമൈസ് ചെയ്താൽ മതി).
- ഒരു നമ്പർ മാറ്റാൻ: ആപ്പിൽ റൈറ്റ്-ക്ലിക്ക് → **Sign out of WhatsApp N on this computer**.
- Chrome ഉപയോഗിച്ചാണ് പ്രവർത്തിക്കുന്നത് (ഇല്ലെങ്കിൽ Brave).

## ഡ്രൈവറുകൾ (Wi-Fi, Bluetooth, എല്ലാം)

- Intel, Realtek, Qualcomm-Atheros, Broadcom, MediaTek Wi-Fi/Bluetooth, Intel/AMD/NVIDIA ഗ്രാഫിക്സ്,
  സൗണ്ട്, ഫിംഗർപ്രിന്റ്, ടച്ച്‌സ്ക്രീൻ/പെൻ, iPhone/Android, ഗെയിം കൺട്രോളറുകൾ, Thunderbolt — firmware ISO-ൽ തന്നെ.
- **ആദ്യ ബൂട്ടിൽ** MBY ഹാർഡ്‌വെയർ തനിയെ കണ്ടെത്തി കുറവുള്ളവ ഇൻസ്റ്റാൾ ചെയ്യും (ഇന്റർനെറ്റ് വേണം).
- **Broadcom Wi-Fi** ഡ്രൈവർ ISO-ൽ സൂക്ഷിച്ചിട്ടുണ്ട് — ഇന്റർനെറ്റ് ഇല്ലാതെയും ഇൻസ്റ്റാൾ ആകും.
- **NVIDIA:** Start → **Device Manager** (Secure Boot ഓണാണെങ്കിൽ അടുത്ത റീസ്റ്റാർട്ടിൽ "Enroll MOK" തിരഞ്ഞെടുക്കുക).
- ഏത് ഭാഗത്തിന് ഏത് ഡ്രൈവർ: Device Manager → റൈറ്റ്-ക്ലിക്ക് → **Show my hardware**. ലോഗ്: `/var/log/mby-drivers.log`.
- BIOS / ഫേംവെയർ അപ്ഡേറ്റുകൾ: **Firmware** ആപ്പ് (നിർമ്മാതാവിൽ നിന്ന്, LVFS).
- Windows-ലെ ഡ്രൈവർ ഫയലുകൾ Linux-ൽ ഉപയോഗിക്കാൻ കഴിയില്ല; Linux-ന് സ്വന്തം ഡ്രൈവറുകൾ ഉണ്ട്.

## ആപ്പ് റിമൂവ് ചെയ്യൽ (Uninstall)

Start-ലോ ഡോക്കിലോ ആപ്പിൽ റൈറ്റ്-ക്ലിക്ക് → **Uninstall…** → ആപ്പിന്റെ പേരും വലിപ്പവും കാണിച്ച് ചോദിക്കും →
**Uninstall**. നിങ്ങളുടെ ഫയലുകൾ നഷ്ടപ്പെടില്ല. Files, Settings, ഫയർവാൾ പോലെ MBY-ക്ക് ആവശ്യമുള്ളവ
നീക്കാൻ അനുവദിക്കില്ല — അവയെ ബാധിക്കുന്ന ഏത് റിമൂവും തടയും. (Software ആപ്പ് → Installed-ലും റിമൂവ് ചെയ്യാം.)

## പുതിയ വാൾപേപ്പറുകൾ ചേർക്കൽ

- **Pictures → Wallpapers** ഫോൾഡറിൽ ഏത് ചിത്രം (JPG, PNG, WebP) ഇട്ടാലും അത് തനിയെ
  **Settings → Wallpaper** ലിസ്റ്റിൽ വരും.
- ഏത് ചിത്രത്തിലും റൈറ്റ്-ക്ലിക്ക് → **Scripts → Set as Wallpaper** (ഉടൻ വാൾപേപ്പറാകും, ഡാർക്ക് മോഡിലും
  ലോക്ക് സ്ക്രീനിലും) അല്ലെങ്കിൽ **Add to Wallpapers** (ഫോൾഡറിലേക്ക് കോപ്പി).
- Settings → Wallpaper → **Add Picture…**
- **Daily Wallpaper** (Start): ഓൺ ചെയ്താൽ എല്ലാ ദിവസവും Wallpapers ഫോൾഡറിൽ നിന്ന് പുതിയ ചിത്രം;
  റൈറ്റ്-ക്ലിക്ക് → Next wallpaper now / Turn off / Open the Wallpapers folder.

## പുതിയ ഫയലുകൾ (Windows "New" മെനു പോലെ)

Files-ൽ ഒഴിഞ്ഞ സ്ഥലത്ത് റൈറ്റ്-ക്ലിക്ക് → **New Document** → Word Document / Excel Sheet / PowerPoint /
Text File / LibreOffice Document.

## VLC Player + ടോറന്റ്

- **VLC** ടാസ്ക്ബാറിൽ; എല്ലാ വീഡിയോയും പാട്ടും (MP4, MKV, AVI, MP3, FLAC...) ഡബിൾ-ക്ലിക്ക് ചെയ്താൽ VLC-ൽ തുറക്കും.
- **qBittorrent**: `.torrent` ഫയലിൽ ഡബിൾ-ക്ലിക്ക് ചെയ്യുകയോ ബ്രൗസറിൽ magnet ലിങ്കിൽ ക്ലിക്ക് ചെയ്യുകയോ ചെയ്താൽ
  തനിയെ തുറക്കും; ഡൗൺലോഡ് ആകുന്നത് **Downloads** ഫോൾഡറിലേക്ക് (ടാസ്ക്ബാറിലെ Downloads-ൽ നിന്ന് തുറക്കാം).
- സുരക്ഷയ്ക്കായി ഫയർവാൾ പുറത്തുനിന്നുള്ള കണക്ഷനുകൾ തടയുന്നു — ഡൗൺലോഡ് പ്രവർത്തിക്കും, പക്ഷേ ചിലപ്പോൾ അല്പം
  വേഗത കുറയാം. വേഗത കൂട്ടാൻ: qBittorrent → Settings → Connection-ലെ പോർട്ട് നമ്പർ നോക്കി `sudo ufw allow <പോർട്ട്>`.

## Notepad + Google Drive

- **Notepad** (ടാസ്ക്ബാറിൽ): ലളിതമായ ടെക്സ്റ്റ് എഡിറ്റർ, എല്ലാ `.txt` ഫയലും ഇതിൽ തുറക്കും, തനിയെ സേവ് ആകും.
- **Sticky Notes**: ചെറിയ കുറിപ്പുകൾ. **Geany**: Notepad++ പോലെ ടാബുകളും കോഡ് നിറങ്ങളും.
- **Google Drive:** Start → **Connect Google Drive** → ബ്രൗസറിൽ Google-ൽ ലോഗിൻ ചെയ്യുക (ഒരിക്കൽ മാത്രം).
  അതിനുശേഷം ഹോമിലെ **Notepad** ഫോൾഡറിലെ എല്ലാ കുറിപ്പുകളും ഓരോ 2 മിനിറ്റിലും Google Drive-ലെ
  "MBY Notepad" ഫോൾഡറുമായി രണ്ട് ദിശയിലും സിങ്ക് ആകും. Save വിൻഡോയിൽ "Notepad (Google Drive)" കാണാം.
  MBY ചോദിക്കുന്നത് അത് തന്നെ ഉണ്ടാക്കുന്ന ഫയലുകളിലേക്കുള്ള ആക്സസ് മാത്രം — നിങ്ങളുടെ മുഴുവൻ Drive അല്ല.
- Settings → Online Accounts → Google ചേർത്താൽ മുഴുവൻ Google Drive-ഉം Files-ൽ കാണാം.

## ദിവസേനയുള്ള ബാക്കപ്പ് → Google Drive

| എന്ത് | എപ്പോൾ | എവിടെ |
|---|---|---|
| **സിസ്റ്റം**: എല്ലാ സെറ്റിംഗുകളും (/etc), ഇൻസ്റ്റാൾ ചെയ്ത ആപ്പുകളുടെ ലിസ്റ്റ്, MBY ടൂളുകൾ | എല്ലാ ദിവസവും 2:30 AM (ഓഫായിരുന്നാൽ അടുത്ത തവണ ഓണാക്കുമ്പോൾ) | ആദ്യം കമ്പ്യൂട്ടറിൽ, പിന്നെ Google Drive → MBY Backup/system |
| **നിങ്ങളുടെ ഫയലുകൾ**: Documents, Pictures, Notepad... | എല്ലാ ദിവസവും, എൻക്രിപ്റ്റ് ചെയ്ത്, 6 മാസം സൂക്ഷിക്കും | Google Drive → MBY Backup/files |

- ആദ്യ തവണ: **Connect Google Drive** ചെയ്യുക, പിന്നെ **Backup (File History)** ആപ്പ് തുറന്ന് **Back Up Now** അമർത്തി
  Google-ൽ ലോഗിൻ ചെയ്ത് ഒരു ബാക്കപ്പ് പാസ്‌വേഡ് സെറ്റ് ചെയ്യുക (ഇത് മറക്കരുത് — ഇല്ലെങ്കിൽ ബാക്കപ്പ് തുറക്കാൻ കഴിയില്ല).
- സുരക്ഷയ്ക്കായി പാസ്‌വേഡ് ഹാഷുകൾ, SSH കീകൾ, Wi-Fi പാസ്‌വേഡുകൾ സിസ്റ്റം ബാക്കപ്പിൽ ഉൾപ്പെടുത്തുന്നില്ല.
- **തിരികെ കൊണ്ടുവരാൻ** (പുതിയ ഇൻസ്റ്റാളിന് ശേഷം): `sudo mby-system-restore mby-system-....tar.gz` — എല്ലാ ആപ്പുകളും
  വീണ്ടും ഇൻസ്റ്റാൾ ചെയ്യും; ഫയലുകൾ Backup (File History) ആപ്പ് → Restore.
- ഇത് ഡിസ്കിന്റെ മുഴുവൻ കോപ്പി (image) അല്ല; വീണ്ടും നിർമ്മിക്കാൻ ആവശ്യമായതെല്ലാം ആണ്.

## റിമോട്ട് ഡെസ്ക്ടോപ്പ് (AnyDesk / RustDesk)

| ആപ്പ് | സ്ഥിതി |
|---|---|
| **AnyDesk** | ഇൻസ്റ്റാൾ ചെയ്തു (ഔദ്യോഗിക റിപ്പോ, ഓട്ടോ അപ്ഡേറ്റ്). സുരക്ഷയ്ക്കായി തുറക്കുമ്പോൾ മാത്രം പ്രവർത്തിക്കും. മറ്റൊരു കമ്പ്യൂട്ടർ നിയന്ത്രിക്കാൻ നേരിട്ട് ഉപയോഗിക്കാം. **ഈ** കമ്പ്യൂട്ടർ മറ്റൊരാൾ AnyDesk വഴി നിയന്ത്രിക്കണമെങ്കിൽ: ലോഗൗട്ട് ചെയ്ത് ലോഗിൻ സ്ക്രീനിലെ ഗിയർ ഐക്കണിൽ **"GNOME on Xorg"** തിരഞ്ഞെടുക്കുക. |
| **RustDesk** | ഇൻസ്റ്റാൾ ചെയ്തു — AnyDesk പോലെ തന്നെ, ഓപ്പൺ സോഴ്സ്, സാധാരണ സെഷനിൽ (Wayland) തന്നെ രണ്ട് ദിശയിലും പ്രവർത്തിക്കും. |
| UltraViewer | Linux പതിപ്പ് ഇല്ല (Windows മാത്രം) — ഇൻസ്റ്റാൾ ചെയ്യാൻ കഴിയില്ല. |
| TeamViewer | ഉൾപ്പെടുത്തിയില്ല — Wayland പിന്തുണ ഇപ്പോഴും പരീക്ഷണ ഘട്ടത്തിൽ; വേണമെങ്കിൽ teamviewer.com-ൽ നിന്ന് ചേർക്കാം. |

## ശ്രദ്ധിക്കുക

- SSH സെർവർ വേണമെങ്കിൽ: `sudo apt install openssh-server && sudo ufw allow ssh`
  (പാസ്‌വേഡ് ലോഗിൻ ഓഫ് ആണ് — SSH key ഉപയോഗിക്കുക)
- ആദ്യം ഒരു VM-ൽ (VirtualBox/QEMU) ടെസ്റ്റ് ചെയ്യുന്നത് നല്ലതാണ്.
