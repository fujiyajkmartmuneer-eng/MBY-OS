#!/bin/bash
# MBY OS - full self-test, run inside the live/installed system (as the desktop user).
# Checks: packages, MBY tools, launchers, dock, file types, extensions + JS errors,
# services/timers, network, sound, theme, flatpaks. Prints a PASS/FAIL summary.
# Result is also saved to /tmp/mby-selftest.txt
OUT=/tmp/mby-selftest.txt; : > "$OUT"
SRC=${1:-/tmp/MBY-OS/build-iso}
P=0; F=0; W=0
ok()   { P=$((P+1)); echo "PASS | $*" >> "$OUT"; }
bad()  { F=$((F+1)); echo "FAIL | $*" >> "$OUT"; }
warn() { W=$((W+1)); echo "WARN | $*" >> "$OUT"; }
t() { if eval "$2" >/dev/null 2>&1; then ok "$1"; else bad "$1"; fi; }

echo "== 1. Packages from packages.list" >> "$OUT"
if [ -f "$SRC/packages.list" ]; then
  miss=""
  for p in $(grep -v '^\s*#' "$SRC/packages.list" | awk '{print $1}' | sort -u); do
    dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q "install ok installed" || miss="$miss $p"
  done
  [ -z "$miss" ] && ok "all listed packages installed" || bad "packages missing:$miss"
else warn "packages.list not found at $SRC"; fi

echo "== 2. MBY tools" >> "$OUT"
for f in /usr/local/bin/mby-* /usr/local/sbin/mby-*; do
  [ -x "$f" ] || { bad "not executable: $f"; continue; }
  case "$(head -c 60 "$f")" in
    *python*) python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" "$f" 2>/dev/null && ok "syntax $(basename "$f")" || bad "python syntax $(basename "$f")";;
    *sh*)     bash -n "$f" 2>/dev/null && ok "syntax $(basename "$f")" || bad "shell syntax $(basename "$f")";;
    *)        ok "present $(basename "$f")";;
  esac
done

echo "== 3. App launchers (Exec program exists)" >> "$OUT"
for d in /usr/share/applications/mby-*.desktop /usr/local/share/applications/*.desktop /etc/xdg/autostart/mby-*.desktop; do
  [ -f "$d" ] || continue
  ex=$(grep -m1 '^Exec=' "$d" | sed 's/^Exec=//; s/^env [^ ]* //' | awk '{print $1}')
  [ -n "$ex" ] && command -v "$ex" >/dev/null 2>&1 && ok "launcher $(basename "$d")" || bad "launcher $(basename "$d") -> '$ex' not found"
done

echo "== 4. Dock favourites" >> "$OUT"
for a in $(gsettings get org.gnome.shell favorite-apps | tr -d "[],'"); do
  found=""
  for dir in /usr/share/applications /usr/local/share/applications /var/lib/flatpak/exports/share/applications "$HOME/.local/share/applications"; do
    [ -f "$dir/$a" ] && found=1
  done
  [ -n "$found" ] && ok "dock $a" || bad "dock icon has no app: $a"
done

echo "== 5. Default apps" >> "$OUT"
for m in application/pdf text/plain image/jpeg image/png video/mp4 audio/mpeg application/zip x-scheme-handler/http \
         application/vnd.openxmlformats-officedocument.wordprocessingml.document application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; do
  d=$(xdg-mime query default "$m" 2>/dev/null)
  if [ -n "$d" ] && { [ -f "/usr/share/applications/$d" ] || [ -f "/usr/local/share/applications/$d" ] || [ -f "/var/lib/flatpak/exports/share/applications/$d" ]; }; then ok "default $m = $d"; else bad "default app for $m ('$d')"; fi
done

echo "== 6. GNOME extensions" >> "$OUT"
for e in $(gsettings get org.gnome.shell enabled-extensions | tr -d "[],'"); do
  st=$(gnome-extensions info "$e" 2>/dev/null | awk -F': ' '/State/{print $2}')
  case "$st" in ENABLED|ACTIVE) ok "extension $e";; "") bad "extension $e not installed";; *) bad "extension $e state=$st";; esac
done
errs=$(journalctl -b --user -o cat 2>/dev/null | grep -E "JS ERROR|Extension .* had error|TypeError|ReferenceError" | sort | uniq -c | sort -rn | head -15)
errs2=$(journalctl -b -o cat _COMM=gnome-shell 2>/dev/null | grep -E "JS ERROR|had error|TypeError|ReferenceError" | sort | uniq -c | sort -rn | head -15)
all=$(printf "%s\n%s" "$errs" "$errs2" | grep -v '^\s*$')
[ -z "$all" ] && ok "no GNOME Shell JS errors this boot" || { bad "GNOME Shell errors this boot:"; echo "$all" | sed 's/^/       /' >> "$OUT"; }

echo "== 7. Services and timers" >> "$OUT"
sf=$(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}' | tr '\n' ' ')
[ -z "$sf" ] && ok "no failed system services" || bad "failed system services: $sf"
uf=$(systemctl --user --failed --no-legend --plain 2>/dev/null | awk '{print $1}' | tr '\n' ' ')
[ -z "$uf" ] && ok "no failed user services" || bad "failed user services: $uf"
for u in mby-autoboost.service mby-wallpapers.path mby-private-watch.service mby-reminders.service mby-weather-alert.timer mby-update-check.timer \
         mby-prayer-focus.service mby-day-recap.timer mby-self-heal.timer mby-rate.timer mby-stock-alert.timer mby-calendars.timer mby-findme.timer \
         mby-day-night.timer mby-eye-break.timer mby-usb-scan.path mby-photo-frame.service; do
  s=$(systemctl --user is-active "$u" 2>/dev/null); [ "$s" = active ] && ok "user $u" || bad "user $u is $s"
done
for u in mby-extras.service mby-locale-fix.service mby-vm-display.service mby-system-backup.timer mby-intruder.service mby-battery-care.service systemd-resolved.service NetworkManager.service cups.service bluetooth.service; do
  e=$(systemctl is-enabled "$u" 2>/dev/null); a=$(systemctl is-active "$u" 2>/dev/null)
  case "$a" in active) ok "system $u active";; *) if [ "$e" = enabled ] || [ "$e" = static ]; then warn "system $u enabled but $a (may be one-shot / no hardware)"; else bad "system $u $e/$a"; fi;; esac
done

echo "== 8. Network, sound, display" >> "$OUT"
t "internet (https)" "curl -fsS -m 10 -o /dev/null https://www.google.com"
t "DNS" "getent hosts debian.org"
t "sound server (PipeWire)" "pactl info"
t "dark theme set" "gsettings get org.gnome.desktop.interface color-scheme | grep -q dark"
t "MBY shell theme" "gsettings get org.gnome.shell.extensions.user-theme name | grep -q MBY"
t "MBY release file" "test -s /etc/mby-release"
t "Calamares installer" "command -v calamares"
t "Flatpak + Flathub" "flatpak remotes | grep -q flathub"
echo "   flatpaks: $(flatpak list --app --columns=application 2>/dev/null | tr '\n' ' ')" >> "$OUT"

echo "== 9. MBY quick functional checks" >> "$OUT"
t "QR maker"  "qrencode -o /tmp/mby-test-qr.png 'MBY OS'"
t "PDF tools" "command -v qpdf || command -v pdftk || command -v pdfarranger"
t "OCR (tesseract)" "command -v tesseract"
t "Archive RAR/7z" "command -v unar && command -v 7z"
t "Screenshot tool" "test -x /usr/local/bin/mby-screenshot"
t "Security Center runs" "timeout 20 python3 -c \"import ast;ast.parse(open('/usr/local/bin/mby-security-center').read())\""

{ echo; echo "RESULT: $P passed, $F failed, $W warnings   ($(cat /etc/mby-release 2>/dev/null))"; } >> "$OUT"
grep -E "^(FAIL|WARN)|^       |^RESULT" "$OUT"
