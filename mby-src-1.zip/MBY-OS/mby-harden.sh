#!/usr/bin/env bash
# =============================================================================
#  MBY OS - System Hardening Script
#  Locks down a Debian 12 / Ubuntu 22.04+ system for high security while
#  keeping desktop, Wi-Fi, printing, USB, browsers, office and media working.
#
#  Usage:   sudo bash mby-harden.sh            (on an installed system)
#           bash mby-harden.sh --chroot        (used by the ISO builder)
#  Options: --firejail   also sandbox desktop apps automatically (firecfg)
#           --no-install skip package installation
# =============================================================================
set -euo pipefail

CHROOT=0; FIREJAIL=0; INSTALL=1
for a in "$@"; do
  case "$a" in
    --chroot) CHROOT=1 ;;
    --firejail) FIREJAIL=1 ;;
    --no-install) INSTALL=0 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "Unknown option: $a"; exit 1 ;;
  esac
done

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash $0"; exit 1; }
command -v apt-get >/dev/null || { echo "Only Debian/Ubuntu (apt) systems are supported."; exit 1; }

LOG=/var/log/mby-harden.log
BACKUP=/var/backups/mby-harden-$(date +%Y%m%d-%H%M%S)
mkdir -p "$BACKUP"
if [ $CHROOT -eq 1 ]; then exec >>"$LOG" 2>&1; else exec > >(tee -a "$LOG") 2>&1; fi
export DEBIAN_FRONTEND=noninteractive

step() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
ok()   { printf '    \033[1;32m✔\033[0m %s\n' "$*"; }
backup() { for f in "$@"; do [ -e "$f" ] && cp -a --parents "$f" "$BACKUP/" || true; done; }
svc_enable() { systemctl enable "$1" >/dev/null 2>&1 || true; [ $CHROOT -eq 1 ] || systemctl restart "$1" >/dev/null 2>&1 || true; }
have() { dpkg -s "$1" >/dev/null 2>&1; }

mkdir -p /etc/sysctl.d /etc/modprobe.d /etc/security/limits.d /etc/apt/apt.conf.d /etc/default/grub.d
echo "MBY OS hardening started $(date)  (backup: $BACKUP)"

# -----------------------------------------------------------------------------
step "1/14  Packages and full system update"
PKGS=(apparmor apparmor-utils apparmor-profiles-extra
      ufw auditd fail2ban unattended-upgrades apt-listchanges needrestart
      libpam-pwquality firejail lynis rkhunter debsums cryptsetup clamav)
if [ $INSTALL -eq 1 ]; then
  apt-get update
  apt-get -y full-upgrade
  avail=()
  for p in "${PKGS[@]}"; do apt-cache show "$p" >/dev/null 2>&1 && avail+=("$p"); done
  apt-get -y install "${avail[@]}"
  ok "System updated, security tools installed"
fi

# -----------------------------------------------------------------------------
step "2/14  Automatic security updates"
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF
ok "Security patches install automatically every day"

# -----------------------------------------------------------------------------
step "3/14  Firewall (block all incoming, allow outgoing)"
if command -v ufw >/dev/null; then
  backup /etc/default/ufw /etc/ufw/ufw.conf
  ufw --force default deny incoming >/dev/null 2>&1 || sed -i 's/^DEFAULT_INPUT_POLICY=.*/DEFAULT_INPUT_POLICY="DROP"/' /etc/default/ufw
  ufw --force default allow outgoing >/dev/null 2>&1 || sed -i 's/^DEFAULT_OUTPUT_POLICY=.*/DEFAULT_OUTPUT_POLICY="ACCEPT"/' /etc/default/ufw
  ufw logging low >/dev/null 2>&1 || true
  if [ $CHROOT -eq 1 ]; then
    sed -i 's/^ENABLED=.*/ENABLED=yes/' /etc/ufw/ufw.conf
    systemctl enable ufw >/dev/null 2>&1 || true
  else
    ufw --force enable >/dev/null
  fi
  ok "Firewall on: nothing on the internet can connect in"
fi

# -----------------------------------------------------------------------------
step "4/14  Kernel hardening (sysctl)"
cat > /etc/sysctl.d/99-mby-hardening.conf <<'EOF'
# --- MBY OS kernel hardening ---
kernel.kptr_restrict = 2
kernel.dmesg_restrict = 1
kernel.printk = 3 3 3 3
kernel.unprivileged_bpf_disabled = 1
net.core.bpf_jit_harden = 2
dev.tty.ldisc_autoload = 0
vm.unprivileged_userfaultfd = 0
kernel.kexec_load_disabled = 1
kernel.sysrq = 4
kernel.perf_event_paranoid = 3
kernel.yama.ptrace_scope = 1
kernel.randomize_va_space = 2
vm.mmap_rnd_bits = 32
vm.mmap_rnd_compat_bits = 16
fs.protected_symlinks = 1
fs.protected_hardlinks = 1
fs.protected_fifos = 2
fs.protected_regular = 2
fs.suid_dumpable = 0
# --- network ---
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_rfc1337 = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.icmp_ignore_bogus_error_responses = 1
net.ipv4.conf.all.log_martians = 1
net.ipv4.conf.default.log_martians = 1
EOF
[ $CHROOT -eq 1 ] || sysctl --system >/dev/null 2>&1 || true
ok "Kernel memory, pointers and network stack locked down"

# -----------------------------------------------------------------------------
step "5/14  Kernel boot parameters"
mkdir -p /etc/default/grub.d
cat > /etc/default/grub.d/99-mby-hardening.cfg <<'EOF'
GRUB_CMDLINE_LINUX_DEFAULT="$GRUB_CMDLINE_LINUX_DEFAULT apparmor=1 security=apparmor lockdown=integrity slab_nomerge init_on_alloc=1 init_on_free=1 page_alloc.shuffle=1 pti=on randomize_kstack_offset=on vsyscall=none debugfs=off"
EOF
if [ $CHROOT -eq 0 ] && command -v update-grub >/dev/null; then update-grub >/dev/null 2>&1 || true; fi
ok "Memory wiping, kernel lockdown and exploit mitigations at boot"

# -----------------------------------------------------------------------------
step "6/14  Block rarely-used, risky kernel modules"
cat > /etc/modprobe.d/mby-blacklist.conf <<'EOF'
# Obscure network protocols (frequent source of kernel exploits)
install dccp /bin/false
install sctp /bin/false
install rds /bin/false
install tipc /bin/false
install n-hdlc /bin/false
install ax25 /bin/false
install netrom /bin/false
install x25 /bin/false
install rose /bin/false
install decnet /bin/false
install econet /bin/false
install af_802154 /bin/false
install ipx /bin/false
install appletalk /bin/false
install psnap /bin/false
install p8023 /bin/false
install p8022 /bin/false
install atm /bin/false
# Rare filesystems
install cramfs /bin/false
install freevxfs /bin/false
install jffs2 /bin/false
# FireWire (DMA attacks)
install firewire-core /bin/false
install firewire-ohci /bin/false
EOF
ok "Unused protocols and FireWire DMA blocked (USB, Wi-Fi, Bluetooth still work)"

# -----------------------------------------------------------------------------
step "7/14  AppArmor mandatory access control"
if [ -d /etc/apparmor.d ]; then
  # Keep each profile in the mode Debian ships it (enforce where tested, complain
  # where enforcing could break apps) - forcing all to enforce breaks programs.
  svc_enable apparmor
  ok "AppArmor active with Debian's tested profiles"
fi

# -----------------------------------------------------------------------------
step "8/14  Disable core dumps"
cat > /etc/security/limits.d/99-mby-nocore.conf <<'EOF'
*    hard    core    0
EOF
mkdir -p /etc/systemd/coredump.conf.d
printf '[Coredump]\nStorage=none\nProcessSizeMax=0\n' > /etc/systemd/coredump.conf.d/99-mby.conf
ok "Crash dumps can no longer leak passwords from memory"

# -----------------------------------------------------------------------------
step "9/14  Strong passwords and login protection"
if [ -f /etc/security/pwquality.conf ]; then
  backup /etc/security/pwquality.conf
  mkdir -p /etc/security/pwquality.conf.d
  cat > /etc/security/pwquality.conf.d/99-mby.conf <<'EOF'
minlen = 12
minclass = 3
maxrepeat = 3
dictcheck = 1
usercheck = 1
enforce_for_root
EOF
fi
backup /etc/login.defs
sed -i -E 's/^#?\s*ENCRYPT_METHOD.*/ENCRYPT_METHOD YESCRYPT/' /etc/login.defs || true
if command -v fail2ban-client >/dev/null; then
  mkdir -p /etc/fail2ban/jail.d
  cat > /etc/fail2ban/jail.d/mby.local <<'EOF'
[DEFAULT]
bantime  = 1h
findtime = 10m
maxretry = 5
backend  = systemd
[sshd]
enabled = true
EOF
  svc_enable fail2ban
fi
ok "Passwords: min 12 chars, 3 character types; brute-force attackers banned"

# -----------------------------------------------------------------------------
step "10/14  SSH hardening (only if SSH server is installed)"
if [ -d /etc/ssh/sshd_config.d ] && have openssh-server; then
  cat > /etc/ssh/sshd_config.d/99-mby.conf <<'EOF'
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
LoginGraceTime 30
X11Forwarding no
AllowAgentForwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
EOF
  ok "SSH: keys only, no root login (allow it in firewall with: sudo ufw allow ssh)"
else
  ok "No SSH server - nothing to expose"
fi

# -----------------------------------------------------------------------------
step "11/14  Security audit logging"
if [ -d /etc/audit ]; then
  mkdir -p /etc/audit/rules.d
  cat > /etc/audit/rules.d/99-mby.rules <<'EOF'
-w /etc/passwd -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/group -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/sudoers -p wa -k sudoers
-w /etc/sudoers.d/ -p wa -k sudoers
-w /etc/ssh/sshd_config -p wa -k sshd
-w /etc/apparmor.d/ -p wa -k apparmor
-a always,exit -F arch=b64 -S init_module,finit_module,delete_module -k modules
-a always,exit -F arch=b64 -S adjtimex,settimeofday,clock_settime -k time
EOF
  svc_enable auditd
  ok "Changes to users, sudo, SSH and kernel modules are recorded"
fi

# -----------------------------------------------------------------------------
step "12/14  Privacy: random Wi-Fi MAC address"
if [ -d /etc/NetworkManager ]; then
  mkdir -p /etc/NetworkManager/conf.d
  cat > /etc/NetworkManager/conf.d/00-mby-macrandomize.conf <<'EOF'
[device]
wifi.scan-rand-mac-address=yes
[connection]
wifi.cloned-mac-address=stable
ethernet.cloned-mac-address=stable
connection.stable-id=${CONNECTION}/${BOOT}
EOF
  ok "Your device can't be tracked across Wi-Fi networks"
fi

# -----------------------------------------------------------------------------
step "13/14  Reduce attack surface"
for s in cups-browsed.service; do
  systemctl disable "$s" >/dev/null 2>&1 || true
  [ $CHROOT -eq 1 ] || systemctl stop "$s" >/dev/null 2>&1 || true
done
chmod 700 /root
chmod 600 /etc/crontab 2>/dev/null || true
chmod 700 /etc/cron.d /etc/cron.daily /etc/cron.hourly /etc/cron.weekly /etc/cron.monthly 2>/dev/null || true
if [ $FIREJAIL -eq 1 ] && command -v firecfg >/dev/null; then
  firecfg >/dev/null 2>&1 || true
  ok "Desktop apps sandboxed with Firejail"
fi
ok "Remote printer auto-discovery off (normal printing works)"

# -----------------------------------------------------------------------------
step "14/14  Security audit"
if [ $CHROOT -eq 0 ] && command -v lynis >/dev/null; then
  lynis audit system --quick --no-colors > /var/log/mby-lynis.log 2>&1 || true
  score=$(grep -oP 'Hardening index : \K[0-9]+' /var/log/mby-lynis.log || echo "?")
  ok "Lynis hardening score: $score / 100  (details: /var/log/mby-lynis.log)"
fi

printf '\n\033[1;32m MBY OS hardening complete.\033[0m Reboot to apply all kernel settings.\n'
printf ' Log: %s   Backups: %s\n' "$LOG" "$BACKUP"
