#!/usr/bin/env bash
# =============================================================================
#  MBY OS - ISO builder
#  Builds a bootable, installable MBY OS live ISO (Debian 12 "bookworm" base,
#  GNOME desktop, MBY theme, full hardening, encrypted-disk installer).
#
#  Requirements: a Debian 12 machine (or VM) with internet, ~20 GB free disk.
#  Usage:        sudo bash build.sh
#  Output:       ./work/MBY-OS-amd64.iso
# =============================================================================
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash $0"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/work"

apt-get update
apt-get -y install live-build

rm -rf "$WORK"; mkdir -p "$WORK"; cd "$WORK"

lb config \
  --distribution bookworm \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --debian-installer none \
  --security true --updates true \
  --binary-images iso-hybrid \
  --chroot-squashfs-compression-type xz \
  --bootloaders "grub-efi,syslinux" \
  --iso-application "MBY OS" \
  --iso-volume "MBY_OS" \
  --iso-publisher "MBY OS Project" \
  --bootappend-live "boot=live components quiet splash hostname=mby username=mby apparmor=1 security=apparmor lockdown=integrity slab_nomerge init_on_alloc=1 init_on_free=1 page_alloc.shuffle=1 pti=on randomize_kstack_offset=on vsyscall=none debugfs=off"

# --- third-party apt repos (keyrings prepared here, packages installed by hook 0050)
apt-get -y install curl gnupg git unzip >/dev/null
INC=config/includes.chroot
mkdir -p "$INC/etc/apt/keyrings" "$INC/etc/apt/sources.list.d" "$INC/opt"
curl -fsSL https://dl.google.com/linux/linux_signing_key.pub | gpg --dearmor > "$INC/etc/apt/keyrings/google-chrome.gpg"
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/google-chrome.gpg] https://dl.google.com/linux/chrome/deb/ stable main" > "$INC/etc/apt/sources.list.d/google-chrome.list"
curl -fsSL https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg -o "$INC/etc/apt/keyrings/brave-browser.gpg"
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/brave-browser.gpg] https://brave-browser-apt-release.s3.brave.com/ stable main" > "$INC/etc/apt/sources.list.d/brave-browser.list"
GNUPGHOME=$(mktemp -d); export GNUPGHOME
gpg --no-default-keyring --keyring "gnupg-ring:$GNUPGHOME/onlyoffice.gpg" --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys CB2DE8E5
install -m644 "$GNUPGHOME/onlyoffice.gpg" "$INC/etc/apt/keyrings/onlyoffice.gpg"
unset GNUPGHOME
echo "deb [signed-by=/etc/apt/keyrings/onlyoffice.gpg] https://download.onlyoffice.com/repo/debian squeeze main" > "$INC/etc/apt/sources.list.d/onlyoffice.list"
curl -fsSL https://repo.waydro.id/waydroid.gpg -o "$INC/etc/apt/keyrings/waydroid.gpg"
echo "deb [signed-by=/etc/apt/keyrings/waydroid.gpg] https://repo.waydro.id/ bookworm main" > "$INC/etc/apt/sources.list.d/waydroid.list"
# AnyDesk (remote desktop) - official repository
curl -fsSL https://keys.anydesk.com/repos/DEB-GPG-KEY | gpg --dearmor > "$INC/etc/apt/keyrings/anydesk.gpg"
echo "deb [signed-by=/etc/apt/keyrings/anydesk.gpg] https://deb.anydesk.com all main" > "$INC/etc/apt/sources.list.d/anydesk.list"
chmod 644 "$INC"/etc/apt/keyrings/*.gpg

# --- package list: installed by hook 0050, which skips (and logs) any package
#     that is not available instead of failing the whole build
cp "$HERE/packages.list" "$INC/opt/mby-packages.list"

# --- files copied into the OS -----------------------------------------------
cp -a "$HERE/rootfs/." config/includes.chroot/
install -Dm755 "$HERE/../mby-harden.sh" config/includes.chroot/usr/local/sbin/mby-harden

# --- macOS-style look: WhiteSur GTK/shell theme, icons, cursors (MIT/GPL) ----
# Pin these refs to a release tag you have reviewed for a reproducible build.
WS_REF="${WS_REF:-master}"
SRC=config/includes.chroot/opt/mby-src; mkdir -p "$SRC"
for r in WhiteSur-gtk-theme WhiteSur-icon-theme WhiteSur-cursors; do
  git clone --depth 1 --branch "$WS_REF" "https://github.com/vinceliuice/$r.git" "$SRC/$r"
  rm -rf "$SRC/$r/.git"
done
# Blur My Shell: real frosted-glass blur on panel, dock, overview and app windows
EXT=config/includes.chroot/usr/share/gnome-shell/extensions/blur-my-shell@aunetx
mkdir -p "$EXT"
curl -fsSL -o /tmp/bms.zip "https://extensions.gnome.org/download-extension/blur-my-shell@aunetx.shell-extension.zip?shell_version=43" \
  && unzip -oq /tmp/bms.zip -d "$EXT" || { echo "WARN: blur-my-shell not downloaded"; rm -rf "$EXT"; }
# Quick Settings Tweaks: macOS-style Control Center extras - now-playing media
# controls, Do Not Disturb toggle, per-app volume mixer inside Quick Settings
QST=config/includes.chroot/usr/share/gnome-shell/extensions/quick-settings-tweaks@qwreey
mkdir -p "$QST"
curl -fsSL -o /tmp/qst.zip "https://extensions.gnome.org/download-extension/quick-settings-tweaks@qwreey.shell-extension.zip?shell_version=43" \
  && unzip -oq /tmp/qst.zip -d "$QST" || { echo "WARN: quick-settings-tweaks not downloaded"; rm -rf "$QST"; }
# Clipboard history (Win+V, like Windows)
CB=config/includes.chroot/usr/share/gnome-shell/extensions/clipboard-indicator@tudmotu.com
if curl -fsSL -o /tmp/cb.zip "https://extensions.gnome.org/download-extension/clipboard-indicator@tudmotu.com.shell-extension.zip?shell_version=43"; then
  mkdir -p "$CB" && unzip -oq /tmp/cb.zip -d "$CB" || rm -rf "$CB"
fi
# Prayer times + Hijri date + Adhan notification in the top bar (optional, skipped if unavailable)
AZ=config/includes.chroot/usr/share/gnome-shell/extensions/azan@hatem.masmoudi.org
if curl -fsSL -o /tmp/azan.zip "https://extensions.gnome.org/download-extension/azan@hatem.masmoudi.org.shell-extension.zip?shell_version=43"; then
  mkdir -p "$AZ" && unzip -oq /tmp/azan.zip -d "$AZ" || rm -rf "$AZ"
fi

# --- build-time hooks -------------------------------------------------------
mkdir -p config/hooks/normal
cat > config/hooks/normal/0050-mby-packages.hook.chroot <<'HOOK'
#!/bin/sh
set -e
export DEBIAN_FRONTEND=noninteractive
echo "ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true" | debconf-set-selections
apt-get update
OK=""; MISSING=""
for p in $(grep -v '^[[:space:]]*#' /opt/mby-packages.list | awk 'NF{print $1}' | sort -u); do
  if apt-cache show "$p" >/dev/null 2>&1; then OK="$OK $p"; else MISSING="$MISSING $p"; fi
done
echo "MBY: packages not available (skipped):$MISSING" | tee /var/log/mby-missing-packages.log
APT="apt-get install -y -o Dpkg::Options::=--force-confold"
if ! $APT $OK; then
  echo "MBY: bulk install failed - installing one by one"
  for p in $OK; do $APT "$p" || echo "$p" >> /var/log/mby-failed-packages.log; done
fi
rm -f /opt/mby-packages.list
HOOK
cat > config/hooks/normal/0060-mby-offline-drivers.hook.chroot <<'HOOK'
#!/bin/sh
# Keep the Broadcom Wi-Fi driver (wl) on the ISO so it can be installed with no internet.
mkdir -p /opt/mby-offline && cd /opt/mby-offline
apt-get download broadcom-sta-dkms 2>/dev/null || true
ls -la /opt/mby-offline
HOOK
cat > config/hooks/normal/0100-mby-harden.hook.chroot <<'EOF'
#!/bin/sh
set -e
/usr/local/sbin/mby-harden --chroot --no-install
EOF
cat > config/hooks/normal/0200-mby-theme.hook.chroot <<'EOF'
#!/bin/sh
set -e
# macOS-style theme (no Apple logos or trademarks are installed)
cd /opt/mby-src/WhiteSur-gtk-theme && ./install.sh -c light -c dark -o normal -t default -N glassy --round || ./install.sh -c light -c dark -t default -N glassy || true
cd /opt/mby-src/WhiteSur-icon-theme && ./install.sh -t default || true
cd /opt/mby-src/WhiteSur-cursors && ./install.sh || true
cd / && rm -rf /opt/mby-src
# Flathub in the Software store: OnlyOffice, DaVinci-style editors, Spotify, Zoom, etc.
flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo || true
# Gaming (Steam + Proton) and Windows programs (.exe) via Bottles - sandboxed Flatpaks
flatpak install --system -y --noninteractive flathub com.valvesoftware.Steam com.usebottles.bottles || true
# RustDesk: open-source remote desktop that works on Wayland (sandboxed Flatpak)
flatpak install --system -y --noninteractive flathub com.rustdesk.RustDesk || true
# AnyDesk: do not listen at boot - it starts only when you open it (smaller attack surface)
systemctl disable anydesk.service 2>/dev/null || true
dconf update || true
cp /usr/share/gnome-shell/extensions/*/schemas/*.gschema.xml /usr/share/glib-2.0/schemas/ 2>/dev/null || true
glib-compile-schemas /usr/share/glib-2.0/schemas || true
gtk-update-icon-cache -f -t /usr/share/icons/hicolor || true
# Windows-style app names (File Explorer, Task Manager, App Store...)
/usr/local/sbin/mby-windows-names || true
# MBY Auto Boost user service for every user
systemctl --global enable mby-autoboost.service || true
systemctl --global enable mby-wallpapers.path || true
systemctl --global enable mby-private-watch.service || true
# Daily system backup (root) and the user-side Google Drive jobs are enabled after sign-in
systemctl enable mby-system-backup.timer || true
systemctl enable mby-firstboot-drivers.service || true
# Ad-blocking DNS resolver - installed last, because it takes over /etc/resolv.conf
DEBIAN_FRONTEND=noninteractive apt-get install -y systemd-resolved || true
systemctl enable systemd-resolved || true
# live-build puts resolv.conf.orig back at the end: make that the resolved stub link
if [ -L /etc/resolv.conf ]; then cp -P /etc/resolv.conf /etc/resolv.conf.orig; fi
# Branding (os-release kept as Debian for package compatibility)
printf 'MBY OS - secure by design \\n \\l\n\n' > /etc/issue
printf '\n  MBY OS  |  Firewall ON  |  AppArmor ON  |  Auto security updates ON\n\n' > /etc/motd
# Plymouth boot splash
if [ -d /usr/share/plymouth/themes/spinner ]; then
  # reuse spinner's password-prompt & throbber images (needed for the disk-unlock screen)
  for f in /usr/share/plymouth/themes/spinner/*.png; do
    case "$(basename "$f")" in watermark.png|background*.png) continue ;; esac
    cp -n "$f" /usr/share/plymouth/themes/mby/ || true
  done
fi
if command -v plymouth-set-default-theme >/dev/null; then
  plymouth-set-default-theme -R mby || true
fi
EOF
chmod +x config/hooks/normal/*.hook.chroot

lb build 2>&1 | tee build.log
ISO=$(ls -1 *.iso 2>/dev/null | head -n1 || true)
if [ -n "$ISO" ]; then
  mv "$ISO" MBY-OS-amd64.iso
  sha256sum MBY-OS-amd64.iso > MBY-OS-amd64.iso.sha256
  echo; echo "Done: $WORK/MBY-OS-amd64.iso"
else
  echo "Build failed - see $WORK/build.log"; exit 1
fi
