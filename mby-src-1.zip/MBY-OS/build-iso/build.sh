#!/usr/bin/env bash
# =============================================================================
#  MBY OS - ISO builder
#  Builds a bootable, installable MBY OS live ISO (Debian 12 "bookworm" base,
#  GNOME desktop, MBY theme, full hardening, encrypted-disk installer).
#
#  Requirements: a Debian 12 machine (or VM) with internet, ~20 GB free disk.
#  Usage:        sudo bash build.sh
#  Output:       ./work/MBY-OS-amd64.iso
# =============================================================================
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash $0"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/work"

apt-get update
apt-get -y install live-build

rm -rf "$WORK"; mkdir -p "$WORK"; cd "$WORK"

lb config \
  --distribution bookworm \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --debian-installer none \
  --security true --updates true \
  --binary-images iso-hybrid \
  --chroot-squashfs-compression-type xz \
  --bootloaders "grub-efi,syslinux" \
  --iso-application "MBY OS" \
  --iso-volume "MBY_OS" \
  --iso-publisher "MBY OS Project" \
  --bootappend-live "boot=live components quiet splash hostname=mby username=mby timezone=Asia/Bahrain apparmor=1 security=apparmor lockdown=integrity slab_nomerge init_on_alloc=1 init_on_free=1 page_alloc.shuffle=1 pti=on randomize_kstack_offset=on vsyscall=none debugfs=off"

# --- Packages the installer (Calamares bootloader-config) installs from the ISO's own pool, offline.
# Without these, "Install MBY OS" failed in build #7: "Package grub-efi-amd64 is not available".
mkdir -p config/package-lists
cat > config/package-lists/mby-installer.list.binary <<'PKGS'
grub-efi-amd64
grub-efi-amd64-bin
grub-efi-amd64-signed
shim-signed
shim-helpers-amd64-signed
grub-pc-bin
grub-common
grub2-common
efibootmgr
os-prober
mokutil
PKGS

# --- MBY boot menu branding (GRUB + ISOLINUX): MBY logo splash, "MBY OS" titles
if [ -d /usr/share/live/build/bootloaders ]; then
  cp -a /usr/share/live/build/bootloaders config/
  B64=$(base64 -w0 "$HERE/boot-branding/splash.png")
  for f in $(find config/bootloaders -name 'splash.svg*'); do
    printf '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1024" height="768"><image width="1024" height="768" xlink:href="data:image/png;base64,%s"/></svg>\n' "$B64" > "$f"
  done
  for f in $(find config/bootloaders -name 'splash.png'); do cp "$HERE/boot-branding/splash.png" "$f"; done
  for f in $(find config/bootloaders -name 'splash*.png' -path '*syslinux*'); do cp "$HERE/boot-branding/splash-640.png" "$f"; done
  find config/bootloaders -type f \( -name '*.cfg' -o -name '*.txt' -o -name '*.in' \) -exec sed -i \
    -e 's/Debian GNU\/Linux/MBY OS/g' -e 's/Live system/Try MBY OS (Live)/g' \
    -e 's/fail-safe mode/safe graphics/g' {} +
  # live-theme colours: MBY green highlight
  find config/bootloaders -name 'theme.txt' -exec sed -i -e 's/selected_item_color = .*/selected_item_color = "#2dd4bf"/' {} +
fi

# --- third-party apt repos (keyrings prepared here, packages installed by hook 0050)
apt-get -y install curl gnupg git unzip >/dev/null
INC=config/includes.chroot
mkdir -p "$INC/etc/apt/keyrings" "$INC/etc/apt/sources.list.d" "$INC/opt"
curl -fsSL https://dl.google.com/linux/linux_signing_key.pub | gpg --dearmor > "$INC/etc/apt/keyrings/google-chrome.gpg"
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/google-chrome.gpg] https://dl.google.com/linux/chrome/deb/ stable main" > "$INC/etc/apt/sources.list.d/google-chrome.list"
curl -fsSL https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg -o "$INC/etc/apt/keyrings/brave-browser.gpg"
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/brave-browser.gpg] https://brave-browser-apt-release.s3.brave.com/ stable main" > "$INC/etc/apt/sources.list.d/brave-browser.list"
GNUPGHOME=$(mktemp -d); export GNUPGHOME
gpg --no-default-keyring --keyring "gnupg-ring:$GNUPGHOME/onlyoffice.gpg" --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys CB2DE8E5
install -m644 "$GNUPGHOME/onlyoffice.gpg" "$INC/etc/apt/keyrings/onlyoffice.gpg"
unset GNUPGHOME
echo "deb [signed-by=/etc/apt/keyrings/onlyoffice.gpg] https://download.onlyoffice.com/repo/debian squeeze main" > "$INC/etc/apt/sources.list.d/onlyoffice.list"
curl -fsSL https://repo.waydro.id/waydroid.gpg -o "$INC/etc/apt/keyrings/waydroid.gpg"
echo "deb [signed-by=/etc/apt/keyrings/waydroid.gpg] https://repo.waydro.id/ bookworm main" > "$INC/etc/apt/sources.list.d/waydroid.list"
# AnyDesk (remote desktop) - official repository
curl -fsSL https://keys.anydesk.com/repos/DEB-GPG-KEY | gpg --dearmor > "$INC/etc/apt/keyrings/anydesk.gpg"
echo "deb [signed-by=/etc/apt/keyrings/anydesk.gpg] https://deb.anydesk.com all main" > "$INC/etc/apt/sources.list.d/anydesk.list"
chmod 644 "$INC"/etc/apt/keyrings/*.gpg

# --- package list: installed by hook 0050, which skips (and logs) any package
#     that is not available instead of failing the whole build
cp "$HERE/packages.list" "$INC/opt/mby-packages.list"

# --- files copied into the OS -----------------------------------------------
cp -a "$HERE/rootfs/." config/includes.chroot/
install -Dm755 "$HERE/../mby-harden.sh" config/includes.chroot/usr/local/sbin/mby-harden

# --- macOS-style look: WhiteSur GTK/shell theme, icons, cursors (MIT/GPL) ----
# Pin these refs to a release tag you have reviewed for a reproducible build.
WS_REF="${WS_REF:-master}"
SRC=config/includes.chroot/opt/mby-src; mkdir -p "$SRC"
for r in WhiteSur-gtk-theme WhiteSur-icon-theme WhiteSur-cursors; do
  git clone --depth 1 --branch "$WS_REF" "https://github.com/vinceliuice/$r.git" "$SRC/$r"
  rm -rf "$SRC/$r/.git"
done
# Blur My Shell: real frosted-glass blur on panel, dock, overview and app windows
EXT=config/includes.chroot/usr/share/gnome-shell/extensions/blur-my-shell@aunetx
mkdir -p "$EXT"
curl -fsSL -o /tmp/bms.zip "https://extensions.gnome.org/download-extension/blur-my-shell@aunetx.shell-extension.zip?shell_version=43" \
  && unzip -oq /tmp/bms.zip -d "$EXT" || { echo "WARN: blur-my-shell not downloaded"; rm -rf "$EXT"; }
# Quick Settings Tweaks: macOS-style Control Center extras - now-playing media
# controls, Do Not Disturb toggle, per-app volume mixer inside Quick Settings
QST=config/includes.chroot/usr/share/gnome-shell/extensions/quick-settings-tweaks@qwreey
mkdir -p "$QST"
curl -fsSL -o /tmp/qst.zip "https://extensions.gnome.org/download-extension/quick-settings-tweaks@qwreey.shell-extension.zip?shell_version=43" \
  && unzip -oq /tmp/qst.zip -d "$QST" || { echo "WARN: quick-settings-tweaks not downloaded"; rm -rf "$QST"; }
# Clipboard history (Win+V, like Windows)
CB=config/includes.chroot/usr/share/gnome-shell/extensions/clipboard-indicator@tudmotu.com
if curl -fsSL -o /tmp/cb.zip "https://extensions.gnome.org/download-extension/clipboard-indicator@tudmotu.com.shell-extension.zip?shell_version=43"; then
  mkdir -p "$CB" && unzip -oq /tmp/cb.zip -d "$CB" || rm -rf "$CB"
fi
# Prayer times + Hijri date + Adhan notification in the top bar (optional, skipped if unavailable)
AZ=config/includes.chroot/usr/share/gnome-shell/extensions/azan@hatem.masmoudi.org
if curl -fsSL -o /tmp/azan.zip "https://extensions.gnome.org/download-extension/azan@hatem.masmoudi.org.shell-extension.zip?shell_version=43"; then
  mkdir -p "$AZ" && unzip -oq /tmp/azan.zip -d "$AZ" || rm -rf "$AZ"
fi

# --- build-time hooks -------------------------------------------------------
mkdir -p config/hooks/normal
cat > config/hooks/normal/0050-mby-packages.hook.chroot <<'HOOK'
#!/bin/sh
set -e
export DEBIAN_FRONTEND=noninteractive
echo "ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true" | debconf-set-selections
apt-get update
OK=""; MISSING=""
for p in $(grep -v '^[[:space:]]*#' /opt/mby-packages.list | awk 'NF{print $1}' | sort -u); do
  # must have a real install candidate (apt-cache show also matches names other packages only mention)
  if apt-cache policy "$p" 2>/dev/null | grep -q 'Candidate: [^(]'; then OK="$OK $p"; else MISSING="$MISSING $p"; fi
done
echo "MBY: packages not available (skipped):$MISSING" | tee /var/log/mby-missing-packages.log
APT="apt-get install -y -o Dpkg::Options::=--force-confold"
if ! $APT $OK; then
  echo "MBY: bulk install failed - installing one by one"
  for p in $OK; do $APT "$p" || echo "$p" >> /var/log/mby-failed-packages.log; done
fi
rm -f /opt/mby-packages.list
HOOK
cat > config/hooks/normal/0055-mby-hp-backports.hook.chroot <<'HOOK'
#!/bin/sh
# Newer HP driver (HPLIP) for the Smart Tank 580-590 series, if Debian backports has one.
# Never fails the build: without it the printer still works driverless (IPP Everywhere).
echo "deb http://deb.debian.org/debian bookworm-backports main contrib non-free non-free-firmware" > /etc/apt/sources.list.d/bookworm-backports.list
apt-get update || true
BP=$(apt-cache policy hplip | awk '/bookworm-backports/{getline; print}' | head -n1)
echo "MBY: hplip backports candidate: ${BP:-none}"
DEBIAN_FRONTEND=noninteractive apt-get install -y -t bookworm-backports hplip hplip-data printer-driver-hpcups libsane-hpaio 2>/dev/null \
  && echo "MBY: hplip from backports installed" || echo "MBY: hplip backports not available - driverless printing is used"
dpkg -l hplip | tail -n1 || true
HOOK
cat > config/hooks/normal/0060-mby-offline-drivers.hook.chroot <<'HOOK'
#!/bin/sh
# Keep the Broadcom Wi-Fi driver (wl) on the ISO so it can be installed with no internet.
mkdir -p /opt/mby-offline && cd /opt/mby-offline
apt-get download broadcom-sta-dkms 2>/dev/null || true
ls -la /opt/mby-offline
HOOK
cat > config/hooks/normal/0100-mby-harden.hook.chroot <<'EOF'
#!/bin/sh
set -e
/usr/local/sbin/mby-harden --chroot --no-install
EOF
cat > config/hooks/normal/0200-mby-theme.hook.chroot <<'EOF'
#!/bin/sh
set -e
# macOS-style theme (no Apple logos or trademarks are installed)
# WhiteSur GTK: every attempt is logged (it failed silently up to build #9)
if [ -d /opt/mby-src/WhiteSur-gtk-theme ]; then
  cd /opt/mby-src/WhiteSur-gtk-theme
  for args in "-c light -c dark -t default orange -N glassy" "-c light -c dark -t default -N glassy" "-c light -c dark"; do
    if bash ./install.sh $args > /var/log/mby-whitesur.log 2>&1; then echo "WhiteSur GTK installed ($args)"; break; fi
    echo "WhiteSur GTK failed ($args):"; tail -15 /var/log/mby-whitesur.log
  done
  cd /
else
  echo "WARN: /opt/mby-src/WhiteSur-gtk-theme missing (git clone failed?)"
fi
ls -d /usr/share/themes/WhiteSur* 2>/dev/null || echo "no WhiteSur themes in /usr/share/themes"
cd /opt/mby-src/WhiteSur-icon-theme && ./install.sh -t default || true
cd /opt/mby-src/WhiteSur-cursors && ./install.sh || true
cd / && rm -rf /opt/mby-src
# MBY Charcoal Copper: a copy of WhiteSur Dark (orange accent if built) with the copper overrides appended
BASE=""
for c in /usr/share/themes/WhiteSur-Dark-orange /usr/share/themes/WhiteSur-Dark-solid-orange /usr/share/themes/WhiteSur-Dark /usr/share/themes/WhiteSur-Dark-solid; do
  [ -d "$c/gtk-3.0" ] && { BASE="$c"; break; }
done
[ -z "$BASE" ] && BASE=$(ls -d /usr/share/themes/WhiteSur-Dark* 2>/dev/null | head -1)
if [ -n "$BASE" ]; then
  rm -rf /usr/share/themes/MBY-Copper; cp -a "$BASE" /usr/share/themes/MBY-Copper
  sed -i 's/^Name=.*/Name=MBY-Copper/' /usr/share/themes/MBY-Copper/index.theme 2>/dev/null || true
  for f in /usr/share/themes/MBY-Copper/gtk-3.0/gtk.css /usr/share/themes/MBY-Copper/gtk-3.0/gtk-dark.css; do
    [ -f "$f" ] && cat /usr/share/mby-theme/copper/gtk3-overrides.css >> "$f"
  done
  [ -f /usr/share/themes/MBY-Copper/gnome-shell/gnome-shell.css ] && cat /usr/share/mby-theme/copper/shell-overrides.css >> /usr/share/themes/MBY-Copper/gnome-shell/gnome-shell.css
  echo "MBY-Copper theme built from $BASE"
else
  echo "WARN: no WhiteSur Dark theme - MBY-Copper falls back to Adwaita-dark"
  mkdir -p /usr/share/themes/MBY-Copper/gtk-3.0 /usr/share/themes/MBY-Copper/gnome-shell
  printf '[Desktop Entry]\nType=X-GNOME-Metatheme\nName=MBY-Copper\n' > /usr/share/themes/MBY-Copper/index.theme
  { echo '@import url("resource:///org/gtk/libgtk/theme/Adwaita/gtk-contained-dark.css");'; cat /usr/share/mby-theme/copper/gtk3-overrides.css; } > /usr/share/themes/MBY-Copper/gtk-3.0/gtk.css
  { echo '@import url("resource:///org/gnome/shell/theme/gnome-shell.css");'; cat /usr/share/mby-theme/copper/shell-overrides.css; } > /usr/share/themes/MBY-Copper/gnome-shell/gnome-shell.css
fi
gtk-update-icon-cache -f -t /usr/share/icons/MBY-Copper-Glass 2>/dev/null || true
# Flathub in the Software store: OnlyOffice, DaVinci-style editors, Spotify, Zoom, etc.
flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo || true
# Gaming (Steam + Proton) and Windows programs (.exe) via Bottles - sandboxed Flatpaks
flatpak install --system -y --noninteractive flathub com.valvesoftware.Steam com.usebottles.bottles || true
# RustDesk: open-source remote desktop that works on Wayland (sandboxed Flatpak)
flatpak install --system -y --noninteractive flathub com.rustdesk.RustDesk || true
# Offline maps: download Bahrain / Kerala once, navigate without internet
flatpak install --system -y --noninteractive flathub app.organicmaps.desktop || true
# Music (Spotify) and a screen recorder with sound (Kooha)
flatpak install --system -y --noninteractive flathub com.spotify.Client io.github.seadve.Kooha || true
# AnyDesk: do not listen at boot - it starts only when you open it (smaller attack surface)
systemctl disable anydesk.service 2>/dev/null || true
# Nextcloud stays in the app grid but does not open its sign-in window at every login
rm -f /etc/xdg/autostart/*nextcloud*.desktop /etc/xdg/autostart/*Nextcloud*.desktop
# only one "Weather" in the app grid: MBY Weather (the stock GNOME Weather stays installed but hidden)
for f in /usr/share/applications/org.gnome.Weather.desktop; do
  [ -f "$f" ] && { sed -i '/^NoDisplay=/d' "$f"; sed -i '0,/^\[Desktop Entry\]/s//[Desktop Entry]\nNoDisplay=true/' "$f"; }
done
dconf update || true
cp /usr/share/gnome-shell/extensions/*/schemas/*.gschema.xml /usr/share/glib-2.0/schemas/ 2>/dev/null || true
glib-compile-schemas /usr/share/glib-2.0/schemas || true
for d in /usr/share/gnome-shell/extensions/*/schemas; do [ -d "$d" ] && glib-compile-schemas "$d" || true; done
# GSConnect is the phone link: KDE Connect (pulled in as a dependency) must not start too - both use port 1716
for f in /etc/xdg/autostart/org.kde.kdeconnect.daemon.desktop /etc/xdg/autostart/kdeconnectd.desktop; do
  [ -f "$f" ] && { grep -q '^Hidden=true' "$f" || echo 'Hidden=true' >> "$f"; }
done
gtk-update-icon-cache -f -t /usr/share/icons/hicolor || true
# Windows-style app names (File Explorer, Task Manager, App Store...)
/usr/local/sbin/mby-windows-names || true
# MBY Auto Boost user service for every user
systemctl enable mby-vm-display.service || true
systemctl --global enable mby-autoboost.service || true
systemctl --global enable mby-wallpapers.path || true
systemctl --global enable mby-private-watch.service || true
systemctl --global enable mby-reminders.service || true
systemctl --global enable mby-weather-alert.timer || true
systemctl --global enable mby-prayer-focus.service mby-day-recap.timer mby-self-heal.timer mby-rate.timer mby-stock-alert.timer mby-calendars.timer mby-findme.timer mby-day-night.timer mby-eye-break.timer mby-usb-scan.path mby-photo-frame.service || true
# Default time zone Bahrain (the live system was showing UTC); the installer can still change it
ln -sf /usr/share/zoneinfo/Asia/Bahrain /etc/localtime; echo Asia/Bahrain > /etc/timezone
# Daily system backup (root) and the user-side Google Drive jobs are enabled after sign-in
systemctl enable mby-system-backup.timer || true
systemctl enable mby-intruder.service || true
systemctl enable mby-firstboot-drivers.service || true
# Ad-blocking DNS resolver - installed last, because it takes over /etc/resolv.conf
DEBIAN_FRONTEND=noninteractive apt-get install -y systemd-resolved || true
systemctl enable systemd-resolved || true
# live-build puts resolv.conf.orig back at the end: make that the resolved stub link
if [ -L /etc/resolv.conf ]; then cp -P /etc/resolv.conf /etc/resolv.conf.orig; fi
# ---- MBY OS branding -------------------------------------------------------
# os-release: ID stays "debian" (apt, drivers and installers rely on it); the
# name shown everywhere (Settings > About, GRUB, installer, login) is MBY OS.
sed -i -e 's/^PRETTY_NAME=.*/PRETTY_NAME="MBY OS 1.0 (based on Debian 12)"/' \
       -e 's/^NAME=.*/NAME="MBY OS"/' /usr/lib/os-release
grep -q '^LOGO=' /usr/lib/os-release || echo 'LOGO=mby-os' >> /usr/lib/os-release
mkdir -p /etc/default/grub.d
cat > /etc/default/grub.d/mby.cfg <<'GRUBCFG'
GRUB_DISTRIBUTOR="MBY OS"
GRUBCFG
# GNOME login screen + Settings > About show the MBY logo
mkdir -p /etc/dconf/db/gdm.d
printf "[org/gnome/login-screen]\nlogo='/usr/share/pixmaps/mby-logo.png'\n" > /etc/dconf/db/gdm.d/01-mby-logo
dconf update || true
# Installer (Calamares): MBY branding + "Install MBY OS" launcher
if [ -f /etc/calamares/settings.conf ]; then
  sed -i 's/^branding:.*/branding: mby/' /etc/calamares/settings.conf
fi
for f in /usr/share/applications/install-debian.desktop /usr/share/applications/calamares.desktop; do
  [ -f "$f" ] || continue
  dpkg-divert --local --rename --add "$f" || true
done
# Installer location page starts at Bahrain (it opened on New York in build #10)
mkdir -p /etc/calamares/modules
cat > /etc/calamares/modules/locale.conf <<'CONF'
---
region: "Asia"
zone: "Bahrain"
localeGenPath: "/etc/locale.gen"
CONF
# Installed system: MBY boot-menu background instead of Debian's (Calamares keeps /etc/default/grub)
if [ -f /etc/default/grub ]; then
  sed -i '/^GRUB_BACKGROUND=/d' /etc/default/grub
  echo 'GRUB_BACKGROUND="/usr/share/mby-theme/copper/grub.png"' >> /etc/default/grub
  sed -i 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="MBY OS"/' /etc/default/grub
fi
# Installer: remove the live-only packages we really have; packages that may be absent are "try_remove"
# (Debian's default list failed in build #10 with apt error 100 - live-task-* / live-tools are not in MBY OS)
mkdir -p /etc/calamares/modules
cat > /etc/calamares/modules/packages.conf <<'CONF'
---
backend: apt
update_db: false
update_system: false
operations:
  - try_remove: [ live-boot ]
  - try_remove: [ live-boot-doc ]
  - try_remove: [ live-boot-initramfs-tools ]
  - try_remove: [ live-config ]
  - try_remove: [ live-config-doc ]
  - try_remove: [ live-config-systemd ]
  - try_remove: [ live-tools ]
  - try_remove: [ live-task-localisation ]
  - try_remove: [ live-task-recommended ]
  - try_remove: [ calamares-settings-debian ]
  - try_remove: [ calamares ]
CONF
# Debian's own desktop-icon helper is replaced by mby-live-installer-icon (autostart)
[ -x /usr/bin/add-calamares-desktop-icon ] && dpkg-divert --local --rename --add /usr/bin/add-calamares-desktop-icon || true
rm -f /etc/xdg/autostart/calamares-desktop-icon.desktop
# (old) Branding notes
printf 'MBY OS - secure by design \\n \\l\n\n' > /etc/issue
printf '\n  MBY OS  |  Firewall ON  |  AppArmor ON  |  Auto security updates ON\n\n' > /etc/motd
# Plymouth boot splash
if [ -d /usr/share/plymouth/themes/spinner ]; then
  # reuse spinner's password-prompt & throbber images (needed for the disk-unlock screen)
  for f in /usr/share/plymouth/themes/spinner/*.png; do
    case "$(basename "$f")" in watermark.png|background*.png) continue ;; esac
    cp -n "$f" /usr/share/plymouth/themes/mby/ || true
  done
fi
# any Debian theme that might still be picked shows the MBY logo too
for t in spinner bgrt; do
  [ -d /usr/share/plymouth/themes/$t ] && cp /usr/share/plymouth/themes/mby/watermark.png /usr/share/plymouth/themes/$t/watermark.png || true
done
[ -f /usr/share/desktop-base/debian-logos/logo-text.svg ] && true
# every Debian logo picture (the "debian 12" splash text comes from desktop-base logos) becomes the MBY logo
for f in $(find /usr/share/desktop-base /usr/share/plymouth \( -iname '*debian*.png' -o -iname 'logo*.png' -o -iname '*-logo*.png' \) 2>/dev/null) $(find /usr/share/pixmaps -iname '*debian*.png' 2>/dev/null); do
  case "$f" in /usr/share/plymouth/themes/mby/*) continue ;; esac
  rm -f "$f"; cp /usr/share/plymouth/themes/mby/watermark.png "$f" || true
done
rm -f /usr/share/plymouth/debian-logo.png; cp /usr/share/plymouth/themes/mby/watermark.png /usr/share/plymouth/debian-logo.png
echo "splash logo check:"; ls -l /usr/share/plymouth/debian-logo.png; md5sum /usr/share/plymouth/themes/mby/watermark.png /usr/share/plymouth/debian-logo.png
for f in /usr/share/plymouth/debian-logo.png $(find /usr/share/plymouth /usr/share/desktop-base -name 'debian-logo*.png' -o -name 'watermark.png' 2>/dev/null); do
  [ "$f" = /usr/share/plymouth/themes/mby/watermark.png ] && continue
  [ -e "$f" ] && cp -f --remove-destination /usr/share/plymouth/themes/mby/watermark.png "$f" || true
done
# only the MBY splash is registered - Debian's emerald splash showed "debian 12" in build #7
update-alternatives --remove-all default.plymouth 2>/dev/null || true
rm -f /usr/share/plymouth/themes/default.plymouth
for f in $(find /usr/share/plymouth/themes /usr/share/desktop-base -path '*plymouth*' \( -iname '*debian*.png' -o -iname '*logo*.png' \) 2>/dev/null); do
  case "$f" in /usr/share/plymouth/themes/mby/*) continue ;; esac
  cp -f --remove-destination /usr/share/plymouth/themes/mby/watermark.png "$f" || true
done
update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth /usr/share/plymouth/themes/mby/mby.plymouth 300 2>/dev/null || true
update-alternatives --set default.plymouth /usr/share/plymouth/themes/mby/mby.plymouth 2>/dev/null || true
mkdir -p /etc/plymouth
printf '[Daemon]\nTheme=mby\nShowDelay=0\n' > /etc/plymouth/plymouthd.conf
if command -v plymouth-set-default-theme >/dev/null; then
  plymouth-set-default-theme mby || true
fi
# only MBY (plus plain text fallbacks) may draw the boot splash - Debian's emerald splash kept appearing
for d in /usr/share/plymouth/themes/*/; do
  case "$(basename "$d")" in mby|details|text|tribar) ;; *) echo "removing splash theme $d"; rm -rf "$d" ;; esac
done
rm -rf /usr/share/desktop-base/*/plymouth 2>/dev/null || true
update-alternatives --set default.plymouth /usr/share/plymouth/themes/mby/mby.plymouth 2>/dev/null || true
plymouth-set-default-theme mby 2>/dev/null || true
# the installer applies the splash theme to the installed system too
mkdir -p /etc/calamares/modules
printf -- '---\nplymouth_theme: mby\n' > /etc/calamares/modules/plymouthcfg.conf
echo "plymouth theme: $(plymouth-set-default-theme 2>/dev/null)"
update-initramfs -u -k all || true
# diagnostics: which splash files really went into the boot image
for i in /boot/initrd.img-*; do echo "== $i"; lsinitramfs "$i" 2>/dev/null | grep -i -E "plymouth|debian|emerald|desktop-base" | grep -v -E "animation-|throbber-" ; done
cat /etc/plymouth/plymouthd.conf; readlink -f /usr/share/plymouth/themes/default.plymouth; ls /usr/share/plymouth/themes
# Mail (Geary) must not open by itself at login
for f in /etc/xdg/autostart/geary-autostart.desktop /etc/xdg/autostart/org.gnome.Geary*.desktop; do
  [ -f "$f" ] && { grep -q '^Hidden=' "$f" || echo 'Hidden=true' >> "$f"; } || true
done
EOF
cat > config/hooks/normal/9000-mby-boot-menu.hook.binary <<'EOF'
#!/bin/sh
# Rename the boot menu entries (generated by live-build) to MBY OS names
for f in $(find boot isolinux -name '*.cfg' 2>/dev/null); do
  sed -i -e 's/Live system (\([a-z0-9]*\) fail-safe mode)/Try MBY OS - safe graphics/' \
         -e 's/Live system (\([a-z0-9]*\))/Try or install MBY OS/' \
         -e 's/Live system/MBY OS/g' -e 's/Debian GNU\/Linux/MBY OS/g' "$f"
done
grep -rh "menuentry\|label" boot/grub/grub.cfg 2>/dev/null | head -5 || true
EOF
chmod +x config/hooks/normal/*.hook.binary
chmod +x config/hooks/normal/*.hook.chroot

lb build 2>&1 | tee build.log
ISO=$(ls -1 *.iso 2>/dev/null | head -n1 || true)
if [ -n "$ISO" ]; then
  mv "$ISO" MBY-OS-amd64.iso
  sha256sum MBY-OS-amd64.iso > MBY-OS-amd64.iso.sha256
  echo; echo "Done: $WORK/MBY-OS-amd64.iso"
else
  echo "Build failed - see $WORK/build.log"; exit 1
fi
