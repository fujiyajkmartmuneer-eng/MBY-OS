"""MBY OS kit - full automated check."""
import configparser, glob, json, os, re, subprocess, sys, tempfile
ROOT = "/home/claude/MBY-OS"; B = f"{ROOT}/build-iso"; R = f"{B}/rootfs"
ok = fail = 0
def res(good, what, detail=""):
    global ok, fail
    if good: ok += 1
    else: fail += 1; print(f"  FAIL  {what} {detail}")
def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)

print("1. Shell scripts (syntax)")
shells = [f"{ROOT}/mby-harden.sh", f"{B}/build.sh"] + [f for f in [x for x in glob.glob(f"{R}/usr/local/*bin/*") if os.path.isfile(x)] + glob.glob(f"{R}/lib/live/config/*")
          + glob.glob(f"{R}/etc/skel/.local/share/nautilus/scripts/**", recursive=True) if __import__("os").path.isfile(f) and open(f, errors="ignore").read(2).startswith("#!") and "python" not in open(f).readline()]
for f in shells:
    sh = "bash" if "bash" in open(f).readline() else "sh"
    r = run([sh, "-n", f]); res(r.returncode == 0, os.path.basename(f), r.stderr)
# hooks embedded in build.sh
text = open(f"{B}/build.sh").read()
hooks = re.findall(r"cat > (config/hooks/normal/[^ ]+) <<'(\w+)'\n(.*?)\n\2\n", text, re.S)
for name, _, body in hooks:
    with tempfile.NamedTemporaryFile("w", suffix=".sh", delete=False) as t: t.write(body)
    r = run(["sh", "-n", t.name]); res(r.returncode == 0, "hook " + os.path.basename(name), r.stderr)
print(f"   {len(shells)} scripts + {len(hooks)} build hooks")

print("2. Python apps (compile)")
pys = [f for f in glob.glob(f"{R}/usr/local/bin/*") if os.path.isfile(f) and "python" in open(f).readline()]
for f in pys:
    r = run([sys.executable, "-c", "import py_compile,sys; py_compile.compile(sys.argv[1], cfile='/tmp/mbycheck.pyc', doraise=True)", f]); res(r.returncode == 0, os.path.basename(f), r.stderr)
print(f"   {len(pys)} apps")

print("3. GNOME extension (JavaScript, metadata)")
for e in glob.glob(f"{R}/usr/share/gnome-shell/extensions/*/"):
    if os.path.exists(e + "extension.js"):
        r = run(["node", "--check", e + "extension.js"]); res(r.returncode == 0, e, r.stderr)
        m = json.load(open(e + "metadata.json")); res(m["uuid"] == os.path.basename(e.rstrip("/")), "uuid matches folder " + m["uuid"])

print("4. Desktop launchers: keys, programs, icons")
pk = {l.split()[0] for l in open(f"{B}/packages.list") if l.strip() and not l.lstrip().startswith("#")}
own_bins = {os.path.basename(p) for p in glob.glob(f"{R}/usr/local/*bin/*") if os.path.isfile(p)}
bin_from_pkg = {"gedit": "gedit", "gnome-system-monitor": "gnome-system-monitor", "gnome-text-editor": "gnome-text-editor", "geary": "geary", "hp-setup": "hplip-gui", "malcontent-control": "malcontent-gui", "xournalpp": "xournalpp", "gnome-terminal": "task-gnome-desktop",
                "google-chrome-stable": "google-chrome-stable", "sh": "base"}
own_icons = {os.path.splitext(os.path.basename(p))[0] for p in glob.glob(f"{R}/usr/share/icons/hicolor/*/apps/*")}
std_icons = {"preferences-desktop-wallpaper", "video-display", "accessories-text-editor", "folder-download", "x-office-document", "x-office-spreadsheet", "x-office-presentation",
             "internet-mail", "folder-remote", "call-start", "phone", "printer", "anydesk", "org.gnome.TextEditor"}
desk = glob.glob(f"{R}/usr/share/applications/*.desktop") + glob.glob(f"{R}/usr/local/share/applications/*.desktop") + glob.glob(f"{R}/etc/xdg/autostart/*.desktop")
for f in desk:
    c = configparser.RawConfigParser(strict=True, interpolation=None); c.optionxform = str; c.read(f)
    d = c["Desktop Entry"]; n = os.path.basename(f)
    res(all(k in d for k in ("Name", "Exec", "Type")), n, "missing Name/Exec/Type")
    prog = os.path.basename(d["Exec"].split()[0])
    res(prog in own_bins or prog in bin_from_pkg, n, f"program '{prog}' not provided")
    if "Icon" in d: res(d["Icon"] in own_icons or d["Icon"] in std_icons, n, f"icon '{d['Icon']}' unknown")
    for a in [s for s in c.sections() if s.startswith("Desktop Action")]:
        p2 = os.path.basename(c[a]["Exec"].split()[0]); res(p2 in own_bins or p2 in bin_from_pkg, n + " " + a, f"'{p2}'")
print(f"   {len(desk)} launchers")

print("5. Dock favourites point to real apps")
dconf = configparser.RawConfigParser(strict=True); dconf.optionxform = str; dconf.read(f"{R}/etc/dconf/db/local.d/00-mby")
fav = re.findall(r"'([^']+)'", dconf["org/gnome/shell"]["favorite-apps"])
pkg_desktop = {"org.gnome.Nautilus.desktop": "task-gnome-desktop", "google-chrome.desktop": "google-chrome-stable", "brave-browser.desktop": "brave-browser",
  "org.gnome.Geary.desktop": "geary", "org.gnome.Calendar.desktop": "gnome-calendar", "onlyoffice-desktopeditors.desktop": "onlyoffice-desktopeditors",
  "org.gnome.Shotwell.desktop": "shotwell", "vlc.desktop": "vlc", "org.gnome.Rhythmbox3.desktop": "rhythmbox", "org.gnome.Software.desktop": "gnome-software",
  "org.gnome.Settings.desktop": "task-gnome-desktop", "org.gnome.Terminal.desktop": "task-gnome-desktop"}
mine = {os.path.basename(p) for p in desk}
for a in fav:
    res(a in mine or (a in pkg_desktop and (pkg_desktop[a] in pk)), "dock: " + a)
print(f"   {len(fav)} dock icons: " + ", ".join(x.replace('.desktop', '') for x in fav))

print("6. Default apps")
c = configparser.RawConfigParser(strict=True); c.optionxform = str; c.read(f"{R}/etc/xdg/mimeapps.list")
known = mine | {"vlc.desktop", "org.qbittorrent.qBittorrent.desktop"} | ({"libreoffice-calc.desktop", "libreoffice-writer.desktop", "libreoffice-impress.desktop"} if "libreoffice-calc" in pk else set())
for k, v in c["Default Applications"].items(): res(v in known, "mime " + k, v)
print(f"   {len(c['Default Applications'])} file types")

print("7. GNOME settings against real schemas")
env = dict(os.environ, GSETTINGS_BACKEND="memory")
schemas = set(run(["gsettings", "list-schemas"], env=env).stdout.split()); checked = 0
for sec in dconf.sections():
    sid = sec.replace("/", ".")
    if sid in schemas:
        keys = set(run(["gsettings", "list-keys", sid], env=env).stdout.split())
        for k, v in dconf[sec].items():
            if k not in keys: res(False, sid, "unknown key " + k); continue
            r = run(["gsettings", "set", sid, k, v], env=env); res(r.returncode == 0, f"{sid} {k}", r.stderr); checked += 1
print(f"   {checked} values validated ({len(dconf.sections())} sections)")
shortcuts = {}
for sec in dconf.sections():
    for k, v in dconf[sec].items():
        if "keybindings" in sec or sec.endswith("media-keys") or k == "binding":
            for key in re.findall(r"'([^']+)'", v):
                if key.startswith("<") or key in ("Print", "Calculator"): shortcuts.setdefault(key, []).append(k)
dups = {k: v for k, v in shortcuts.items() if len(v) > 1}; res(not dups, "duplicate shortcuts", str(dups))

print("8. systemd units, XML, JSON")
for f in glob.glob(f"{R}/usr/lib/systemd/*/*"):
    c = configparser.RawConfigParser(strict=True, interpolation=None); c.optionxform = str; c.read(f)
    res("Unit" in c and ("Service" in c or "Timer" in c or "Path" in c), os.path.basename(f))
    if "Timer" in c: res(os.path.exists(f[:-6] + ".service"), os.path.basename(f), "has no matching .service")
import xml.dom.minidom as M
for f in glob.glob(f"{R}/**/*.xml", recursive=True) + glob.glob(f"{R}/**/*.svg", recursive=True): M.parse(f); res(True, f)
print("9. Package list")
lines = [l.split()[0] for l in open(f"{B}/packages.list") if l.strip() and not l.lstrip().startswith("#")]
dup = sorted({x for x in lines if lines.count(x) > 1}); print(f"   {len(set(lines))} packages; listed twice (harmless): {', '.join(dup) or 'none'}")
print(f"\nRESULT: {ok} checks passed, {fail} failed")
