#!/bin/bash
# MBY Update: one-time steps for a computer that is already installed (run as root by mby-update-apply).
# The ISO build does these in build.sh; an installed system gets them here.

# Claude desktop app (official Anthropic apt repository, key checked against the published fingerprint)
CK=/usr/share/keyrings/claude-desktop-archive-keyring.asc
if [ ! -f /etc/apt/sources.list.d/claude-desktop.list ]; then
  T=$(mktemp)
  if curl -fsSL -m 60 -o "$T" https://downloads.claude.ai/claude-desktop/key.asc \
     && gpg --show-keys --with-colons "$T" 2>/dev/null | grep -q '^fpr:::::::::31DDDE24DDFAB679F42D7BD2BAA929FF1A7ECACE:'; then
    install -m644 "$T" "$CK"
    echo "deb [arch=amd64,arm64 signed-by=$CK] https://downloads.claude.ai/claude-desktop/apt/stable stable main" \
      > /etc/apt/sources.list.d/claude-desktop.list
    echo "claude repository added"
  fi
  rm -f "$T"
fi

# Claude Cowork needs the kvm group for the person who ran the update
if [ -n "${PKEXEC_UID:-}" ]; then
  U=$(getent passwd "$PKEXEC_UID" | cut -d: -f1)
  [ -n "$U" ] && getent group kvm >/dev/null && usermod -aG kvm "$U"
fi

# animated boot splash: make the MBY theme active and rebuild the boot image when it changed
if [ -f /usr/share/plymouth/themes/mby/mby.script ] && command -v plymouth-set-default-theme >/dev/null; then
  if [ "$(plymouth-set-default-theme 2>/dev/null)" != mby ] || \
     [ /usr/share/plymouth/themes/mby/mby.script -nt /boot/initrd.img-"$(uname -r)" ]; then
    plymouth-set-default-theme mby && update-initramfs -u >/dev/null 2>&1 && echo "boot splash updated"
  fi
fi

# LibreOffice opens without the splash logo
for f in /etc/libreoffice/sofficerc; do
  [ -f "$f" ] || continue
  if grep -q '^Logo=' "$f"; then sed -i 's/^Logo=.*/Logo=0/' "$f"; else sed -i '/^\[Bootstrap\]/a Logo=0' "$f"; fi
done

# desktop right-click "Refresh"
for f in /usr/share/gnome-shell/extensions/ding@rastersoft.com/desktopManager.js \
         /usr/share/gnome-shell/extensions/ding@rastersoft.com/app/desktopManager.js; do
  [ -f "$f" ] || continue
  grep -q mbyRefresh "$f" && continue
  sed -i "/let selectAll = new Gtk.MenuItem/i\\        let mbyRefresh = new Gtk.MenuItem({label: _('Refresh')});\n        mbyRefresh.connect('activate', () => this._updateDesktop().catch(e => print('MBY refresh: ' + e)));\n        this._menu.add(mbyRefresh);" "$f"
done

# new right-click scripts and New Document templates also reach people who already have an account
for h in /home/*/; do
  u=$(stat -c %U "$h"); [ "$u" = root ] && continue
  for sub in .local/share/nautilus/scripts Templates; do
    [ -d "/etc/skel/$sub" ] || continue
    mkdir -p "$h$sub"
    for f in /etc/skel/$sub/*; do
      [ -e "$h$sub/$(basename "$f")" ] && continue           # never overwrite the user's own copy
      cp -p "$f" "$h$sub/" && chown "$u:" "$h$sub/$(basename "$f")"
    done
    chown "$u:" "$h$sub"
  done
done

# extensions downloaded from extensions.gnome.org must be readable by every user
chmod -R go+rX /usr/share/gnome-shell/extensions 2>/dev/null

# the radio was removed from MBY OS
pkill -f '/usr/local/bin/mby-radio' 2>/dev/null
rm -f /usr/local/bin/mby-radio
exit 0
