// MBY OS: new-mail alerts go through the system notification centre (top-centre banners)
pref("mail.biff.use_system_alert", true);
pref("mail.biff.show_alert", true);
pref("mail.biff.alert.show_preview", true);
pref("mail.biff.alert.show_sender", true);
pref("mail.biff.alert.show_subject", true);
pref("mail.biff.play_sound", true);
