import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation {
    id: presentation
    function nextSlide() { presentation.goToNextSlide(); }
    Timer { interval: 6000; running: presentation.activatedInCalamares; repeat: true; onTriggered: nextSlide() }

    Slide { Rectangle { anchors.fill: parent; color: "#03140f" }
        Image { source: "welcome.png"; width: 260; height: 260; fillMode: Image.PreserveAspectFit; anchors.centerIn: parent; anchors.verticalCenterOffset: -30 }
        Text { text: "Installing MBY OS - secure by design"; color: "#e6fffb"; font.pixelSize: 20; anchors.horizontalCenter: parent.horizontalCenter; anchors.bottom: parent.bottom; anchors.bottomMargin: 30 } }
    Slide { Rectangle { anchors.fill: parent; color: "#03140f" }
        Text { anchors.centerIn: parent; width: parent.width * 0.8; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter; color: "#e6fffb"; font.pixelSize: 18
               text: "🔒 Firewall, AppArmor and automatic security updates are ON from the first boot.\nYour Private Folder is protected with your own password." } }
    Slide { Rectangle { anchors.fill: parent; color: "#03140f" }
        Text { anchors.centerIn: parent; width: parent.width * 0.8; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter; color: "#e6fffb"; font.pixelSize: 18
               text: "💼 Office (Word, Excel, PowerPoint), Chrome, Brave, WhatsApp, VLC and Notepad with Google Drive sync are ready to use." } }
    Slide { Rectangle { anchors.fill: parent; color: "#03140f" }
        Text { anchors.centerIn: parent; width: parent.width * 0.8; wrapMode: Text.WordWrap; horizontalAlignment: Text.AlignHCenter; color: "#e6fffb"; font.pixelSize: 18
               text: "⚡ Press Fn+Q to switch Eco / Auto / Boost power modes.\n🕒 India and Bahrain time are always on the top bar." } }
}
