/* MBY Sheet - Excel-style right-click menu with a mini toolbar, Format Cells,
 * Column width / Row height / AutoFit, notes, drop-down pick list, paste values
 * and Format Painter.  Uses the globals defined in app.js. */
"use strict";

const FONTS = ["Carlito", "Calibri", "Arial", "Liberation Sans", "Liberation Serif", "Noto Sans Malayalam", "Noto Naskh Arabic", "DejaVu Sans Mono"];
const SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 36];

// ------------------------------------------------------------------ small modal dialog
function dialog(title, bodyHtml, onOk, okLabel = "OK") {
  closeMenu();
  const wrap = document.createElement("div"); wrap.className = "dlg-wrap";
  wrap.innerHTML = `<div class="dlg"><h3>${title}</h3><div class="dlg-body">${bodyHtml}</div>
    <div class="dlg-btns"><button class="cancel">Cancel</button><button class="ok">${okLabel}</button></div></div>`;
  document.body.appendChild(wrap);
  const done = ok => { if (ok && onOk(wrap) === false) return; wrap.remove(); };
  wrap.querySelector(".ok").onclick = () => done(true);
  wrap.querySelector(".cancel").onclick = () => done(false);
  wrap.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") done(true); if (e.key === "Escape") done(false); });
  const first = wrap.querySelector("input,select,textarea"); if (first) { first.focus(); if (first.select) first.select(); }
  return wrap;
}
const PX_PER_CHAR = 7;   // Excel column width unit ≈ 7 px

function columnWidthDialog() {
  const b = rangeBox(), w = Math.round(colW(b.c1) / PX_PER_CHAR * 10) / 10;
  dialog(`Column width (${F.numToCol(b.c1)}${b.c2 > b.c1 ? ":" + F.numToCol(b.c2) : ""})`,
    `<label>Width <input type="number" id="dw" min="1" max="100" step="0.5" value="${w}"> characters</label>
     <p class="hint">Excel default is 8.43. Tip: drag the line between column letters, or double-click it to fit.</p>`,
    wrap => { const v = parseFloat(wrap.querySelector("#dw").value); if (!(v > 0)) return false;
      change(() => { for (let c = b.c1; c <= b.c2; c++) S.colW[c] = Math.round(v * PX_PER_CHAR); }, true); });
}
function rowHeightDialog() {
  const b = rangeBox(), h = Math.round(rowH(b.r1) * 0.75 * 10) / 10;
  dialog(`Row height (rows ${b.r1}${b.r2 > b.r1 ? "-" + b.r2 : ""})`,
    `<label>Height <input type="number" id="dh" min="8" max="400" step="0.5" value="${h}"> points</label><p class="hint">Excel default is 15.</p>`,
    wrap => { const v = parseFloat(wrap.querySelector("#dh").value); if (!(v > 0)) return false;
      change(() => { for (let r = b.r1; r <= b.r2; r++) S.rowH[r] = Math.round(v / 0.75); }, true); });
}
function stepColumns(dpx) {
  const b = rangeBox();
  change(() => { for (let c = b.c1; c <= b.c2; c++) S.colW[c] = Math.max(20, Math.min(800, colW(c) + dpx)); }, true);
}
function autofitSelection() { const b = rangeBox(); change(() => { for (let c = b.c1; c <= b.c2; c++) autofit(c); }, true); }

function formatCellsDialog() {
  const s = style(cur.c, cur.r), nf0 = Object.assign({ cat: s.fmt ? ({ BHD: "currency", INR: "currency", SAR: "currency", USD: "currency", num2: "number", pct: "percent" }[s.fmt]) : "general" }, s.nf || {});
  if (s.fmt && !s.nf) { nf0.sym = { BHD: "BD", INR: "₹", SAR: "SAR", USD: "$" }[s.fmt]; nf0.dp = s.dp != null ? s.dp : DEF_DP[s.fmt]; nf0.sep = true; }
  const CATS = [["general", "General"], ["number", "Number"], ["currency", "Currency"], ["accounting", "Accounting"], ["date", "Date"], ["time", "Time"], ["percent", "Percentage"],
    ["fraction", "Fraction"], ["scientific", "Scientific"], ["text", "Text"], ["special", "Special"], ["custom", "Custom"]];
  const DESC = { general: "General format cells have no specific number format.", number: "Number is used for general display of numbers.", currency: "Currency formats are used for money values.",
    accounting: "Accounting formats line up the currency symbols and decimal points.", date: "Date formats display date serial numbers or dd/mm/yyyy text as dates.", time: "Time formats display times.",
    percent: "Percentage formats multiply the cell value by 100 and show a % symbol.", fraction: "Shows decimals as fractions.", scientific: "Shows numbers like 1.23E+05.",
    text: "Text format cells are treated as text even when a number is in the cell (good for barcodes).", special: "Special formats for phone numbers and codes.", custom: "Type an Excel-style number format code, e.g. #,##0.000 \"BD\"" };
  const o = (v, l, sel) => `<option value="${esc(v)}"${String(sel) === String(v) ? " selected" : ""}>${esc(l)}</option>`;
  const bdSel = s.bt || s.bb || s.bl || s.br ? "custom" : (s.bd ? "all" : "none");
  const html = `
  <div class="tabs"><button data-t="num" class="on">Number</button><button data-t="align">Alignment</button><button data-t="font">Font</button><button data-t="border">Border</button><button data-t="fill">Fill</button><button data-t="prot">Protection</button></div>
  <div class="tab on" data-t="num"><div class="numwrap">
    <div><b class="lbl">Category:</b><select id="nf_cat" size="12">${CATS.map(([v, l]) => o(v, l, nf0.cat)).join("")}</select></div>
    <div class="numright"><fieldset><legend>Sample</legend><div id="nf_sample">&nbsp;</div></fieldset>
      <div class="opt" data-for="number currency accounting percent scientific"><label>Decimal places <input type="number" id="nf_dp" min="0" max="10" value="${nf0.dp != null ? nf0.dp : 2}"></label></div>
      <div class="opt" data-for="number"><label><input type="checkbox" id="nf_sep"${nf0.sep ? " checked" : ""}> Use 1000 separator (,)</label></div>
      <div class="opt" data-for="currency accounting"><label>Symbol <select id="nf_sym">${["BD", "₹", "SAR", "$", "€", "£", "AED"].map(x => o(x, x === "BD" ? "BD (Bahraini Dinar)" : x === "₹" ? "₹ (Indian Rupee)" : x, nf0.sym || "BD")).join("")}</select></label></div>
      <div class="opt" data-for="number currency"><label>Negative numbers <select id="nf_neg">${o("minus", "-1234.10", nf0.neg)}${o("red", "-1234.10 in red", nf0.neg)}${o("paren", "(1234.10)", nf0.neg)}</select></label></div>
      <div class="opt" data-for="date"><label>Type <select id="nf_date">${["dd/mm/yyyy", "d-mmm-yyyy", "d mmmm yyyy", "dddd, d mmmm yyyy", "yyyy-mm-dd", "mm/dd/yyyy"].map(x => o(x, x, nf0.date || "dd/mm/yyyy")).join("")}</select></label></div>
      <div class="opt" data-for="time"><label>Type <select id="nf_time">${["hh:mm", "hh:mm:ss", "h:mm AM/PM"].map(x => o(x, x, nf0.time || "hh:mm")).join("")}</select></label></div>
      <div class="opt" data-for="fraction"><label>Type <select id="nf_frac">${[["any", "Up to one digit (1/4)"], ["2", "As halves (1/2)"], ["4", "As quarters (2/4)"], ["8", "As eighths (4/8)"], ["10", "As tenths (3/10)"], ["100", "As hundredths (30/100)"]].map(([v, l]) => o(v, l, nf0.frac || "any")).join("")}</select></label></div>
      <div class="opt" data-for="special"><label>Type <select id="nf_special">${o("phone", "Phone number (3333 4444)", nf0.special)}${o("code", "Code / barcode (keeps zeros)", nf0.special)}</select></label></div>
      <div class="opt" data-for="custom"><label>Type <input id="nf_code" value="${esc(nf0.code || "#,##0.000 \"BD\"")}" style="width:220px"></label>
        <select id="nf_codes" size="5" style="width:100%;margin-top:6px">${["0", "0.00", "#,##0", "#,##0.00", "#,##0.000 \"BD\"", "\"₹\"#,##0.00", "0%", "0.00%", "#,##0.00;[Red]-#,##0.00"].map(x => `<option>${esc(x)}</option>`).join("")}</select></div>
      <p class="hint" id="nf_desc"></p></div></div></div>
  <div class="tab" data-t="align"><div class="alignwrap"><div>
    <b class="lbl">Text alignment</b>
    <div class="grid2">
    <label>Horizontal<select id="al_h">${[["", "General"], ["left", "Left (Indent)"], ["center", "Centre"], ["right", "Right (Indent)"], ["fill", "Fill"], ["justify", "Justify"], ["centerAcross", "Centre Across Selection"], ["distributed", "Distributed (Indent)"]].map(([v, l]) => o(v, l, s.al || "")).join("")}</select></label>
    <label>Indent<input type="number" id="al_ind" min="0" max="15" value="${s.ind || 0}"></label>
    <label>Vertical<select id="al_v">${[["top", "Top"], ["middle", "Centre"], ["", "Bottom"], ["justify", "Justify"], ["distributed", "Distributed"]].map(([v, l]) => o(v, l, s.va || "")).join("")}</select></label>
    <label class="chk"><input type="checkbox" id="al_jd"${s.jd ? " checked" : ""}> Justify distributed</label></div>
    <b class="lbl">Text control</b>
    <label class="chk"><input type="checkbox" id="al_wrap"${s.wrap ? " checked" : ""}> Wrap text</label>
    <label class="chk"><input type="checkbox" id="al_shrink"${s.shrink ? " checked" : ""}> Shrink to fit</label>
    <label class="chk"><input type="checkbox" id="al_merge"${mergesIn(rangeBox()).length ? " checked" : ""}> Merge cells</label>
    <b class="lbl">Right-to-left</b>
    <label>Text direction<select id="al_dir">${[["", "Context"], ["ltr", "Left-to-Right"], ["rtl", "Right-to-Left"]].map(([v, l]) => o(v, l, s.dir || "")).join("")}</select></label>
    </div><fieldset class="orient"><legend>Orientation</legend>
      <label class="chk vertbox"><input type="checkbox" id="al_vert"${s.vert ? " checked" : ""}> <span class="vtext">T<br>e<br>x<br>t</span></label>
      <div class="dial"><input type="range" id="al_rot" min="-90" max="90" step="5" value="${s.rot || 0}" orient="vertical"><span id="al_rotprev" style="transform:rotate(${-(s.rot || 0)}deg)">Text ——</span></div>
      <label><input type="number" id="al_deg" min="-90" max="90" value="${s.rot || 0}" style="width:64px"> Degrees</label></fieldset></div></div>
  <div class="tab" data-t="font"><div class="grid2">
    <label>Font<select id="ft_f">${o("", "Default (Carlito)", s.ff || "")}${FONTS.map(f => o(f, f, s.ff || "")).join("")}</select></label>
    <label>Size<select id="ft_z">${o("", "Default (10)", String(s.fz || ""))}${SIZES.map(z => o(String(z), z, String(s.fz || ""))).join("")}</select></label>
    <label>Font style<select id="ft_st">${o("", "Regular", (s.b ? "b" : "") + (s.i ? "i" : ""))}${o("i", "Italic", (s.b ? "b" : "") + (s.i ? "i" : ""))}${o("b", "Bold", (s.b ? "b" : "") + (s.i ? "i" : ""))}${o("bi", "Bold Italic", (s.b ? "b" : "") + (s.i ? "i" : ""))}</select></label>
    <label>Colour<input type="color" id="ft_c" value="${s.fg || "#000000"}"></label>
    <label class="chk"><input type="checkbox" id="ft_u"${s.u ? " checked" : ""}> Underline</label>
    <label class="chk"><input type="checkbox" id="ft_s"${s.st ? " checked" : ""}> Strikethrough</label></div>
    <fieldset><legend>Preview</legend><div id="ft_prev">AaBbCcYyZz 123</div></fieldset></div>
  <div class="tab" data-t="border"><div class="grid2">
    <label>Presets<select id="bd_p">${[["none", "None"], ["all", "All borders"], ["outside", "Outside borders"], ["thick", "Thick outside"], ["bottom", "Bottom border"], ["top", "Top border"], ["double", "Double bottom"], ["custom", "(current)"]].map(([v, l]) => o(v, l, bdSel)).join("")}</select></label>
    <label>Colour<input type="color" id="bd_c" value="#444444"></label></div>
    <div class="bdprev"><div id="bd_box">Text</div></div></div>
  <div class="tab" data-t="fill"><div class="grid2">
    <label>Background colour<input type="color" id="fl_c" value="${s.bg || "#ffffff"}"></label>
    <label class="chk"><input type="checkbox" id="fl_none"${s.bg ? "" : " checked"}> No colour</label></div>
    <div class="swatches">${["#ffffff", "#f3f4f6", "#fef9c3", "#fde68a", "#fed7aa", "#fecaca", "#fbcfe8", "#e9d5ff", "#c7d2fe", "#bfdbfe", "#a5f3fc", "#bbf7d0", "#dcfce7", "#1e3a5f", "#15803d", "#b91c1c"].map(c => `<span data-c="${c}" style="background:${c}"></span>`).join("")}</div>
    <fieldset><legend>Sample</legend><div id="fl_prev" style="height:34px;background:${s.bg || "#fff"}"></div></fieldset></div>
  <div class="tab" data-t="prot"><label class="chk"><input type="checkbox" id="pr_l"${s.unlocked ? "" : " checked"}> Locked</label>
    <label class="chk" style="display:block;margin-top:8px"><input type="checkbox" id="pr_h"${s.hid ? " checked" : ""}> Hidden (formula not shown)</label>
    <p class="hint">Locking cells or hiding formulas has no effect until you protect the sheet (Review tab › Protect sheet).</p></div>`;
  const w = dialog("Format Cells", html, wrap => {
    const v = id => wrap.querySelector(id), cat = v("#nf_cat").value, b = rangeBox();
    const nf = { cat };
    if (["number", "currency", "accounting", "percent", "scientific"].includes(cat)) nf.dp = +v("#nf_dp").value;
    if (cat === "number") nf.sep = v("#nf_sep").checked;
    if (cat === "number" || cat === "currency") nf.neg = v("#nf_neg").value;
    if (cat === "currency" || cat === "accounting") nf.sym = v("#nf_sym").value;
    if (cat === "date") nf.date = v("#nf_date").value; if (cat === "time") nf.time = v("#nf_time").value;
    if (cat === "fraction") nf.frac = v("#nf_frac").value; if (cat === "special") nf.special = v("#nf_special").value; if (cat === "custom") nf.code = v("#nf_code").value;
    const preset = v("#bd_p").value, bc = v("#bd_c").value, line = (wd, st = "solid") => `${wd}px ${st} ${bc}`;
    change(() => {
      for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) {
        const k = ref(c, r), o2 = S.cells[k] || { v: "" }, t = Object.assign({}, o2.s);
        const set = (key, val) => { if (val === "" || val == null || val === false || val === 0) delete t[key]; else t[key] = val; };
        delete t.fmt; delete t.dp; if (cat === "general") delete t.nf; else t.nf = nf;
        set("al", v("#al_h").value); set("va", v("#al_v").value); set("ind", +v("#al_ind").value); set("wrap", v("#al_wrap").checked);
        set("jd", v("#al_jd").checked); set("shrink", v("#al_shrink").checked); set("dir", v("#al_dir").value);
        set("vert", v("#al_vert").checked); set("rot", v("#al_vert").checked ? 0 : +v("#al_deg").value);
        set("ff", v("#ft_f").value); set("fz", v("#ft_z").value ? +v("#ft_z").value : null);
        const fs = v("#ft_st").value; set("b", fs.includes("b")); set("i", fs.includes("i"));
        set("fg", v("#ft_c").value === "#000000" ? "" : v("#ft_c").value); set("u", v("#ft_u").checked); set("st", v("#ft_s").checked);
        set("bg", v("#fl_none").checked ? "" : v("#fl_c").value);
        set("unlocked", !v("#pr_l").checked); set("hid", v("#pr_h").checked);
        if (preset !== "custom") {
          for (const x of ["bd", "bt", "bb", "bl", "br"]) delete t[x];
          if (preset === "all") { t.bt = t.bb = t.bl = t.br = line(1); }
          if (preset === "outside" || preset === "thick") { const L = line(preset === "thick" ? 2 : 1); if (r === b.r1) t.bt = L; if (r === b.r2) t.bb = L; if (c === b.c1) t.bl = L; if (c === b.c2) t.br = L; }
          if (preset === "bottom" && r === b.r2) t.bb = line(1);
          if (preset === "top" && r === b.r1) t.bt = line(1);
          if (preset === "double" && r === b.r2) t.bb = line(3, "double");
        }
        if (Object.keys(t).length) o2.s = t; else delete o2.s; S.cells[k] = o2;
      }
      // Merge cells (real merge, like Excel): the upper-left value is kept; unticking unmerges
      if (v("#al_merge").checked && (b.c2 > b.c1 || b.r2 > b.r1)) addMerge(b, v("#al_h").value === "center");
      else if (!v("#al_merge").checked && mergesIn(b).length) unmerge(b);
      if (v("#al_h").value === "centerAcross" && b.c2 > b.c1)            // centre across selection: one line, no merge
        for (let r = b.r1; r <= b.r2; r++) addMerge({ c1: b.c1, c2: b.c2, r1: r, r2: r }, true);
    }, true);
  });
  // tabs
  w.querySelector(".tabs").addEventListener("click", e => { const t = e.target.dataset.t; if (!t) return; w.querySelectorAll(".tabs button, .tab").forEach(x => x.classList.toggle("on", x.dataset.t === t)); });
  // orientation: slider, degrees box and stacked text stay in step
  { const rot = w.querySelector("#al_rot"), deg = w.querySelector("#al_deg"), pv = w.querySelector("#al_rotprev");
    const upd = x => { rot.value = deg.value = x; pv.style.transform = `rotate(${-x}deg)`; };
    rot.addEventListener("input", () => upd(rot.value)); deg.addEventListener("input", () => upd(Math.max(-90, Math.min(90, +deg.value || 0)))); }
  // live sample
  const v = id => w.querySelector(id);
  const sampleVal = (() => { const x = engine.value(ref(cur.c, cur.r)); return typeof x === "number" ? x : (parseDateText(x) ? x : 1234.5); })();
  const update = () => {
    const cat = v("#nf_cat").value;
    w.querySelectorAll(".opt").forEach(el => { el.style.display = el.dataset.for.split(" ").includes(cat) ? "" : "none"; });
    v("#nf_desc").textContent = DESC[cat];
    const nf = { cat, dp: +v("#nf_dp").value, sep: v("#nf_sep").checked, neg: v("#nf_neg").value, sym: v("#nf_sym").value, date: v("#nf_date").value, time: v("#nf_time").value, frac: v("#nf_frac").value, special: v("#nf_special").value, code: v("#nf_code").value };
    let t;
    if (cat === "general") t = typeof sampleVal === "number" ? fmtNum(sampleVal) : sampleVal;
    else if (cat === "text") t = String(raw(cur.c, cur.r) || sampleVal);
    else if ((cat === "date" || cat === "time") && typeof sampleVal === "string") { const d = parseDateText(sampleVal); t = cat === "date" ? fmtDate(d, nf.date) : fmtTime(d, nf.time); }
    else t = formatNF(typeof sampleVal === "number" ? sampleVal : 45986.5, nf);
    v("#nf_sample").textContent = t; v("#nf_sample").style.color = (typeof sampleVal === "number" && sampleVal < 0 && nf.neg === "red") ? "#dc2626" : "";
    const fs = v("#ft_st").value; Object.assign(v("#ft_prev").style, { fontFamily: v("#ft_f").value || "Carlito, sans-serif", fontSize: (v("#ft_z").value || 10) + "pt", fontWeight: fs.includes("b") ? 700 : 400, fontStyle: fs.includes("i") ? "italic" : "normal", color: v("#ft_c").value, textDecoration: [v("#ft_u").checked ? "underline" : "", v("#ft_s").checked ? "line-through" : ""].join(" ") });
    v("#fl_prev").style.background = v("#fl_none").checked ? "#fff" : v("#fl_c").value;
    const p = v("#bd_p").value, c = v("#bd_c").value, bx = v("#bd_box").style;
    bx.border = "1px dashed #ccc";
    if (p === "all" || p === "outside") bx.border = `1px solid ${c}`; if (p === "thick") bx.border = `2px solid ${c}`;
    if (p === "bottom") bx.borderBottom = `1px solid ${c}`; if (p === "top") bx.borderTop = `1px solid ${c}`; if (p === "double") bx.borderBottom = `3px double ${c}`;
  };
  w.addEventListener("input", update); w.addEventListener("change", update);
  v("#nf_codes").addEventListener("change", e => { v("#nf_code").value = e.target.value; update(); });
  w.querySelector(".swatches").addEventListener("click", e => { const c = e.target.dataset.c; if (c) { v("#fl_c").value = c; v("#fl_none").checked = c === "#ffffff"; update(); } });
  v("#fl_c").addEventListener("input", () => { v("#fl_none").checked = false; });
  update();
}
function noteDialog() {
  const s = style(cur.c, cur.r);
  dialog(`Note for ${ref(cur.c, cur.r)}`, `<textarea id="dn" rows="4" placeholder="Write a note…">${esc(s.note || "")}</textarea>`,
    wrap => { const t = wrap.querySelector("#dn").value.trim(); setStyle(x => { if (t) x.note = t; else delete x.note; }); });
}
function pickListDialog() {          // values already used in this column, like Excel's Pick From Drop-down List
  const vals = new Set();
  for (let r = 2; r <= S.rows; r++) if (r !== cur.r && !isTotalRow(r)) { const t = display(cur.c, r).t; if (t !== "" && !(style(cur.c, r).b && r <= 2)) vals.add(t); }
  const list = [...vals].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  if (!list.length) { setSaved("No values in this column yet"); return; }
  dialog("Pick from list", `<select id="dp" size="${Math.min(12, list.length)}" style="width:100%">${list.map(v => `<option>${esc(v)}</option>`).join("")}</select>`,
    wrap => { const v = wrap.querySelector("#dp").value; if (v != null) { change(() => setRaw(cur.c, cur.r, v)); select(cur.c, cur.r + 1); } });
}
function filterBySelected() {
  const t = display(cur.c, cur.r).t; filtersOn = true; filters = { [cur.c]: t }; render();
}
function pasteValues() {
  if (!clipRaw) return;
  const tsv = clipRaw.text; clipRaw = null; pasteText(tsv);     // text only: results, no formulas or formats
}
function stepDecimals(d) {
  setStyle(s => {
    if (s.nf && ["number", "currency", "accounting", "percent", "scientific"].includes(s.nf.cat)) {
      const base = s.nf.dp != null ? +s.nf.dp : (s.nf.cat === "currency" || s.nf.cat === "accounting" ? (CUR[s.nf.sym || "BD"] || CUR.BD)[0] : 2);
      s.nf = Object.assign({}, s.nf, { dp: Math.max(0, Math.min(10, base + d)) }); return;
    }
    if (s.nf) delete s.nf;
    const base = s.dp != null ? s.dp : (DEF_DP[s.fmt] != null ? DEF_DP[s.fmt] : 0);
    s.dp = Math.max(0, Math.min(10, base + d));
  });
}
function stepFont(d) {
  setStyle(s => { const cur = s.fz || 10; const i = SIZES.findIndex(z => z >= cur); const n = SIZES[Math.max(0, Math.min(SIZES.length - 1, (i < 0 ? SIZES.length - 1 : i) + d))]; s.fz = n; });
}

// ------------------------------------------------------------------ the menu
let menuEl = null;
function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
function item(label, icon, fn, opts = {}) { return { label, icon, fn, ...opts }; }
function sep() { return { sep: true }; }

function cellMenuItems() {
  return [
    item("Cut", "✂️", () => copySel(true), { key: "Ctrl+X" }),
    item("Copy", "📋", () => copySel(false), { key: "Ctrl+C" }),
    item("Paste", "📥", () => CMD.paste(), { key: "Ctrl+V" }),
    item("Paste values only", "🔢", pasteValues, { disabled: !clipRaw }),
    sep(),
    item("Insert", "➕", null, { sub: [
      item("Row above", "", () => CMD.rowabove()), item("Row below", "", () => CMD.rowbelow()),
      item("Column left", "", () => CMD.colleft()), item("Column right", "", () => CMD.colright())] }),
    item("Delete", "➖", null, { sub: [item("Entire row", "", () => CMD.delrow()), item("Entire column", "", () => CMD.delcol())] }),
    item("Clear contents", "🧽", () => change(() => eachSel((c, r) => setRaw(c, r, ""))), { key: "Del" }),
    sep(),
    item("Filter", "⏷", null, { sub: [item("Filter by this value", "", filterBySelected), item("Show filter boxes", "", () => CMD.filter()), item("Clear filter", "", () => CMD.clearfilter())] }),
    item("Sort", "⇅", null, { sub: [item("A → Z  (small → big)", "", () => CMD.sortaz()), item("Z → A  (big → small)", "", () => CMD.sortza())] }),
    sep(),
    item(style(cur.c, cur.r).note ? "Edit note" : "New note", "📝", noteDialog),
    item("Delete note", "🗑️", () => setStyle(x => { delete x.note; }), { hidden: !style(cur.c, cur.r).note }),
    item("Format cells…", "🎨", formatCellsDialog, { key: "Ctrl+1" }),
    item("Pick from drop-down list…", "📃", pickListDialog),
    sep(),
    item("Column width…", "↔", columnWidthDialog),
    item("Row height…", "↕", rowHeightDialog),
    item("AutoFit column", "⇔", autofitSelection),
  ];
}
function headerMenuItems(kind) {
  const col = kind === "col";
  return [
    item("Cut", "✂️", () => copySel(true)), item("Copy", "📋", () => copySel(false)), item("Paste", "📥", () => CMD.paste()),
    sep(),
    col ? item("Insert column left", "➕", () => CMD.colleft()) : item("Insert row above", "➕", () => CMD.rowabove()),
    col ? item("Insert column right", "➕", () => CMD.colright()) : item("Insert row below", "➕", () => CMD.rowbelow()),
    (() => { const b = rangeBox(), n = col ? b.c2 - b.c1 + 1 : b.r2 - b.r1 + 1;
      const what = col ? (n > 1 ? `Delete ${n} columns (${F.numToCol(b.c1)}:${F.numToCol(b.c2)})` : `Delete column ${F.numToCol(b.c1)}`) : (n > 1 ? `Delete ${n} rows (${b.r1}:${b.r2})` : `Delete row ${b.r1}`);
      return item(what, "➖", () => col ? CMD.delcol() : CMD.delrow()); })(),
    item("Clear contents", "🧽", () => change(() => eachSel((c, r) => setRaw(c, r, "")))),
    sep(),
    col ? item("Column width…", "↔", columnWidthDialog) : item("Row height…", "↕", rowHeightDialog),
    col ? item("AutoFit column", "⇔", autofitSelection) : item("Default height", "↕", () => { const b = rangeBox(); change(() => { for (let r = b.r1; r <= b.r2; r++) delete S.rowH[r]; }, true); }),
    col ? item("Wider  (+10 px)", "⊕", () => stepColumns(10)) : null,
    col ? item("Narrower  (-10 px)", "⊖", () => stepColumns(-10)) : null,
    sep(),
    col ? item("Sort A → Z", "⇅", () => CMD.sortaz()) : null,
    col ? item("Sort Z → A", "⇅", () => CMD.sortza()) : null,
    item("Format cells…", "🎨", formatCellsDialog),
  ].filter(Boolean);
}

function miniToolbar() {
  const s = style(cur.c, cur.r);
  const fontOpts = [`<option value="">Font</option>`, ...FONTS.map(f => `<option${s.ff === f ? " selected" : ""}>${f}</option>`)].join("");
  const sizeOpts = [`<option value="">${s.fz || 10}</option>`, ...SIZES.map(z => `<option value="${z}">${z}</option>`)].join("");
  return `<div class="mini">
    <div class="row"><select class="m-font">${fontOpts}</select><select class="m-size">${sizeOpts}</select>
      <button data-m="grow" title="Bigger font">A<sup>+</sup></button><button data-m="shrink" title="Smaller font">A<sup>−</sup></button>
      <button data-m="bhd" title="BHD currency">BD</button><button data-m="pct" title="Percent">%</button><button data-m="comma" title="Thousands, 2 decimals">,</button>
      <button data-m="fit" title="AutoFit column">⇔</button></div>
    <div class="row"><button data-m="b" title="Bold"><b>B</b></button><button data-m="i" title="Italic"><i>I</i></button><button data-m="center" title="Centre">≡</button>
      <label title="Fill colour">🪣<input type="color" class="m-bg" value="${s.bg || "#fff2a8"}"></label>
      <label title="Text colour"><b style="color:#c00">A</b><input type="color" class="m-fg" value="${s.fg || "#c00000"}"></label>
      <button data-m="bd" title="Borders">▦</button><button data-m="decup" title="More decimals">.0+</button><button data-m="decdn" title="Fewer decimals">.0−</button>
      <button data-m="painter" title="Format Painter: copy this format, then click another cell">🖌️</button></div></div>`;
}
const MINI = {
  grow: () => stepFont(1), shrink: () => stepFont(-1),
  bhd: () => setStyle(s => { delete s.nf; delete s.dp; s.fmt = "BHD"; }), pct: () => setStyle(s => { delete s.nf; delete s.dp; s.fmt = "pct"; }), comma: () => setStyle(s => { delete s.nf; delete s.dp; s.fmt = "num2"; }),
  fit: autofitSelection, b: () => CMD.bold(), i: () => CMD.italic(), center: () => CMD.center(), bd: () => CMD.borders(),
  decup: () => stepDecimals(1), decdn: () => stepDecimals(-1),
  painter: () => { painter = Object.assign({}, style(cur.c, cur.r)); document.body.classList.add("painting"); setSaved("🖌️ Click or drag over the cells to paint this format"); },
};

function openMenu(x, y, items, withMini) {
  closeMenu();
  const m = document.createElement("div"); m.className = "ctx";
  let html = withMini ? miniToolbar() : "";
  html += `<input class="ctx-search" placeholder="Search the menus">`;
  html += `<div class="ctx-list">` + renderItems(items) + `</div>`;
  m.innerHTML = html; document.body.appendChild(m); menuEl = m;
  const vw = window.innerWidth, vh = window.innerHeight, rc = m.getBoundingClientRect();
  m.style.left = Math.min(x, vw - rc.width - 6) + "px"; m.style.top = Math.max(4, Math.min(y, vh - rc.height - 6)) + "px";
  const flat = items.flatMap(i => i && i.sub ? i.sub.map(s => ({ ...s, label: i.label + " › " + s.label })) : [i]).filter(i => i && !i.sep && i.fn);
  m.addEventListener("mousedown", e => e.stopPropagation());
  m.addEventListener("click", e => {
    const b = e.target.closest("[data-i]"); if (b && !b.classList.contains("dis")) { const it = JSON.parse(b.dataset.i); const fn = resolve(items, it); if (fn) { closeMenu(); fn(); } return; }
    const mb = e.target.closest("[data-m]"); if (mb) { MINI[mb.dataset.m](); if (mb.dataset.m !== "painter") refreshMini(); else closeMenu(); }
  });
  m.querySelector(".m-font") && m.querySelector(".m-font").addEventListener("change", e => { setStyle(s => { if (e.target.value) s.ff = e.target.value; else delete s.ff; }); });
  m.querySelector(".m-size") && m.querySelector(".m-size").addEventListener("change", e => { if (e.target.value) setStyle(s => { s.fz = +e.target.value; }); });
  m.querySelector(".m-bg") && m.querySelector(".m-bg").addEventListener("input", e => setStyle(s => { s.bg = e.target.value; }));
  m.querySelector(".m-fg") && m.querySelector(".m-fg").addEventListener("input", e => setStyle(s => { s.fg = e.target.value; }));
  const search = m.querySelector(".ctx-search");
  search.addEventListener("keydown", e => e.stopPropagation());
  search.addEventListener("input", () => {
    const q = search.value.trim().toLowerCase();
    m.querySelector(".ctx-list").innerHTML = q ? renderItems(flat.filter(i => i.label.toLowerCase().includes(q)).map(i => ({ ...i, sub: null }))) || `<div class="ctx-empty">No match</div>` : renderItems(items);
    m._flat = q ? flat.filter(i => i.label.toLowerCase().includes(q)) : null;
  });
  function resolve(list, it) {
    if (m._flat) return m._flat[it.a] && m._flat[it.a].fn;          // clicked a search result
    let x = list[it.a]; if (it.b !== undefined) x = x.sub[it.b]; return x && x.fn;
  }
}
function renderItems(items) {
  return items.map((it, a) => {
    if (!it || it.hidden) return "";
    if (it.sep) return `<div class="ctx-sep"></div>`;
    const sub = it.sub ? `<div class="ctx-sub">${it.sub.map((s, b) => `<div class="ctx-item" data-i='${JSON.stringify({ a, b })}'><span class="ic">${s.icon || ""}</span>${esc(s.label)}</div>`).join("")}</div>` : "";
    return `<div class="ctx-item${it.disabled ? " dis" : ""}${it.sub ? " has-sub" : ""}"${it.fn ? ` data-i='${JSON.stringify({ a })}'` : ""}>
      <span class="ic">${it.icon || ""}</span>${esc(it.label)}<span class="key">${it.key || (it.sub ? "›" : "")}</span>${sub}</div>`;
  }).join("");
}
function refreshMini() { if (!menuEl) return; const old = menuEl.querySelector(".mini"); if (!old) return; const t = document.createElement("div"); t.innerHTML = miniToolbar(); old.replaceWith(t.firstElementChild); }

// right-click on cells, column letters and row numbers
$("#wrap").addEventListener("contextmenu", e => {
  e.preventDefault();
  if (editing) commit(0, 0);
  const th = e.target.closest("thead th[data-c]"), rh = e.target.closest("tbody th[data-r]");
  if (th) { const c = +th.dataset.c, b = rangeBox(); if (!(c >= b.c1 && c <= b.c2 && b.r1 === 1)) { anchor = { c, r: 1 }; select(c, Math.max(lastRow(), 1), true, true); } openMenu(e.clientX, e.clientY, headerMenuItems("col"), true); return; }
  if (rh) { const r = +rh.dataset.r, b = rangeBox(); if (!(r >= b.r1 && r <= b.r2 && b.c1 === 1)) { anchor = { c: 1, r }; select(S.cols, r, true, true); } openMenu(e.clientX, e.clientY, headerMenuItems("row"), true); return; }
  if (e.target.closest("td[data-c]")) openMenu(e.clientX, e.clientY, cellMenuItems(), true);
});
document.addEventListener("mousedown", e => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); }, true);
document.addEventListener("keydown", e => {
  if (e.key === "Escape") { if (menuEl) { closeMenu(); e.stopPropagation(); } if (painter) { painter = null; document.body.classList.remove("painting"); setSaved(""); } }
  if ((e.ctrlKey || e.metaKey) && e.key === "1") { e.preventDefault(); formatCellsDialog(); }
}, true);
window.addEventListener("blur", closeMenu);
$("#wrap").addEventListener("scroll", closeMenu);

// ribbon: Home > Cells group (Column width, Row height, AutoFit, wider / narrower)
Object.assign(CMD, {
  colwidth: columnWidthDialog, rowheight: rowHeightDialog, autofitsel: autofitSelection,
  wider: () => stepColumns(10), narrower: () => stepColumns(-10), formatcells: formatCellsDialog, note: noteDialog,
});
