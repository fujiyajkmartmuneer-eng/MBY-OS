"""MBY Sheet file input/output: .xlsx (Excel, via openpyxl) and .csv.

Sheet format shared with the page (app.js):
  {"name": str, "rows": int, "cols": int,
   "cells": {"A1": {"v": "text or =formula", "s": {"b":1,"i":1,"fg":"#rrggbb","bg":"#rrggbb","al":"left|center|right","fmt":"BHD|INR|SAR|USD|num2|pct","bd":1}}},
   "colW": {"1": px}, "rowH": {"1": px}}
"""
import base64, csv, io, os, re, datetime
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.drawing.image import Image as XLImage
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule, FormulaRule
from openpyxl.styles import Protection
from openpyxl.utils.cell import range_boundaries
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import column_index_from_string, get_column_letter

MARK = "Made with MBY Sheet"
NUMFMT = {
    "BHD": '#,##0.000 "BD"', "INR": '"₹"#,##,##0.00', "SAR": '#,##0.00 "SAR"',
    "USD": '"$"#,##0.00', "num2": "#,##0.00", "pct": "0.00%",
}
THIN = Side(style="thin", color="444444")
REF = re.compile(r"^([A-Z]{1,3})(\d+)$")


def _numfmt(fmt, dp):
    """number format string; dp = decimals chosen with .0+ / .0- (None = format default)"""
    if fmt not in NUMFMT and dp is None:
        return None
    base = NUMFMT.get(fmt, "#,##0.00")
    if dp is None:
        return base
    dec = ("." + "0" * int(dp)) if int(dp) > 0 else ""
    return re.sub(r"0(\.0+)?(?=[^0.]|$)", "0" + dec, base, count=1) if fmt else ("0" + dec if not fmt else base)


CURSYM = {"BD": ('"BD" ', '', 3), "₹": ('"₹"', '', 2), "SAR": ('', ' "SAR"', 2), "$": ('"$"', '', 2), "€": ('"€"', '', 2), "£": ('"£"', '', 2), "AED": ('"AED" ', '', 2)}


def _nf_code(nf):
    """MBY Sheet number format (nf dict) -> Excel number_format"""
    cat = nf.get("cat")
    dp = nf.get("dp")
    dec = lambda d: ("." + "0" * int(d)) if d and int(d) > 0 else ""
    if cat == "number":
        base = ("#,##0" if nf.get("sep") else "0") + dec(dp if dp is not None else 2)
        return {"red": f"{base};[Red]-{base}", "paren": f"{base};({base})"}.get(nf.get("neg"), base)
    if cat in ("currency", "accounting"):
        pre, post, d0 = CURSYM.get(nf.get("sym") or "BD", CURSYM["BD"])
        base = f"{pre}#,##0{dec(dp if dp is not None else d0)}{post}"
        if cat == "accounting":
            return f"_({base}_);({base})"
        return {"red": f"{base};[Red]-{base}", "paren": f"{base};({base})"}.get(nf.get("neg"), base)
    if cat == "percent":
        return "0" + dec(dp if dp is not None else 0) + "%"
    if cat == "scientific":
        return "0" + dec(dp if dp is not None else 2) + "E+00"
    if cat == "date":
        return {"d-mmm-yyyy": "d-mmm-yyyy", "d mmmm yyyy": "d mmmm yyyy", "dddd, d mmmm yyyy": "dddd, d mmmm yyyy", "yyyy-mm-dd": "yyyy-mm-dd", "mm/dd/yyyy": "mm/dd/yyyy"}.get(nf.get("date"), "dd/mm/yyyy")
    if cat == "time":
        return {"hh:mm:ss": "hh:mm:ss", "h:mm AM/PM": "h:mm AM/PM"}.get(nf.get("time"), "hh:mm")
    if cat == "fraction":
        f = nf.get("frac") or "any"
        return "# ?/?" if f == "any" else f"# ?/{f}"
    if cat == "text":
        return "@"
    if cat == "special":
        return "0000 0000" if nf.get("special") == "phone" else "@"
    if cat == "custom":
        return nf.get("code") or "General"
    return None


def _nf_from(code):
    """Excel number_format -> MBY Sheet nf dict (best effort)"""
    c = code or "General"
    if c == "General":
        return None
    if c == "@":
        return {"cat": "text"}
    m = re.search(r"0\.(0+)", c)
    dp = len(m.group(1)) if m else 0
    if "E+" in c:
        return {"cat": "scientific", "dp": dp}
    if "?/" in c:
        return {"cat": "fraction", "frac": c.split("/")[-1] if c.split("/")[-1].isdigit() else "any"}
    if "%" in c:
        return {"cat": "percent", "dp": dp}
    if re.search(r"[dy]{2}", c, re.I) and not re.search(r"0", c):
        return {"cat": "date", "date": {"d-mmm-yyyy": "d-mmm-yyyy", "yyyy-mm-dd": "yyyy-mm-dd", "mm/dd/yyyy": "mm/dd/yyyy"}.get(c, "dd/mm/yyyy")}
    if re.fullmatch(r"\[?h+\]?:mm(:ss)?( AM/PM)?", c, re.I):
        return {"cat": "time", "time": "h:mm AM/PM" if "AM" in c else ("hh:mm:ss" if "ss" in c else "hh:mm")}
    for sym, (pre, post, _d) in CURSYM.items():
        if (pre and pre.strip() in c) or (post and post.strip() in c):
            return {"cat": "accounting" if c.startswith("_(") else "currency", "sym": sym, "dp": dp, "neg": "red" if "[Red]" in c else ("paren" if "(" in c and not c.startswith("_(") else "minus")}
    if re.fullmatch(r"[#,0]+(\.0+)?(;.*)?", c):
        return {"cat": "number", "dp": dp, "sep": "," in c, "neg": "red" if "[Red]" in c else ("paren" if "(" in c else "minus")}
    return {"cat": "custom", "code": c}


def _side(css):
    """'1px solid #444' -> openpyxl Side"""
    if not css:
        return Side()
    m = re.match(r"(\d+)px\s+(\w+)\s+(#[0-9a-fA-F]{6})", css)
    if not m:
        return THIN
    w, st, col = int(m.group(1)), m.group(2), m.group(3)
    style = "double" if st == "double" else ("medium" if w >= 2 else "thin")
    return Side(style=style, color=col.lstrip("#").upper())


def _css(side):
    if side is None or not side.style:
        return None
    col = "#" + (side.color.rgb[-6:] if side.color is not None and isinstance(side.color.rgb, str) else "444444")
    return {"double": f"3px double {col}", "medium": f"2px solid {col}", "thick": f"2px solid {col}"}.get(side.style, f"1px solid {col}")


def _hex(c):
    return c.lstrip("#").upper().rjust(6, "0")[-6:] if c else None


def _number(v):
    """typed text -> number when it looks like one (so Excel can calculate with it)"""
    s = v.strip()
    digits = re.sub(r"\D", "", s)
    if re.fullmatch(r"0\d+", s) or (s.isdigit() and len(s) >= 12):
        return None              # barcodes / phone numbers: keep as text (leading zeros, all digits)
    if re.fullmatch(r"[-+]?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?([eE][+-]?\d+)?", s):
        n = float(s.replace(",", ""))
        return int(n) if n.is_integer() and "." not in s and "e" not in s.lower() else n
    if re.fullmatch(r"[-+]?\d+(\.\d+)?%", s):
        return float(s[:-1]) / 100
    return None


def write_xlsx(sheet, path):
    wb = Workbook(); ws = wb.active
    merges = []
    ws.title = re.sub(r"[\[\]:*?/\\]", "-", (sheet.get("name") or "Sheet"))[:31] or "Sheet"
    for key, o in sheet.get("cells", {}).items():
        m = REF.match(key)
        if not m: continue
        c = ws[key]
        v = o.get("v", "")
        if isinstance(v, str) and v.startswith("=") and len(v) > 1:
            c.value = v
        elif isinstance(v, str):
            n = _number(v)
            dm = re.fullmatch(r"(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})", v.strip())
            tm = re.fullmatch(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", v.strip())
            if dm and n is None:                      # a real date in Excel (sorts and calculates), shown dd/mm/yyyy
                try:
                    c.value = datetime.datetime(int(dm.group(3)), int(dm.group(2)), int(dm.group(1)))
                    c.number_format = "dd/mm/yyyy"
                except ValueError:
                    c.value = v
            elif tm and n is None and int(tm.group(1)) < 24:
                c.value = datetime.time(int(tm.group(1)), int(tm.group(2)), int(tm.group(3) or 0))
                c.number_format = "hh:mm:ss" if tm.group(3) else "hh:mm"
            else:
                c.value = n if n is not None else (v if v != "" else None)
                if n is not None and v.strip().endswith("%"):     # 12.5% stays 12.5% in Excel
                    dec = len(v.strip()[:-1].split(".")[1]) if "." in v else 0
                    c.number_format = "0" + ("." + "0" * dec if dec else "") + "%"
        else:
            c.value = v
        s = o.get("s") or {}
        if s.get("b") or s.get("i") or s.get("fg") or s.get("ff") or s.get("fz") or s.get("u") or s.get("st"):
            c.font = Font(bold=bool(s.get("b")), italic=bool(s.get("i")), color=_hex(s.get("fg")),
                          name=s.get("ff") or "Calibri", size=s.get("fz") or 11,
                          underline="single" if s.get("u") else None, strike=bool(s.get("st")))
        if s.get("bg"):
            c.fill = PatternFill("solid", fgColor=_hex(s["bg"]))
        if any(s.get(k) for k in ("al", "wrap", "va", "ind", "rot", "vert", "shrink", "dir", "jd")):
            H = {"centerAcross": "centerContinuous"}
            V = {"middle": "center", "top": "top", "justify": "justify", "distributed": "distributed"}
            c.alignment = Alignment(horizontal=H.get(s.get("al"), s.get("al")) or None, wrap_text=bool(s.get("wrap")),
                                    vertical=V.get(s.get("va")), indent=int(s.get("ind") or 0),
                                    text_rotation=255 if s.get("vert") else (int(s.get("rot") or 0) if (s.get("rot") or 0) >= 0 else 90 - int(s["rot"])),
                                    shrink_to_fit=bool(s.get("shrink")), justifyLastLine=bool(s.get("jd")),
                                    readingOrder={"ltr": 1, "rtl": 2}.get(s.get("dir"), 0))
        nf = _nf_code(s["nf"]) if s.get("nf") else _numfmt(s.get("fmt"), s.get("dp"))
        if nf:
            c.number_format = nf
        if s.get("note"):
            c.comment = Comment(s["note"], "MBY Sheet")
        if s.get("bd"):
            c.border = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
        if any(s.get(k) for k in ("bt", "bb", "bl", "br")):
            c.border = Border(top=_side(s.get("bt")), bottom=_side(s.get("bb")), left=_side(s.get("bl")), right=_side(s.get("br")))
        if s.get("unlocked") or s.get("hid"):
            c.protection = Protection(locked=not s.get("unlocked"), hidden=bool(s.get("hid")))
        if (s.get("span") or 0) > 1:
            col, row = column_index_from_string(m.group(1)), int(m.group(2))
            merges.append(f"{key}:{get_column_letter(col + int(s['span']) - 1)}{row}")
    for col, px in (sheet.get("colW") or {}).items():
        ws.column_dimensions[get_column_letter(int(col))].width = round(float(px) / 7.0, 1)
    for row, px in (sheet.get("rowH") or {}).items():
        ws.row_dimensions[int(row)].height = round(float(px) * 0.75, 1)
    for m_ in sheet.get("merges") or []:
        merges.append(f"{get_column_letter(m_['c1'])}{m_['r1']}:{get_column_letter(m_['c2'])}{m_['r2']}")
    for rng in merges:
        try: ws.merge_cells(rng)
        except Exception: pass
    fr = sheet.get("freeze") or {"rows": 1, "cols": 0}
    if fr.get("rows") or fr.get("cols"):
        ws.freeze_panes = f"{get_column_letter(int(fr.get('cols') or 0) + 1)}{int(fr.get('rows') or 0) + 1}"
    _write_objects(ws, sheet)
    _write_cf(ws, sheet.get("cf") or [])
    pg = sheet.get("page") or {}
    ws.page_setup.orientation = "landscape" if pg.get("orient") == "landscape" else "portrait"
    ws.page_setup.paperSize = {"A4": 9, "A5": 11, "Letter": 1, "Legal": 5}.get(pg.get("paper") or "A4", 9)
    if pg.get("fit", True):
        ws.sheet_properties.pageSetUpPr.fitToPage = True; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.print_options.gridLines = bool(pg.get("grid"))
    m_ = {"narrow": 0.25, "wide": 1.0}.get(pg.get("margins"), 0.7)
    ws.page_margins.left = ws.page_margins.right = m_
    if sheet.get("protect"):
        ws.protection.sheet = True
    wb.properties.creator = "MBY Sheet"; wb.properties.keywords = MARK
    tmp = path + ".mby-tmp"
    wb.save(tmp); os.replace(tmp, path)          # never leave a half-written file


def _px_to_anchor(sheet, x, y):
    """pixel position on the sheet -> top-left cell (e.g. 'C5')"""
    colw = {int(k): float(v) for k, v in (sheet.get("colW") or {}).items()}
    rowh = {int(k): float(v) for k, v in (sheet.get("rowH") or {}).items()}
    cx, c = 56.0, 1
    while cx + colw.get(c, 110 if c == 1 else 96) <= x and c < 16000:
        cx += colw.get(c, 110 if c == 1 else 96); c += 1
    ry, r = 25.0, 1
    while ry + rowh.get(r, 24) <= y and r < 1000000:
        ry += rowh.get(r, 24); r += 1
    return f"{get_column_letter(c)}{r}"


def _write_objects(ws, sheet):
    for o in sheet.get("objects") or []:
        anchor = o.get("cell") or _px_to_anchor(sheet, float(o.get("x", 0)), float(o.get("y", 0)))
        try:
            if o.get("type") == "image" and str(o.get("src", "")).startswith("data:image"):
                data = base64.b64decode(o["src"].split(",", 1)[1])
                img = XLImage(io.BytesIO(data)); img.width, img.height = int(o.get("w", 200)), int(o.get("h", 150))
                ws.add_image(img, anchor)
            elif o.get("type") == "chart" and o.get("range"):
                c1, r1, c2, r2 = range_boundaries(o["range"])
                kind = o.get("kind", "col")
                ch = PieChart() if kind == "pie" else (LineChart() if kind == "line" else BarChart())
                if kind == "bar": ch.type = "bar"
                if kind == "col": ch.type = "col"
                ch.title = o.get("title") or None
                labels_col = c2 > c1
                data = Reference(ws, min_col=c1 + (1 if labels_col else 0), max_col=c2, min_row=r1, max_row=r2)
                ch.add_data(data, titles_from_data=True)
                if labels_col:
                    ch.set_categories(Reference(ws, min_col=c1, max_col=c1, min_row=r1 + 1, max_row=r2))
                ch.width, ch.height = float(o.get("w", 440)) / 37.8, float(o.get("h", 270)) / 37.8
                ws.add_chart(ch, anchor)
        except Exception:
            continue          # a broken picture never stops the save


def _write_cf(ws, rules):
    for r in rules:
        rng, col = r.get("range"), (r.get("color") or "#FDE68A").lstrip("#").upper()
        fill = PatternFill("solid", fgColor=col, bgColor=col)
        try:
            t = r.get("type")
            if t == "scale":
                ws.conditional_formatting.add(rng, ColorScaleRule(start_type="min", start_color="F8696B", mid_type="percentile", mid_value=50, mid_color="FFEB84", end_type="max", end_color="63BE7B"))
            elif t in ("gt", "lt", "eq", "between"):
                op = {"gt": "greaterThan", "lt": "lessThan", "eq": "equal", "between": "between"}[t]
                f = [str(r.get("v1"))] + ([str(r.get("v2"))] if t == "between" else [])
                f = [x if re.fullmatch(r"-?\d+(\.\d+)?", x) else f'"{x}"' for x in f]
                ws.conditional_formatting.add(rng, CellIsRule(operator=op, formula=f, fill=fill))
            elif t == "text":
                first = rng.split(":")[0]
                ws.conditional_formatting.add(rng, FormulaRule(formula=[f'NOT(ISERROR(SEARCH("{r.get("v1")}",{first})))'], fill=fill))
            elif t == "dup":
                first = rng.split(":")[0]; a = re.sub(r"([A-Z]+)(\d+)", r"$\1$\2", rng)
                ws.conditional_formatting.add(rng, FormulaRule(formula=[f"COUNTIF({a},{first})>1"], fill=fill))
        except Exception:
            continue


def write_csv(sheet, path):
    if sheet.get("values"):                    # results as shown on screen (formulas calculated)
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerows(sheet["values"])
        return
    cells = sheet.get("cells", {})
    rows = cols = 0
    for k in cells:
        m = REF.match(k)
        if m and cells[k].get("v", "") != "":
            cols = max(cols, column_index_from_string(m.group(1))); rows = max(rows, int(m.group(2)))
    with open(path, "w", newline="", encoding="utf-8-sig") as f:      # BOM: Excel opens Arabic/Malayalam correctly
        w = csv.writer(f)
        for r in range(1, rows + 1):
            w.writerow([(cells.get(f"{get_column_letter(c)}{r}") or {}).get("v", "") for c in range(1, cols + 1)])


def _fmt_from(number_format):
    nf = number_format or ""
    if "BD" in nf or "BHD" in nf: return "BHD"
    if "₹" in nf: return "INR"
    if "SAR" in nf: return "SAR"
    if "$" in nf: return "USD"
    if "%" in nf: return "pct"
    if nf in ("#,##0.00", "0.00"): return "num2"
    return None


def read_file(path):
    """returns (sheet, own): own=True when MBY Sheet wrote the file and may auto-save over it"""
    name = os.path.splitext(os.path.basename(path))[0]
    if name.lower().endswith(".mby"): name = name[:-4]      # "New MBY Sheet.mby.xlsx" -> "New MBY Sheet"
    if path.lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            sample = f.read(4096); f.seek(0)
            try: dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            except csv.Error: dialect = csv.excel
            data = list(csv.reader(f, dialect))
        cells = {}
        for r, row in enumerate(data, 1):
            for c, v in enumerate(row, 1):
                if v != "": cells[f"{get_column_letter(c)}{r}"] = {"v": v}
        cols = max((len(r) for r in data), default=1)
        return {"name": name, "rows": len(data) + 20, "cols": cols + 2, "cells": cells, "colW": {}, "rowH": {}}, False

    wb = load_workbook(path)                     # formulas stay formulas
    ws = wb.active
    cells = {}
    for row in ws.iter_rows():
        for c in row:
            if c.value is None and not (c.fill and c.fill.fgColor and c.fill.fill_type == "solid"):
                continue
            v = c.value
            if isinstance(v, (datetime.datetime, datetime.date)):
                v = v.strftime("%d/%m/%Y")
            elif isinstance(v, bool):
                v = "TRUE" if v else "FALSE"
            elif isinstance(v, float) and v.is_integer():
                v = str(int(v))
            elif v is None:
                v = ""
            else:
                v = str(v)
            s = {}
            if c.font is not None:
                if c.font.b: s["b"] = 1
                if c.font.i: s["i"] = 1
                col = c.font.color.rgb if c.font.color is not None and isinstance(c.font.color.rgb, str) else None
                if col and col not in ("FF000000", "00000000"): s["fg"] = "#" + col[-6:].lower()
            if c.fill is not None and c.fill.fill_type == "solid" and isinstance(c.fill.fgColor.rgb, str) and c.fill.fgColor.rgb not in ("00000000",):
                s["bg"] = "#" + c.fill.fgColor.rgb[-6:].lower()
            if c.alignment is not None and c.alignment.horizontal in ("left", "center", "right", "fill", "justify", "distributed", "centerContinuous"):
                s["al"] = {"centerContinuous": "centerAcross"}.get(c.alignment.horizontal, c.alignment.horizontal)
            a_ = c.alignment
            if a_ is not None:
                tr = int(a_.text_rotation or 0)
                if tr == 255: s["vert"] = 1
                elif 0 < tr <= 90: s["rot"] = tr
                elif 90 < tr <= 180: s["rot"] = 90 - tr
                if a_.shrink_to_fit: s["shrink"] = 1
                if a_.justifyLastLine: s["jd"] = 1
                if int(a_.readingOrder or 0) in (1, 2): s["dir"] = {1: "ltr", 2: "rtl"}[int(a_.readingOrder)]
            if c.alignment is not None and c.alignment.wrap_text:
                s["wrap"] = 1
            if c.font is not None and c.font.name and c.font.name != "Calibri":
                s["ff"] = c.font.name
            if c.font is not None and c.font.sz and float(c.font.sz) != 11:
                s["fz"] = float(c.font.sz)
            m = re.search(r"0\.(0+)", c.number_format or "")
            if m and _fmt_from(c.number_format) and len(m.group(1)) != {"BHD": 3}.get(_fmt_from(c.number_format), 2):
                s["dp"] = len(m.group(1))
            if c.comment is not None and c.comment.text:
                s["note"] = c.comment.text
            f = _fmt_from(c.number_format)
            if f and not (c.number_format or "").count(";") and "[" not in (c.number_format or ""): s["fmt"] = f
            else:
                nfx = _nf_from(c.number_format)
                if nfx: s["nf"] = nfx
            if c.font is not None and c.font.u: s["u"] = 1
            if c.font is not None and c.font.strike: s["st"] = 1
            if c.alignment is not None and c.alignment.vertical in ("center", "top", "justify", "distributed"): s["va"] = {"center": "middle"}.get(c.alignment.vertical, c.alignment.vertical)
            if c.alignment is not None and c.alignment.indent: s["ind"] = int(c.alignment.indent)
            if c.protection is not None and c.protection.locked is False: s["unlocked"] = 1
            if c.protection is not None and c.protection.hidden: s["hid"] = 1
            if c.border is not None:
                for k, side in (("bt", c.border.top), ("bb", c.border.bottom), ("bl", c.border.left), ("br", c.border.right)):
                    v_ = _css(side)
                    if v_: s[k] = v_
            o = {"v": v}
            if s: o["s"] = s
            if v != "" or s: cells[c.coordinate] = o
    colw = {}
    for letter, dim in ws.column_dimensions.items():
        if dim.width:
            try: colw[str(column_index_from_string(letter))] = int(dim.width * 7)
            except ValueError: pass
    rowh = {str(r): int(d.height / 0.75) for r, d in ws.row_dimensions.items() if d.height}
    own = (wb.properties.keywords or "") == MARK
    merges = [{"c1": mr.min_col, "r1": mr.min_row, "c2": mr.max_col, "r2": mr.max_row} for mr in ws.merged_cells.ranges]
    fr = {"rows": 0, "cols": 0}
    if ws.freeze_panes:
        m_ = re.match(r"([A-Z]+)(\d+)", ws.freeze_panes)
        if m_: fr = {"rows": int(m_.group(2)) - 1, "cols": column_index_from_string(m_.group(1)) - 1}
    page = {"orient": "landscape" if ws.page_setup.orientation == "landscape" else "portrait",
            "paper": {9: "A4", 11: "A5", 1: "Letter", 5: "Legal"}.get(int(ws.page_setup.paperSize or 9), "A4"),
            "fit": bool(ws.sheet_properties.pageSetUpPr and ws.sheet_properties.pageSetUpPr.fitToPage), "grid": bool(ws.print_options.gridLines), "margins": "normal"}
    objects = []
    for i, im in enumerate(getattr(ws, "_images", [])):
        try:
            raw_ = im._data()
            mime = "image/png" if raw_[:4] == b"\x89PNG" else "image/jpeg"
            fr_ = im.anchor._from
            x = 56 + sum(colw.get(str(c), 110 if c == 1 else 96) for c in range(1, fr_.col + 1))
            y = 25 + sum(rowh.get(str(r), 24) for r in range(1, fr_.row + 1))
            w_, h_ = int(im.width or 200), int(im.height or 150)
            ext = getattr(im.anchor, "ext", None)
            if ext is not None and getattr(ext, "width", None):          # size shown in Excel (EMU -> px)
                w_, h_ = int(ext.width / 9525), int(ext.height / 9525)
            objects.append({"id": f"x{i}", "type": "image", "src": f"data:{mime};base64," + base64.b64encode(raw_).decode(),
                            "x": x, "y": y, "w": w_, "h": h_})
        except Exception:
            continue
    return {"name": name, "rows": (ws.max_row or 1) + 20, "cols": (ws.max_column or 1) + 2,
            "cells": cells, "colW": colw, "rowH": rowh, "freeze": fr, "page": page, "objects": objects,
            "protect": bool(ws.protection.sheet), "merges": merges}, own
