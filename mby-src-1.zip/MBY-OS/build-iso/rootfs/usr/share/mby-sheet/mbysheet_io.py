"""MBY Sheet file input/output: .xlsx (Excel, via openpyxl) and .csv.

Sheet format shared with the page (app.js):
  {"name": str, "rows": int, "cols": int,
   "cells": {"A1": {"v": "text or =formula", "s": {"b":1,"i":1,"fg":"#rrggbb","bg":"#rrggbb","al":"left|center|right","fmt":"BHD|INR|SAR|USD|num2|pct","bd":1}}},
   "colW": {"1": px}, "rowH": {"1": px}}
"""
import csv, os, re, datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import column_index_from_string, get_column_letter

MARK = "Made with MBY Sheet"
NUMFMT = {
    "BHD": '#,##0.000 "BD"', "INR": '"₹"#,##,##0.00', "SAR": '#,##0.00 "SAR"',
    "USD": '"$"#,##0.00', "num2": "#,##0.00", "pct": "0.00%",
}
THIN = Side(style="thin", color="444444")
REF = re.compile(r"^([A-Z]{1,3})(\d+)$")


def _hex(c):
    return c.lstrip("#").upper().rjust(6, "0")[-6:] if c else None


def _number(v):
    """typed text -> number when it looks like one (so Excel can calculate with it)"""
    s = v.strip()
    digits = re.sub(r"\D", "", s)
    if re.fullmatch(r"0\d+", s) or (s.isdigit() and len(s) >= 12):
        return None              # barcodes / phone numbers: keep as text (leading zeros, all digits)
    if re.fullmatch(r"[-+]?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?([eE][+-]?\d+)?", s):
        n = float(s.replace(",", ""))
        return int(n) if n.is_integer() and "." not in s and "e" not in s.lower() else n
    if re.fullmatch(r"[-+]?\d+(\.\d+)?%", s):
        return float(s[:-1]) / 100
    return None


def write_xlsx(sheet, path):
    wb = Workbook(); ws = wb.active
    ws.title = re.sub(r"[\[\]:*?/\\]", "-", (sheet.get("name") or "Sheet"))[:31] or "Sheet"
    for key, o in sheet.get("cells", {}).items():
        m = REF.match(key)
        if not m: continue
        c = ws[key]
        v = o.get("v", "")
        if isinstance(v, str) and v.startswith("=") and len(v) > 1:
            c.value = v
        elif isinstance(v, str):
            n = _number(v)
            c.value = n if n is not None else (v if v != "" else None)
        else:
            c.value = v
        s = o.get("s") or {}
        if s.get("b") or s.get("i") or s.get("fg"):
            c.font = Font(bold=bool(s.get("b")), italic=bool(s.get("i")), color=_hex(s.get("fg")))
        if s.get("bg"):
            c.fill = PatternFill("solid", fgColor=_hex(s["bg"]))
        if s.get("al"):
            c.alignment = Alignment(horizontal=s["al"])
        if s.get("fmt") in NUMFMT:
            c.number_format = NUMFMT[s["fmt"]]
        if s.get("bd"):
            c.border = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
    for col, px in (sheet.get("colW") or {}).items():
        ws.column_dimensions[get_column_letter(int(col))].width = round(float(px) / 7.0, 1)
    for row, px in (sheet.get("rowH") or {}).items():
        ws.row_dimensions[int(row)].height = round(float(px) * 0.75, 1)
    ws.freeze_panes = "A2"                       # header row stays visible in Excel too
    wb.properties.creator = "MBY Sheet"; wb.properties.keywords = MARK
    tmp = path + ".mby-tmp"
    wb.save(tmp); os.replace(tmp, path)          # never leave a half-written file


def write_csv(sheet, path):
    if sheet.get("values"):                    # results as shown on screen (formulas calculated)
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerows(sheet["values"])
        return
    cells = sheet.get("cells", {})
    rows = cols = 0
    for k in cells:
        m = REF.match(k)
        if m and cells[k].get("v", "") != "":
            cols = max(cols, column_index_from_string(m.group(1))); rows = max(rows, int(m.group(2)))
    with open(path, "w", newline="", encoding="utf-8-sig") as f:      # BOM: Excel opens Arabic/Malayalam correctly
        w = csv.writer(f)
        for r in range(1, rows + 1):
            w.writerow([(cells.get(f"{get_column_letter(c)}{r}") or {}).get("v", "") for c in range(1, cols + 1)])


def _fmt_from(number_format):
    nf = number_format or ""
    if "BD" in nf or "BHD" in nf: return "BHD"
    if "₹" in nf: return "INR"
    if "SAR" in nf: return "SAR"
    if "$" in nf: return "USD"
    if "%" in nf: return "pct"
    if nf in ("#,##0.00", "0.00"): return "num2"
    return None


def read_file(path):
    """returns (sheet, own): own=True when MBY Sheet wrote the file and may auto-save over it"""
    name = os.path.splitext(os.path.basename(path))[0]
    if path.lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            sample = f.read(4096); f.seek(0)
            try: dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            except csv.Error: dialect = csv.excel
            data = list(csv.reader(f, dialect))
        cells = {}
        for r, row in enumerate(data, 1):
            for c, v in enumerate(row, 1):
                if v != "": cells[f"{get_column_letter(c)}{r}"] = {"v": v}
        cols = max((len(r) for r in data), default=1)
        return {"name": name, "rows": len(data) + 20, "cols": cols + 2, "cells": cells, "colW": {}, "rowH": {}}, False

    wb = load_workbook(path)                     # formulas stay formulas
    ws = wb.active
    cells = {}
    for row in ws.iter_rows():
        for c in row:
            if c.value is None and not (c.fill and c.fill.fgColor and c.fill.fill_type == "solid"):
                continue
            v = c.value
            if isinstance(v, (datetime.datetime, datetime.date)):
                v = v.strftime("%d/%m/%Y")
            elif isinstance(v, bool):
                v = "TRUE" if v else "FALSE"
            elif isinstance(v, float) and v.is_integer():
                v = str(int(v))
            elif v is None:
                v = ""
            else:
                v = str(v)
            s = {}
            if c.font is not None:
                if c.font.b: s["b"] = 1
                if c.font.i: s["i"] = 1
                col = c.font.color.rgb if c.font.color is not None and isinstance(c.font.color.rgb, str) else None
                if col and col not in ("FF000000", "00000000"): s["fg"] = "#" + col[-6:]
            if c.fill is not None and c.fill.fill_type == "solid" and isinstance(c.fill.fgColor.rgb, str) and c.fill.fgColor.rgb not in ("00000000",):
                s["bg"] = "#" + c.fill.fgColor.rgb[-6:]
            if c.alignment is not None and c.alignment.horizontal in ("left", "center", "right"):
                s["al"] = c.alignment.horizontal
            f = _fmt_from(c.number_format)
            if f: s["fmt"] = f
            if c.border is not None and c.border.left is not None and c.border.left.style:
                s["bd"] = 1
            o = {"v": v}
            if s: o["s"] = s
            if v != "" or s: cells[c.coordinate] = o
    colw = {}
    for letter, dim in ws.column_dimensions.items():
        if dim.width:
            try: colw[str(column_index_from_string(letter))] = int(dim.width * 7)
            except ValueError: pass
    rowh = {str(r): int(d.height / 0.75) for r, d in ws.row_dimensions.items() if d.height}
    own = (wb.properties.keywords or "") == MARK
    return {"name": name, "rows": (ws.max_row or 1) + 20, "cols": (ws.max_column or 1) + 2,
            "cells": cells, "colW": colw, "rowH": rowh}, own
