/* MBY Sheet - a simple spreadsheet for everyday shop work.
 * The grid, editing, resizing, drag-to-move, sort/filter/find and formatting live here.
 * Opening and saving files (.xlsx / .csv) is done by the host program (mby-sheet, Python),
 * which talks to this page through window.webkit.messageHandlers.mby. */
"use strict";
const F = window.MBYFormula;
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

// ------------------------------------------------------------------ state
let S = blankSheet();
let cur = { c: 1, r: 1 }, anchor = { c: 1, r: 1 };
let undoStack = [], redoStack = [];
let engine = null, dirty = false, filtersOn = false, filters = {};
let editing = null;           // {c, r, input, fromBar}
let hostPath = "";            // file this sheet is saved to (set by host)

function blankSheet(rows = 100, cols = 12) {
  return { name: "Untitled", rows, cols, cells: {}, colW: {}, rowH: {} };
}
const ref = (c, r) => F.numToCol(c) + r;
const cell = (c, r) => S.cells[ref(c, r)];
const raw = (c, r) => (cell(c, r) || {}).v ?? "";
const style = (c, r) => (cell(c, r) || {}).s || {};
const colW = c => S.colW[c] || (c === 1 ? 110 : 96);
const rowH = r => S.rowH[r] || 24;

// ------------------------------------------------------------------ host bridge
const host = {
  post(msg) {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mby;
    if (h) h.postMessage(JSON.stringify(msg));
    else if (msg.cmd === "save" || msg.cmd === "autosave") { localStorage.setItem("mby-sheet", JSON.stringify(msg.sheet)); setSaved("Saved (browser)"); }
  }
};
window.MBY = {
  receive(msg) {
    if (msg.cmd === "load") {
      S = Object.assign(blankSheet(), msg.sheet); hostPath = msg.path || "";
      S.rows = Math.max(S.rows, 100); S.cols = Math.max(S.cols, 12);
      undoStack = []; redoStack = []; dirty = false; filters = {}; filtersOn = false;
      $("#start").hidden = true; cur = { c: 1, r: 2 }; anchor = { ...cur };
      render(); setSaved(msg.path ? "Opened" : "");
    } else if (msg.cmd === "saved") { hostPath = msg.path || hostPath; if (msg.name) S.name = msg.name; dirty = false; setSaved("Saved ✓"); updateTitle(); }
    else if (msg.cmd === "error") { setSaved("⚠ " + msg.text); alertBox(msg.text); }
    else if (msg.cmd === "start") { $("#start").hidden = false; }
    else if (msg.cmd === "save") { save(false); }
  }
};
function alertBox(t) { setTimeout(() => window.alert(t), 10); }
function setSaved(t) { $("#savestate").textContent = t; }
function updateTitle() { $("#docname").textContent = S.name + (dirty ? " •" : ""); document.title = S.name + " - MBY Sheet"; }

// ------------------------------------------------------------------ values & formatting
function newEngine() {
  const get = r => (S.cells[r] || {}).v ?? "";
  get.maxRow = () => S.rows;
  engine = F.makeEngine(get);
}
function display(c, r) {
  const v = engine.value(ref(c, r));
  if (F.isErr(v)) return { t: v.err, err: true, num: false };
  if (typeof v === "boolean") return { t: v ? "TRUE" : "FALSE", num: false };
  if (typeof v === "number") return { t: fmtNum(v, style(c, r).fmt), num: true };
  return { t: v, num: false };
}
function fmtNum(n, f) {
  const loc = (x, d, l = "en-US") => x.toLocaleString(l, { minimumFractionDigits: d, maximumFractionDigits: d });
  switch (f) {
    case "BHD": return loc(n, 3) + " BD";
    case "INR": return "₹" + loc(n, 2, "en-IN");
    case "SAR": return loc(n, 2) + " SAR";
    case "USD": return (n < 0 ? "-$" : "$") + loc(Math.abs(n), 2);
    case "num2": return loc(n, 2);
    case "pct": return loc(n * 100, 2) + "%";
    default: return Number.isInteger(n) ? String(n) : String(+n.toPrecision(12));
  }
}

// ------------------------------------------------------------------ rendering
function render() {
  newEngine();
  const g = $("#grid");
  let h = "<colgroup><col style='width:56px'>";
  for (let c = 1; c <= S.cols; c++) h += `<col data-c="${c}" style="width:${colW(c)}px">`;
  h += "</colgroup><thead><tr><th class='corner'></th>";
  for (let c = 1; c <= S.cols; c++) h += `<th data-c="${c}" title="Drag to move this column"><div class="hd">${F.numToCol(c)}<span class="cw" data-c="${c}"></span></div></th>`;
  h += "</tr></thead><tbody>";
  if (filtersOn) {
    h += "<tr class='filters'><th></th>";
    for (let c = 1; c <= S.cols; c++) h += `<td><input data-fc="${c}" placeholder="filter" value="${esc(filters[c] || "")}"></td>`;
    h += "</tr>";
  }
  for (let r = 1; r <= S.rows; r++) {
    h += `<tr data-r="${r}" class="${r === 1 ? "r1" : ""}" style="height:${rowH(r)}px"><th data-r="${r}"><div class="hd"><span class="handle" data-r="${r}" title="Drag to move this row">⠿</span>${r}<span class="rh" data-r="${r}"></span></div></th>`;
    for (let c = 1; c <= S.cols; c++) h += `<td data-c="${c}" data-r="${r}"></td>`;
    h += "</tr>";
  }
  g.innerHTML = h + "</tbody>";
  paintAll(); applyFilters(); select(cur.c, cur.r, true); updateTitle();
}
function esc(s) { return String(s).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch])); }
function td(c, r) { return document.querySelector(`#grid td[data-c="${c}"][data-r="${r}"]`); }
function paintCell(el, c, r) {
  const d = display(c, r), s = style(c, r);
  el.textContent = d.t;
  el.className = (d.num ? "num" : "") + (d.err ? " err" : "") + (s.bd ? " b-all" : "");
  el.style.fontWeight = s.b ? "700" : ""; el.style.fontStyle = s.i ? "italic" : "";
  el.style.color = s.fg || ""; el.style.background = s.bg || "";
  el.style.textAlign = s.al || "";
}
function paintAll() {
  newEngine();
  for (const el of $$("#grid td[data-c]")) paintCell(el, +el.dataset.c, +el.dataset.r);
  markSelection(); stats();
}

// ------------------------------------------------------------------ selection
function rangeBox() {
  return { c1: Math.min(anchor.c, cur.c), c2: Math.max(anchor.c, cur.c), r1: Math.min(anchor.r, cur.r), r2: Math.max(anchor.r, cur.r) };
}
function select(c, r, keepAnchor) {
  c = Math.max(1, Math.min(c, S.cols)); r = Math.max(1, r);
  if (r > S.rows - 5) { S.rows += 50; render(); }
  cur = { c, r }; if (!keepAnchor) anchor = { c, r };
  markSelection(); stats();
  $("#addr").textContent = ref(c, r);
  if (!editing || !editing.fromBar) $("#formula").value = raw(c, r);
  $("#numfmt").value = style(c, r).fmt || "";
  const el = td(c, r); if (el) el.scrollIntoView({ block: "nearest", inline: "nearest" });
}
function markSelection() {
  const b = rangeBox();
  for (const el of $$("#grid td.sel, #grid td.cur")) el.classList.remove("sel", "cur");
  for (const el of $$("#grid th.selh")) el.classList.remove("selh");
  const multi = b.c1 !== b.c2 || b.r1 !== b.r2;
  if (multi) for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) { const el = td(c, r); if (el) el.classList.add("sel"); }
  const el = td(cur.c, cur.r); if (el) el.classList.add("cur");
  for (let c = b.c1; c <= b.c2; c++) { const h = document.querySelector(`#grid thead th[data-c="${c}"]`); if (h) h.classList.add("selh"); }
  for (let r = b.r1; r <= b.r2; r++) { const h = document.querySelector(`#grid tbody th[data-r="${r}"]`); if (h) h.classList.add("selh"); }
}
function stats() {
  const b = rangeBox(); let sum = 0, n = 0, cnt = 0;
  for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) {
    const v = engine.value(ref(c, r)); if (v !== "" && v != null) cnt++;
    if (typeof v === "number") { sum += v; n++; }
  }
  const f = style(cur.c, cur.r).fmt;
  $("#stat").textContent = (b.c1 === b.c2 && b.r1 === b.r2) ? ref(cur.c, cur.r) :
    `Sum: ${fmtNum(sum, f)}   Average: ${n ? fmtNum(sum / n, f) : "-"}   Count: ${cnt}`;
}

// ------------------------------------------------------------------ changes + undo
function snapshot() { return JSON.stringify({ cells: S.cells, colW: S.colW, rowH: S.rowH, rows: S.rows, cols: S.cols }); }
function restore(j) { Object.assign(S, JSON.parse(j)); render(); }
function change(fn, full) {
  undoStack.push(snapshot()); if (undoStack.length > 200) undoStack.shift(); redoStack = [];
  fn(); dirty = true; updateTitle(); setSaved("Editing…");
  if (full) render(); else paintAll();
  scheduleAutosave();
}
function undo() { if (!undoStack.length) return; redoStack.push(snapshot()); restore(undoStack.pop()); dirty = true; scheduleAutosave(); }
function redo() { if (!redoStack.length) return; undoStack.push(snapshot()); restore(redoStack.pop()); dirty = true; scheduleAutosave(); }
function setRaw(c, r, v) {
  const k = ref(c, r);
  if (v === "" && !(S.cells[k] && S.cells[k].s)) { delete S.cells[k]; return; }
  S.cells[k] = Object.assign({}, S.cells[k], { v });
  if (c > S.cols - 1) S.cols = c + 2;
}
function eachSel(fn) { const b = rangeBox(); for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) fn(c, r); }
function setStyle(fn) {
  change(() => eachSel((c, r) => { const k = ref(c, r); const o = S.cells[k] || { v: "" }; o.s = Object.assign({}, o.s); fn(o.s); if (!Object.keys(o.s).length) delete o.s; S.cells[k] = o; }));
}

// ------------------------------------------------------------------ editing
function startEdit(initial, fromBar) {
  if (editing) return;
  const el = td(cur.c, cur.r); if (!el) return;
  const wrap = $("#wrap"), rc = el.getBoundingClientRect(), wr = wrap.getBoundingClientRect();
  const inp = document.createElement("input"); inp.id = "editor"; inp.spellcheck = false;
  inp.style.left = (rc.left - wr.left + wrap.scrollLeft) + "px"; inp.style.top = (rc.top - wr.top + wrap.scrollTop) + "px";
  inp.style.width = Math.max(rc.width, 120) + "px"; inp.style.height = rc.height + "px";
  inp.value = initial != null ? initial : raw(cur.c, cur.r);
  wrap.appendChild(inp);
  editing = { c: cur.c, r: cur.r, input: inp, fromBar: !!fromBar };
  if (!fromBar) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
  inp.addEventListener("input", () => { $("#formula").value = inp.value; });
  inp.addEventListener("blur", () => { if (editing && editing.input === inp && !editing.fromBar) commit(0, 0); });
}
function commit(dc, dr) {
  if (!editing) return;
  const { c, r, input } = editing; const v = editing.fromBar ? $("#formula").value : input.value;
  editing = null; input.remove();
  if (v !== raw(c, r)) change(() => setRaw(c, r, v));
  select(c + dc, r + dr);
}
function cancelEdit() { if (!editing) return; editing.input.remove(); editing = null; select(cur.c, cur.r); }

// ------------------------------------------------------------------ rows / columns: move, insert, delete
function remapAll(fn, keepRanges) {  // fn(c, r) -> [c, r] | null for every reference & cell
  const cells = {};
  for (const [k, o] of Object.entries(S.cells)) {
    const p = F.parseRef(k); const to = fn(p.c, p.r);
    if (!to) continue;
    cells[ref(to[0], to[1])] = Object.assign({}, o, { v: F.remapFormula(o.v, fn, keepRanges) });
  }
  S.cells = cells;
}
function permuteRows(order) {        // order[newIndex-1] = oldRow
  const map = {}; order.forEach((old, i) => { map[old] = i + 1; });
  const rh = {}; for (const [r, h] of Object.entries(S.rowH)) rh[map[r] || r] = h; S.rowH = rh;
  remapAll((c, r) => [c, map[r] || r], true);
}
function permuteCols(order) {
  const map = {}; order.forEach((old, i) => { map[old] = i + 1; });
  const cw = {}; for (const [c, w] of Object.entries(S.colW)) cw[map[c] || c] = w; S.colW = cw;
  remapAll((c, r) => [map[c] || c, r], true);
}
function moveRow(from, to) {
  if (from === to || to < 1) return;
  const order = []; for (let r = 1; r <= S.rows; r++) order.push(r);
  order.splice(from - 1, 1); order.splice(to > from ? to - 2 : to - 1, 0, from);
  change(() => permuteRows(order), true);
  select(cur.c, order.indexOf(from) + 1);
}
function moveCol(from, to) {
  if (from === to || to < 1) return;
  const order = []; for (let c = 1; c <= S.cols; c++) order.push(c);
  order.splice(from - 1, 1); order.splice(to > from ? to - 2 : to - 1, 0, from);
  change(() => permuteCols(order), true);
  select(order.indexOf(from) + 1, cur.r);
}
function insertRow(at) { change(() => { S.rows++; const rh = {}; for (const [r, h] of Object.entries(S.rowH)) rh[+r >= at ? +r + 1 : r] = h; S.rowH = rh; remapAll((c, r) => [c, r >= at ? r + 1 : r]); }, true); }
function deleteRow(at) { change(() => { const rh = {}; for (const [r, h] of Object.entries(S.rowH)) if (+r !== at) rh[+r > at ? +r - 1 : r] = h; S.rowH = rh; remapAll((c, r) => r === at ? null : [c, r > at ? r - 1 : r]); }, true); }
function insertCol(at) { change(() => { S.cols++; const cw = {}; for (const [c, w] of Object.entries(S.colW)) cw[+c >= at ? +c + 1 : c] = w; S.colW = cw; remapAll((c, r) => [c >= at ? c + 1 : c, r]); }, true); }
function deleteCol(at) { change(() => { const cw = {}; for (const [c, w] of Object.entries(S.colW)) if (+c !== at) cw[+c > at ? +c - 1 : c] = w; S.colW = cw; remapAll((c, r) => c === at ? null : [c > at ? c - 1 : c, r]); }, true); }

// ------------------------------------------------------------------ sort / filter / find
function lastRow() { let m = 1; for (const k of Object.keys(S.cells)) { const p = F.parseRef(k); if (S.cells[k].v !== "" && p.r > m) m = p.r; } return m; }
function isTotalRow(r) {
  for (let c = 1; c <= S.cols; c++) { const v = String(raw(c, r)); if (/^=\s*SUM\(/i.test(v) || /^(grand )?total:?$/i.test(v.trim())) return true; }
  return false;
}
function dataEnd() {                 // last row with real (typed) data, above any TOTAL row
  let last = 1;
  for (let r = 2; r <= S.rows; r++) {
    if (isTotalRow(r)) break;
    for (let c = 1; c <= S.cols; c++) { const v = raw(c, r); if (v !== "" && !String(v).startsWith("=")) { last = r; break; } }
  }
  return last;
}
function sortBy(col, dir) {
  const last = dataEnd(); if (last < 3) return;
  const rows = []; for (let r = 2; r <= last; r++) rows.push(r);
  const key = r => { const v = engine.value(ref(col, r)); return v === "" ? null : v; };
  rows.sort((a, b) => {
    const x = key(a), y = key(b);
    if (x === null && y === null) return a - b; if (x === null) return 1; if (y === null) return -1;
    if (typeof x === "number" && typeof y === "number") return dir * (x - y) || a - b;
    return dir * String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: "base" }) || a - b;
  });
  const order = [1, ...rows]; for (let r = last + 1; r <= S.rows; r++) order.push(r);
  change(() => permuteRows(order), true);
}
function applyFilters() {
  const active = Object.entries(filters).filter(([, t]) => t);
  for (const tr of $$("#grid tbody tr[data-r]")) {
    const r = +tr.dataset.r;
    let show = r === 1 || !active.length;
    if (!show) show = active.every(([c, t]) => display(+c, r).t.toLowerCase().includes(t.toLowerCase()));
    tr.classList.toggle("hidden", !show);
  }
}
let findHits = [], findPos = -1;
function doFind() {
  const t = $("#findtxt").value.trim().toLowerCase();
  for (const el of $$("#grid td.found")) el.classList.remove("found");
  findHits = []; findPos = -1;
  if (!t) { $("#findinfo").textContent = ""; return; }
  for (let r = 1; r <= S.rows; r++) for (let c = 1; c <= S.cols; c++) if (display(c, r).t.toLowerCase().includes(t)) { findHits.push([c, r]); const el = td(c, r); if (el) el.classList.add("found"); }
  $("#findinfo").textContent = findHits.length ? `${findHits.length} found` : "Not found";
  findNext();
}
function findNext() { if (!findHits.length) return; findPos = (findPos + 1) % findHits.length; const [c, r] = findHits[findPos]; select(c, r); $("#findinfo").textContent = `${findPos + 1} of ${findHits.length}`; }

// ------------------------------------------------------------------ copy / paste
function selectionTSV() { const b = rangeBox(); const lines = []; for (let r = b.r1; r <= b.r2; r++) { const row = []; for (let c = b.c1; c <= b.c2; c++) row.push(display(c, r).t); lines.push(row.join("\t")); } return lines.join("\n"); }
let clipRaw = null;
function copySel(cut) {
  const b = rangeBox(); clipRaw = { b, cells: [] };
  for (let r = b.r1; r <= b.r2; r++) { const row = []; for (let c = b.c1; c <= b.c2; c++) row.push(Object.assign({}, cell(c, r))); clipRaw.cells.push(row); }
  clipRaw.text = selectionTSV();
  const ta = document.createElement("textarea"); ta.value = clipRaw.text; document.body.appendChild(ta); ta.select();
  try { document.execCommand("copy"); } catch (e) {} ta.remove();
  if (cut) change(() => eachSel((c, r) => setRaw(c, r, "")));
  setSaved(cut ? "Cut" : "Copied");
}
function pasteText(text) {
  if (clipRaw && text === clipRaw.text) {          // inside MBY Sheet: keep formulas & formats, shift references
    const dc = cur.c - clipRaw.b.c1, dr = cur.r - clipRaw.b.r1;
    change(() => clipRaw.cells.forEach((row, i) => row.forEach((o, j) => {
      const v = F.remapFormula(o.v ?? "", (c, r) => [c + dc, r + dr]);
      S.cells[ref(cur.c + j, cur.r + i)] = Object.assign({}, o, { v });
    })), true);
    return;
  }
  const rows = text.replace(/\r/g, "").replace(/\n$/, "").split("\n").map(l => l.split("\t"));
  change(() => rows.forEach((row, i) => row.forEach((v, j) => setRaw(cur.c + j, cur.r + i, v))), true);
}

// ------------------------------------------------------------------ autofit
const measureCtx = document.createElement("canvas").getContext("2d");
function autofit(c) {
  measureCtx.font = "13px Inter, Cantarell, sans-serif"; let w = 40;
  for (let r = 1; r <= S.rows; r++) { const t = display(c, r).t; if (t) { measureCtx.font = (style(c, r).b || r === 1 ? "700 " : "") + "13px Inter, Cantarell, sans-serif"; w = Math.max(w, measureCtx.measureText(t).width + 16); } }
  S.colW[c] = Math.min(Math.ceil(w), 480);
}

// ------------------------------------------------------------------ templates
const TPL = {
  blank: () => blankSheet(),
  products: () => tpl("Product list", ["Barcode", "Product", "Price (BD)", "Qty", "Total (BD)"], [130, 220, 100, 70, 110],
    r => ({ E: `=IF(D${r}="","",C${r}*D${r})` }), { C: "BHD", E: "BHD" }, "E"),
  sales: () => tpl("Daily sales", ["Date", "Bill no.", "Cash (BD)", "Card (BD)", "Total (BD)"], [110, 90, 110, 110, 120],
    r => ({ E: `=IF(AND(C${r}="",D${r}=""),"",C${r}+D${r})` }), { C: "BHD", D: "BHD", E: "BHD" }, "E"),
  expenses: () => tpl("Expenses", ["Date", "Item", "Category", "Amount (BD)"], [110, 220, 140, 120], () => ({}), { D: "BHD" }, "D"),
};
function tpl(name, heads, widths, perRow, fmts, totalCol) {
  const s = blankSheet(); s.name = name;
  heads.forEach((h, i) => { s.cells[ref(i + 1, 1)] = { v: h, s: { b: true, bg: "#dcfce7" } }; s.colW[i + 1] = widths[i]; });
  const lastData = 40;
  for (let r = 2; r <= lastData; r++) {
    for (const [col, f] of Object.entries(perRow(r))) s.cells[col + r] = { v: f, s: { fmt: fmts[col] } };
    for (const [col, f] of Object.entries(fmts)) if (!s.cells[col + r]) s.cells[col + r] = { v: "", s: { fmt: f } };
  }
  const tr = lastData + 1, tc = F.colToNum(totalCol);
  s.cells[ref(tc - 1, tr)] = { v: "TOTAL", s: { b: true, al: "right" } };
  s.cells[ref(tc, tr)] = { v: `=SUM(${totalCol}2:${totalCol}${lastData})`, s: { b: true, fmt: fmts[totalCol], bg: "#fef9c3", bd: true } };
  return s;
}
function startWith(name) {
  S = TPL[name](); hostPath = ""; undoStack = []; redoStack = []; dirty = false; filters = {}; filtersOn = false;
  $("#start").hidden = true; cur = { c: 1, r: 2 }; anchor = { ...cur }; render();
  host.post({ cmd: "new", name: S.name });
}

// ------------------------------------------------------------------ save / autosave
function sheetForSave() { return { name: S.name, rows: lastRow(), cols: S.cols, cells: S.cells, colW: S.colW, rowH: S.rowH }; }
function save(asNew) { if (editing) commit(0, 0); host.post({ cmd: asNew ? "saveas" : "save", sheet: sheetForSave() }); setSaved("Saving…"); }
let autoTimer = 0;
function scheduleAutosave() {
  clearTimeout(autoTimer);
  if (!$("#autosave").checked) return;
  autoTimer = setTimeout(() => { if (dirty) { host.post({ cmd: "autosave", sheet: sheetForSave() }); } }, 3000);
}

// ------------------------------------------------------------------ commands
const CMD = {
  new: () => { if (dirty) save(false); $("#start").hidden = false; },
  open: () => host.post({ cmd: "open" }), save: () => save(false), saveas: () => save(true),
  print: () => host.post({ cmd: "print" }), exportcsv: () => {
    const last = lastRow(); let lastC = 1;
    for (const k of Object.keys(S.cells)) { const p = F.parseRef(k); if (S.cells[k].v !== "" && p.c > lastC) lastC = p.c; }
    const values = []; for (let r = 1; r <= last; r++) { const row = []; for (let c = 1; c <= lastC; c++) { const v = engine.value(ref(c, r)); row.push(F.isErr(v) ? v.err : typeof v === "boolean" ? (v ? "TRUE" : "FALSE") : String(v)); } values.push(row); }
    host.post({ cmd: "exportcsv", sheet: Object.assign(sheetForSave(), { values }) });
  },
  undo, redo, cut: () => copySel(true), copy: () => copySel(false), paste: () => host.post({ cmd: "paste" }),
  bold: () => { const on = !style(cur.c, cur.r).b; setStyle(s => { if (on) s.b = true; else delete s.b; }); },
  italic: () => { const on = !style(cur.c, cur.r).i; setStyle(s => { if (on) s.i = true; else delete s.i; }); },
  borders: () => { const on = !style(cur.c, cur.r).bd; setStyle(s => { if (on) s.bd = true; else delete s.bd; }); },
  clearfmt: () => setStyle(s => { for (const k of Object.keys(s)) delete s[k]; }),
  left: () => setStyle(s => { s.al = "left"; }), center: () => setStyle(s => { s.al = "center"; }), right: () => setStyle(s => { s.al = "right"; }),
  autosum: () => {
    let r = cur.r - 1; while (r >= 1 && typeof engine.value(ref(cur.c, r)) === "number") r--;
    const top = r + 1; if (top >= cur.r) { startEdit("=SUM()"); return; }
    change(() => setRaw(cur.c, cur.r, `=SUM(${ref(cur.c, top)}:${ref(cur.c, cur.r - 1)})`)); select(cur.c, cur.r);
  },
  sortaz: () => sortBy(cur.c, 1), sortza: () => sortBy(cur.c, -1),
  filter: () => { filtersOn = !filtersOn; if (!filtersOn) filters = {}; render(); },
  clearfilter: () => { filters = {}; render(); },
  find: () => { $("#findbar").hidden = false; $("#findtxt").focus(); $("#findtxt").select(); },
  findnext: findNext, findclose: () => { $("#findbar").hidden = true; $("#findtxt").value = ""; doFind(); },
  rowabove: () => insertRow(cur.r), rowbelow: () => { insertRow(cur.r + 1); select(cur.c, cur.r + 1); },
  delrow: () => deleteRow(cur.r), colleft: () => insertCol(cur.c), colright: () => { insertCol(cur.c + 1); select(cur.c + 1, cur.r); }, delcol: () => deleteCol(cur.c),
  today: () => { change(() => setRaw(cur.c, cur.r, new Date().toLocaleDateString("en-GB"))); },
  autofitall: () => change(() => { for (let c = 1; c <= S.cols; c++) autofit(c); }, true),
};

// ------------------------------------------------------------------ mouse: select, resize, drag rows & columns
let drag = null;
$("#wrap").addEventListener("mousedown", e => {
  const t = e.target;
  if (t.id === "editor" || t.closest("tr.filters")) return;
  if (editing && !editing.fromBar) commit(0, 0);
  if (t.classList.contains("cw")) { drag = { kind: "colw", c: +t.dataset.c, x: e.clientX, w: colW(+t.dataset.c), snap: snapshot() }; e.preventDefault(); return; }
  if (t.classList.contains("rh")) { drag = { kind: "rowh", r: +t.dataset.r, y: e.clientY, h: rowH(+t.dataset.r), snap: snapshot() }; e.preventDefault(); return; }
  if (t.classList.contains("handle")) { drag = { kind: "row", from: +t.dataset.r, started: true }; document.body.style.cursor = "grabbing"; e.preventDefault(); return; }
  const th = t.closest("thead th[data-c]");
  if (th) { const c = +th.dataset.c; drag = { kind: "col", from: c, x: e.clientX, started: false }; anchor = { c, r: 1 }; select(c, Math.max(lastRow(), 1), true); e.preventDefault(); return; }
  const rth = t.closest("tbody th[data-r]");
  if (rth) { const r = +rth.dataset.r; anchor = { c: 1, r }; select(S.cols, r, true); e.preventDefault(); return; }
  const cellEl = t.closest("td[data-c]");
  if (cellEl) { const c = +cellEl.dataset.c, r = +cellEl.dataset.r; if (e.shiftKey) select(c, r, true); else select(c, r); drag = { kind: "sel" }; e.preventDefault(); }
});
window.addEventListener("mousemove", e => {
  if (!drag) return;
  if (drag.kind === "colw") { S.colW[drag.c] = Math.max(30, drag.w + e.clientX - drag.x); document.querySelector(`col[data-c="${drag.c}"]`).style.width = S.colW[drag.c] + "px"; return; }
  if (drag.kind === "rowh") { S.rowH[drag.r] = Math.max(18, drag.h + e.clientY - drag.y); document.querySelector(`tr[data-r="${drag.r}"]`).style.height = S.rowH[drag.r] + "px"; return; }
  const el = document.elementFromPoint(e.clientX, e.clientY); if (!el) return;
  if (drag.kind === "sel") { const c = el.closest && el.closest("td[data-c]"); if (c) select(+c.dataset.c, +c.dataset.r, true); return; }
  const line = $("#dropline"), wrap = $("#wrap"), wr = wrap.getBoundingClientRect();
  if (drag.kind === "row") {
    const tr = el.closest && el.closest("tr[data-r]"); if (!tr) return;
    const rc = tr.getBoundingClientRect(); const after = e.clientY > rc.top + rc.height / 2;
    drag.to = +tr.dataset.r + (after ? 1 : 0);
    Object.assign(line.style, { left: "0px", width: wrap.scrollWidth + "px", height: "3px", top: (rc[after ? "bottom" : "top"] - wr.top + wrap.scrollTop - 1) + "px" }); line.hidden = false;
  } else if (drag.kind === "col") {
    if (!drag.started && Math.abs(e.clientX - drag.x) < 6) return;
    drag.started = true; document.body.style.cursor = "grabbing";
    const th = el.closest && (el.closest("th[data-c]") || el.closest("td[data-c]")); if (!th) return;
    const rc = th.getBoundingClientRect(); const after = e.clientX > rc.left + rc.width / 2;
    drag.to = +th.dataset.c + (after ? 1 : 0);
    Object.assign(line.style, { top: "0px", height: wrap.scrollHeight + "px", width: "3px", left: (rc[after ? "right" : "left"] - wr.left + wrap.scrollLeft - 1) + "px" }); line.hidden = false;
  }
});
window.addEventListener("mouseup", () => {
  if (!drag) return;
  const d = drag; drag = null; $("#dropline").hidden = true; document.body.style.cursor = "";
  if (d.kind === "colw" || d.kind === "rowh") { undoStack.push(d.snap); redoStack = []; dirty = true; updateTitle(); scheduleAutosave(); return; }
  if (d.kind === "row" && d.to) moveRow(d.from, d.to);
  if (d.kind === "col" && d.started && d.to) moveCol(d.from, d.to);
});
$("#wrap").addEventListener("dblclick", e => {
  const t = e.target;
  if (t.classList.contains("cw")) { const c = +t.dataset.c; change(() => autofit(c), true); return; }
  if (t.closest("td[data-c]")) startEdit();
});
$("#wrap").addEventListener("input", e => { if (e.target.dataset.fc) { filters[e.target.dataset.fc] = e.target.value; applyFilters(); } });

// ------------------------------------------------------------------ keyboard
document.addEventListener("keydown", e => {
  const ctrl = e.ctrlKey || e.metaKey, k = e.key;
  if (ctrl && !e.altKey) {
    const map = { s: "save", o: "open", n: "new", p: "print", z: "undo", y: "redo", b: "bold", i: "italic", f: "find" };
    if (map[k.toLowerCase()] && !(editing && "zybi".includes(k.toLowerCase()))) { e.preventDefault(); if (k.toLowerCase() === "z" && e.shiftKey) redo(); else CMD[map[k.toLowerCase()]](); return; }
    if (!editing && document.activeElement.tagName !== "INPUT") {
      if (k.toLowerCase() === "c") { e.preventDefault(); copySel(false); return; }
      if (k.toLowerCase() === "x") { e.preventDefault(); copySel(true); return; }
      if (k.toLowerCase() === "a") { e.preventDefault(); anchor = { c: 1, r: 1 }; select(S.cols, lastRow(), true); return; }
    }
  }
  if (document.activeElement && document.activeElement.id === "findtxt") { if (k === "Enter") { e.preventDefault(); findHits.length ? findNext() : doFind(); } if (k === "Escape") CMD.findclose(); return; }
  if (document.activeElement && document.activeElement.dataset && document.activeElement.dataset.fc) return;
  if (document.activeElement && document.activeElement.id === "formula") {
    if (k === "Enter") { e.preventDefault(); const v = $("#formula").value; if (v !== raw(cur.c, cur.r)) change(() => setRaw(cur.c, cur.r, v)); $("#formula").blur(); select(cur.c, cur.r + 1); }
    if (k === "Escape") { $("#formula").value = raw(cur.c, cur.r); $("#formula").blur(); }
    return;
  }
  if (editing) {
    if (k === "Enter") { e.preventDefault(); commit(0, 1); }
    else if (k === "Tab") { e.preventDefault(); commit(e.shiftKey ? -1 : 1, 0); }
    else if (k === "Escape") cancelEdit();
    return;
  }
  if (!$("#start").hidden) return;
  const mv = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0], Enter: [0, 1], Tab: [1, 0] }[k];
  if (mv) { e.preventDefault(); const sh = e.shiftKey && k.startsWith("Arrow"); select(cur.c + (k === "Tab" && e.shiftKey ? -1 : mv[0]), cur.r + mv[1], sh); return; }
  if (k === "Delete" || k === "Backspace") { e.preventDefault(); change(() => eachSel((c, r) => setRaw(c, r, ""))); select(cur.c, cur.r, true); return; }
  if (k === "F2") { e.preventDefault(); startEdit(); return; }
  if (k.length === 1 && !ctrl && !e.altKey) { e.preventDefault(); startEdit(k); }
});
document.addEventListener("paste", e => {
  if (editing || (document.activeElement && document.activeElement.tagName === "INPUT")) return;
  e.preventDefault(); pasteText(e.clipboardData.getData("text/plain"));
});
window.MBY.pasteText = pasteText;

// ------------------------------------------------------------------ ribbon wiring
$$("#tabs button").forEach(b => b.addEventListener("click", () => {
  $$("#tabs button").forEach(x => x.classList.toggle("on", x === b));
  $$(".pane").forEach(p => p.classList.toggle("on", p.id === "pane-" + b.dataset.tab));
}));
document.addEventListener("click", e => {
  const b = e.target.closest("[data-cmd]"); if (b) { e.preventDefault(); CMD[b.dataset.cmd](); }
  const t = e.target.closest("[data-tpl]"); if (t) startWith(t.dataset.tpl);
});
$("#fg").addEventListener("input", e => setStyle(s => { s.fg = e.target.value; }));
$("#bg").addEventListener("input", e => setStyle(s => { s.bg = e.target.value; }));
$("#numfmt").addEventListener("change", e => setStyle(s => { if (e.target.value) s.fmt = e.target.value; else delete s.fmt; }));
$("#findtxt").addEventListener("input", doFind);
$("#formula").addEventListener("focus", () => { if (editing && !editing.fromBar) commit(0, 0); });
$("#autosave").addEventListener("change", e => host.post({ cmd: "autosave-setting", on: e.target.checked }));
window.addEventListener("beforeunload", () => { if (dirty) host.post({ cmd: "autosave", sheet: sheetForSave() }); });

// ------------------------------------------------------------------ start
render();
if (!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mby)) $("#start").hidden = false;
host.post({ cmd: "ready" });
