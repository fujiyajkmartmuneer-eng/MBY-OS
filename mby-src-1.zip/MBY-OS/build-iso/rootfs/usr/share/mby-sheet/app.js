/* MBY Sheet - a simple spreadsheet for everyday shop work.
 * The grid, editing, resizing, drag-to-move, sort/filter/find and formatting live here.
 * Opening and saving files (.xlsx / .csv) is done by the host program (mby-sheet, Python),
 * which talks to this page through window.webkit.messageHandlers.mby. */
"use strict";
const F = window.MBYFormula;
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

// ------------------------------------------------------------------ state
let S = blankSheet();
let cur = { c: 1, r: 1 }, anchor = { c: 1, r: 1 };
let undoStack = [], redoStack = [];
let engine = null, dirty = false, filtersOn = false, filters = {};
let editing = null;           // {c, r, input, fromBar}
let hostPath = "";            // file this sheet is saved to (set by host)
let painter = null;           // Format Painter: style waiting to be applied

function blankSheet(rows = 100, cols = 12) {
  return { name: "Untitled", rows, cols, cells: {}, colW: {}, rowH: {},
    objects: [],                                  // pictures and charts floating over the sheet
    cf: [],                                       // conditional formatting rules
    freeze: { rows: 1, cols: 0 },                 // frozen panes (row 1 frozen by default)
    page: { orient: "portrait", paper: "A4", margins: "normal", fit: true, grid: false },
    view: { zoom: 100, gridlines: true, headings: true, formulas: false },
    merges: [],                                   // merged cells: {c1, r1, c2, r2}
    protect: false };
}
const ref = (c, r) => F.numToCol(c) + r;
const cell = (c, r) => S.cells[ref(c, r)];
const raw = (c, r) => (cell(c, r) || {}).v ?? "";
// ---- merged cells (like Excel): one cell covering a block; the upper-left cell holds the value
function mergeAt(c, r) { for (const m of S.merges || []) if (c >= m.c1 && c <= m.c2 && r >= m.r1 && r <= m.r2) return m; return null; }
function mergesIn(b) { return (S.merges || []).filter(m => !(m.c2 < b.c1 || m.c1 > b.c2 || m.r2 < b.r1 || m.r1 > b.r2)); }
function addMerge(b, centre) {
  if (b.c1 === b.c2 && b.r1 === b.r2) return;
  S.merges = (S.merges || []).filter(m => !mergesIn(b).includes(m));
  const k0 = ref(b.c1, b.r1); let first = S.cells[k0];
  if (!first || first.v === "" || first.v == null) {          // Excel keeps the upper-left value; use the first filled cell if that one is empty
    for (let r = b.r1; r <= b.r2 && !(first && first.v !== ""); r++) for (let c = b.c1; c <= b.c2; c++) { const x = S.cells[ref(c, r)]; if (x && x.v !== "") { first = Object.assign({}, x); break; } }
  }
  for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) if (c !== b.c1 || r !== b.r1) delete S.cells[ref(c, r)];
  first = first || { v: "" }; first.s = Object.assign({}, first.s); delete first.s.span;
  if (centre) { first.s.al = "center"; first.s.va = first.s.va || "middle"; }
  S.cells[k0] = first; S.merges.push({ c1: b.c1, r1: b.r1, c2: b.c2, r2: b.r2 });
}
function unmerge(b) { S.merges = (S.merges || []).filter(m => !mergesIn(b).includes(m)); }
function upgradeSpans() {                       // older MBY files: "span" (text across cells) becomes a real merge
  S.merges = S.merges || [];
  for (const [k, o] of Object.entries(S.cells)) if (o.s && o.s.span > 1) {
    const m = /^([A-Z]+)(\d+)$/.exec(k); if (!m) continue; const c = F.colToNum(m[1]), r = +m[2];
    if (!mergeAt(c, r)) S.merges.push({ c1: c, r1: r, c2: c + o.s.span - 1, r2: r }); delete o.s.span;
  }
}
const style = (c, r) => (cell(c, r) || {}).s || {};
const colW = c => S.colW[c] || (c === 1 ? 110 : 96);
const rowH = r => S.rowH[r] || 24;

// ------------------------------------------------------------------ host bridge
const host = {
  post(msg) {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mby;
    if (h) h.postMessage(JSON.stringify(msg));
    else if (msg.cmd === "save" || msg.cmd === "autosave") { localStorage.setItem("mby-sheet", JSON.stringify(msg.sheet)); setSaved("Saved (browser)"); }
  }
};
window.MBY = {
  receive(msg) {
    if (msg.cmd === "load") {
      const base = blankSheet(); S = Object.assign(base, msg.sheet);
      for (const k of ["page", "view", "freeze"]) S[k] = Object.assign({}, base[k], msg.sheet[k] || {});
      hostPath = msg.path || "";
      S.rows = Math.max(S.rows, 100); S.cols = Math.max(S.cols, 12);
      undoStack = []; redoStack = []; dirty = false; filters = {}; filtersOn = false;
      $("#start").hidden = true; cur = { c: 1, r: 2 }; anchor = { ...cur };
      render(); setSaved(msg.path ? "Opened" : "");
    } else if (msg.cmd === "saved") { hostPath = msg.path || hostPath; if (msg.name) S.name = msg.name; dirty = false; setSaved("Saved ✓"); updateTitle(); }
    else if (msg.cmd === "error") { setSaved("⚠ " + msg.text); alertBox(msg.text); }
    else if (msg.cmd === "start") { $("#start").hidden = false; }
    else if (msg.cmd === "save") { save(false); }
  }
};
function alertBox(t) { setTimeout(() => window.alert(t), 10); }
function setSaved(t) { $("#savestate").textContent = t; }
function updateTitle() { $("#docname").textContent = S.name + (dirty ? " •" : ""); document.title = S.name + " - MBY Sheet"; }

// ------------------------------------------------------------------ values & formatting
function newEngine() {
  const get = r => (S.cells[r] || {}).v ?? "";
  get.maxRow = () => S.rows;
  engine = F.makeEngine(get);
}
// Excel-style number formats: style.nf = {cat, dp, sep, neg, sym, date, time, frac, code}
const CUR = { BD: [3, "BD ", ""], "₹": [2, "₹", ""], SAR: [2, "", " SAR"], "$": [2, "$", ""], "€": [2, "€", ""], "£": [2, "£", ""], AED: [2, "AED ", ""] };
function serialToDate(n) { return new Date(Date.UTC(1899, 11, 30) + Math.round(n * 864e5)); }
function parseDateText(t) { const m = /^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/.exec(String(t).trim()); if (!m) return null; const y = +m[3] < 100 ? 2000 + +m[3] : +m[3]; return new Date(Date.UTC(y, +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0))); }
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function fmtDate(d, f) {
  const p = n => String(n).padStart(2, "0"), D = d.getUTCDate(), M = d.getUTCMonth() + 1, Y = d.getUTCFullYear();
  return { "dd/mm/yyyy": `${p(D)}/${p(M)}/${Y}`, "d-mmm-yyyy": `${D}-${MON[M - 1]}-${Y}`, "d mmmm yyyy": `${D} ${d.toLocaleString("en-GB", { month: "long", timeZone: "UTC" })} ${Y}`,
    "yyyy-mm-dd": `${Y}-${p(M)}-${p(D)}`, "mm/dd/yyyy": `${p(M)}/${p(D)}/${Y}`, "dddd, d mmmm yyyy": d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }) }[f] || `${p(D)}/${p(M)}/${Y}`;
}
function fmtTime(d, f) {
  const H = d.getUTCHours(), m = String(d.getUTCMinutes()).padStart(2, "0"), sec = String(d.getUTCSeconds()).padStart(2, "0");
  if (f === "h:mm AM/PM") return `${(H % 12) || 12}:${m} ${H < 12 ? "AM" : "PM"}`;
  if (f === "hh:mm:ss") return `${String(H).padStart(2, "0")}:${m}:${sec}`;
  return `${String(H).padStart(2, "0")}:${m}`;
}
function fraction(n, den) {
  const sign = n < 0 ? "-" : "", a = Math.abs(n), w = Math.floor(a); let f = a - w;
  let best = [0, 1];
  if (den === "any") { let bestErr = 1; for (let d = 1; d <= 9; d++) { const nu = Math.round(f * d), e = Math.abs(f - nu / d); if (e < bestErr - 1e-12) { bestErr = e; best = [nu, d]; } } }
  else { const d = +den; best = [Math.round(f * d), d]; }
  if (best[0] === best[1]) return sign + (w + 1);
  return sign + (w ? w + (best[0] ? " " : "") : "") + (best[0] ? `${best[0]}/${best[1]}` : (w ? "" : "0"));
}
function fmtCustom(n, code) {             // simple Excel codes: 0  0.00  #,##0.000 "BD"  0%  [Red]
  const sec = code.split(";"), part = n < 0 && sec[1] ? sec[1] : sec[0];
  const lit = []; let c = part.replace(/"([^"]*)"/g, (_, t) => { lit.push(t); return "\u0000" + (lit.length - 1) + "\u0000"; }).replace(/\[[^\]]*\]/g, "");
  const pct = c.includes("%"); let v = pct ? n * 100 : n; if (n < 0 && sec[1]) v = Math.abs(v);
  const m = /[#0,]*0(\.0+|\.#+)?/.exec(c); if (!m) return c.replace(/\u0000(\d+)\u0000/g, (_, i) => lit[i]);
  const dp = m[1] ? m[1].length - 1 : 0, sep = m[0].includes(",");
  const txt = v.toLocaleString("en-US", { minimumFractionDigits: dp, maximumFractionDigits: dp, useGrouping: sep });
  return c.replace(m[0], txt).replace(/\u0000(\d+)\u0000/g, (_, i) => lit[i]);
}
function formatNF(n, nf) {
  const dp = nf.dp != null ? +nf.dp : 2, loc = (x, d, g = true) => x.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d, useGrouping: g });
  const neg = t => n < 0 ? (nf.neg === "paren" ? `(${t})` : "-" + t) : t;
  switch (nf.cat) {
    case "number": return neg(loc(Math.abs(n), dp, !!nf.sep));
    case "currency": case "accounting": { const [d0, pre, post] = CUR[nf.sym || "BD"] || CUR.BD; const d = nf.dp != null ? +nf.dp : d0; return neg(pre + loc(Math.abs(n), d) + post); }
    case "date": return fmtDate(serialToDate(n), nf.date);
    case "time": return fmtTime(serialToDate(n), nf.time);
    case "percent": return loc(n * 100, nf.dp != null ? +nf.dp : 0) + "%";
    case "fraction": return fraction(n, nf.frac || "any");
    case "scientific": return n.toExponential(nf.dp != null ? +nf.dp : 2).replace("e", "E").replace(/E\+?(-?)(\d)$/, "E+$1" + "0$2").replace("E+-", "E-");
    case "special": return nf.special === "phone" ? String(Math.round(n)).replace(/(\d{4})(\d{4})$/, "$1 $2") : String(n);
    case "custom": return fmtCustom(n, nf.code || "General");
  }
  return null;
}
function display(c, r) {
  if (S.view && S.view.formulas) { const rw = raw(c, r); if (typeof rw === "string" && rw.startsWith("=")) return { t: rw, num: false }; }
  const v = engine.value(ref(c, r));
  if (F.isErr(v)) return { t: v.err, err: true, num: false };
  if (typeof v === "boolean") return { t: v ? "TRUE" : "FALSE", num: false };
  const st = style(c, r), nf = st.nf;
  if (nf && nf.cat === "text") return { t: String(raw(c, r)), num: false };
  if (nf && (nf.cat === "date" || nf.cat === "time") && typeof v === "string") { const d = parseDateText(v); if (d) return { t: nf.cat === "date" ? fmtDate(d, nf.date) : fmtTime(d, nf.time), num: true }; }
  if (typeof v === "number" && nf && nf.cat && nf.cat !== "general") { const t = formatNF(v, nf); if (t != null) return { t, num: true, red: v < 0 && nf.neg === "red" }; }
  if (typeof v === "number") return { t: fmtNum(v, st.fmt, st.dp), num: true };
  return { t: v, num: false };
}
const DEF_DP = { BHD: 3, INR: 2, SAR: 2, USD: 2, num2: 2, pct: 2 };
function fmtNum(n, f, dp) {
  const loc = (x, d, l = "en-US") => x.toLocaleString(l, { minimumFractionDigits: d, maximumFractionDigits: d });
  const d = dp != null ? dp : DEF_DP[f];
  switch (f) {
    case "BHD": return loc(n, d) + " BD";
    case "INR": return "₹" + loc(n, d, "en-IN");
    case "SAR": return loc(n, d) + " SAR";
    case "USD": return (n < 0 ? "-$" : "$") + loc(Math.abs(n), d);
    case "num2": return loc(n, d);
    case "pct": return loc(n * 100, d) + "%";
    default: return dp != null ? loc(n, dp) : (Number.isInteger(n) ? String(n) : String(+n.toPrecision(12)));
  }
}

// ------------------------------------------------------------------ rendering
function render() {
  upgradeSpans();
  newEngine();
  const g = $("#grid");
  let h = "<colgroup><col style='width:56px'>";
  for (let c = 1; c <= S.cols; c++) h += `<col data-c="${c}" style="width:${colW(c)}px">`;
  h += "</colgroup><thead><tr><th class='corner'></th>";
  for (let c = 1; c <= S.cols; c++) h += `<th data-c="${c}" title="Drag to move this column"><div class="hd">${F.numToCol(c)}<span class="cw" data-c="${c}"></span></div></th>`;
  h += "</tr></thead><tbody>";
  if (filtersOn) {
    h += "<tr class='filters'><th></th>";
    for (let c = 1; c <= S.cols; c++) h += `<td><input data-fc="${c}" placeholder="filter" value="${esc(filters[c] || "")}"></td>`;
    h += "</tr>";
  }
  for (let r = 1; r <= S.rows; r++) {
    h += `<tr data-r="${r}" class="${r === 1 ? "r1" : ""}" style="height:${rowH(r)}px"><th data-r="${r}"><div class="hd"><span class="handle" data-r="${r}" title="Drag to move this row">⠿</span>${r}<span class="rh" data-r="${r}"></span></div></th>`;
    for (let c = 1; c <= S.cols; c++) {
      const m = mergeAt(c, r);
      if (m && (m.c1 !== c || m.r1 !== r)) continue;            // covered by a merged cell
      h += m ? `<td data-c="${c}" data-r="${r}" colspan="${m.c2 - m.c1 + 1}" rowspan="${m.r2 - m.r1 + 1}" class="merged"></td>` : `<td data-c="${c}" data-r="${r}"></td>`;
    }
    h += "</tr>";
  }
  g.innerHTML = h + "</tbody>";
  paintAll(); applyFilters(); select(cur.c, cur.r, true, true); updateTitle();
  if (window.afterRender) window.afterRender();
}
function esc(s) { return String(s).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch])); }
function td(c, r) { return document.querySelector(`#grid td[data-c="${c}"][data-r="${r}"]`); }
function paintCell(el, c, r) {
  const d = display(c, r), s = style(c, r);
  el.textContent = d.t;
  el.className = (d.num ? "num" : "") + (d.err ? " err" : "") + (s.bd ? " b-all" : "");
  el.style.fontWeight = s.b ? "700" : ""; el.style.fontStyle = s.i ? "italic" : "";
  el.style.color = s.fg || ""; el.style.background = s.bg || "";
  const AL = { left: "left", center: "center", right: "right", justify: "justify", distributed: "justify", fill: "left", centerAcross: "center" };
  el.style.textAlign = AL[s.al] || ""; el.style.textAlignLast = s.al === "distributed" || s.jd ? "justify" : "";
  el.style.fontFamily = s.ff ? `"${s.ff}", sans-serif` : ""; el.style.fontSize = s.fz ? s.fz + "pt" : "";
  el.style.whiteSpace = s.wrap ? "normal" : ""; el.style.lineHeight = s.wrap ? "1.2" : "";
  el.style.verticalAlign = ({ justify: "middle", distributed: "middle" })[s.va] || s.va || "";
  el.style.paddingLeft = s.ind && (s.al === "left" || s.al === "distributed" || !s.al) ? (5 + s.ind * 10) + "px" : "";
  el.style.paddingRight = s.ind && s.al === "right" ? (5 + s.ind * 10) + "px" : "";
  el.dir = s.dir === "rtl" ? "rtl" : s.dir === "ltr" ? "ltr" : "auto";
  el.style.textDecoration = [s.u ? "underline" : "", s.st ? "line-through" : ""].filter(Boolean).join(" ");
  for (const [k, side] of [["bt", "Top"], ["bb", "Bottom"], ["bl", "Left"], ["br", "Right"]]) el.style["border" + side] = s[k] || "";
  if (d.red) el.style.color = "#dc2626";
  if (mergeAt(c, r)) el.classList.add("merged");
  let w = colW(c); const mm = mergeAt(c, r); if (mm) { w = 0; for (let k = mm.c1; k <= mm.c2; k++) w += colW(k); }
  if (s.al === "fill" && d.t) { const n = Math.max(1, Math.floor((w - 10) / Math.max(6, d.t.length * 7))); el.textContent = d.t.repeat(n); }
  if (s.shrink && d.t && !s.wrap) {                // shrink to fit: smaller letters so the text fits the cell
    const base = s.fz ? s.fz : 10, need = d.t.length * base * 0.62; if (need > w - 8) el.style.fontSize = Math.max(5, base * (w - 8) / need).toFixed(1) + "pt";
  }
  if (s.rot || s.vert) {                           // orientation: angled or stacked text
    el.textContent = ""; const sp = document.createElement("span"); sp.textContent = d.t;
    sp.style.display = "inline-block";
    if (s.vert) { sp.style.writingMode = "vertical-rl"; sp.style.textOrientation = "upright"; }
    else { sp.style.transform = `rotate(${-s.rot}deg)`; sp.style.transformOrigin = "center"; sp.style.whiteSpace = "nowrap"; }
    el.appendChild(sp);
  }
  el.title = s.note || ""; if (s.note) el.classList.add("has-note");
  if (window.cfStyleFor) { const x = window.cfStyleFor(c, r); if (x) { if (x.bg) el.style.background = x.bg; if (x.fg) el.style.color = x.fg; if (x.b) el.style.fontWeight = "700"; } }
}
function paintAll() {
  newEngine();
  for (const el of $$("#grid td[data-c]")) paintCell(el, +el.dataset.c, +el.dataset.r);
  markSelection(); stats();
}

// ------------------------------------------------------------------ selection
function rangeBox() {
  const b = { c1: Math.min(anchor.c, cur.c), c2: Math.max(anchor.c, cur.c), r1: Math.min(anchor.r, cur.r), r2: Math.max(anchor.r, cur.r) };
  for (let grown = true; grown;) {                  // a selection always takes whole merged cells
    grown = false;
    for (const m of mergesIn(b)) {
      if (m.c1 < b.c1) { b.c1 = m.c1; grown = true; } if (m.c2 > b.c2) { b.c2 = m.c2; grown = true; }
      if (m.r1 < b.r1) { b.r1 = m.r1; grown = true; } if (m.r2 > b.r2) { b.r2 = m.r2; grown = true; }
    }
  }
  return b;
}
function select(c, r, keepAnchor, noScroll) {
  c = Math.max(1, Math.min(c, S.cols)); r = Math.max(1, r);
  if (r > S.rows - 5) { S.rows += 50; render(); }
  const mg = mergeAt(c, r);
  if (mg && (c !== mg.c1 || r !== mg.r1)) {          // inside a merged cell: select the whole merged cell, or step over it
    const from = mergeAt(cur.c, cur.r) === mg;
    if (from && c > cur.c) c = Math.min(mg.c2 + 1, S.cols); else if (from && r > cur.r) r = mg.r2 + 1;
    else { c = mg.c1; r = mg.r1; }
  }
  cur = { c, r }; if (!keepAnchor) anchor = { c, r };
  markSelection(); stats();
  $("#addr").textContent = ref(c, r);
  if (!editing || !editing.fromBar) $("#formula").value = S.protect && style(c, r).hid ? "" : raw(c, r);
  $("#numfmt").value = style(c, r).fmt || "";
  const el = td(c, r); if (el && !noScroll) el.scrollIntoView({ block: "nearest", inline: "nearest" });
}
function markSelection() {
  const b = rangeBox();
  for (const el of $$("#grid td.sel, #grid td.cur")) el.classList.remove("sel", "cur");
  for (const el of $$("#grid th.selh")) el.classList.remove("selh");
  const multi = b.c1 !== b.c2 || b.r1 !== b.r2;
  if (multi) for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) { const el = td(c, r); if (el) el.classList.add("sel"); }
  const el = td(cur.c, cur.r); if (el) el.classList.add("cur");
  for (let c = b.c1; c <= b.c2; c++) { const h = document.querySelector(`#grid thead th[data-c="${c}"]`); if (h) h.classList.add("selh"); }
  for (let r = b.r1; r <= b.r2; r++) { const h = document.querySelector(`#grid tbody th[data-r="${r}"]`); if (h) h.classList.add("selh"); }
}
function stats() {
  const b = rangeBox(); let sum = 0, n = 0, cnt = 0;
  for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) {
    const v = engine.value(ref(c, r)); if (v !== "" && v != null) cnt++;
    if (typeof v === "number") { sum += v; n++; }
  }
  const f = style(cur.c, cur.r).fmt;
  $("#stat").textContent = (b.c1 === b.c2 && b.r1 === b.r2) ? ref(cur.c, cur.r) :
    `Sum: ${fmtNum(sum, f)}   Average: ${n ? fmtNum(sum / n, f) : "-"}   Count: ${cnt}`;
}

// ------------------------------------------------------------------ changes + undo
function snapshot() { return JSON.stringify({ cells: S.cells, colW: S.colW, rowH: S.rowH, rows: S.rows, cols: S.cols, objects: S.objects, cf: S.cf, freeze: S.freeze, page: S.page, merges: S.merges }); }
function restore(j) { Object.assign(S, JSON.parse(j)); render(); }
function change(fn, full) {
  if (S.protect && !window.__mbyUnlocked) { let ok = true; eachSel((c, r) => { if (!style(c, r).unlocked) ok = false; }); if (!ok) { setSaved("🔒 Sheet is protected - Review › Unprotect sheet"); return; } }
  undoStack.push(snapshot()); if (undoStack.length > 200) undoStack.shift(); redoStack = [];
  fn(); dirty = true; updateTitle(); setSaved("Editing…");
  if (full) render(); else paintAll();
  scheduleAutosave();
}
function undo() { if (!undoStack.length) return; redoStack.push(snapshot()); restore(undoStack.pop()); dirty = true; scheduleAutosave(); }
function redo() { if (!redoStack.length) return; undoStack.push(snapshot()); restore(redoStack.pop()); dirty = true; scheduleAutosave(); }
function setRaw(c, r, v) {
  const k = ref(c, r);
  if (v === "" && !(S.cells[k] && S.cells[k].s)) { delete S.cells[k]; return; }
  S.cells[k] = Object.assign({}, S.cells[k], { v });
  if (c > S.cols - 1) S.cols = c + 2;
}
function eachSel(fn) { const b = rangeBox(); for (let r = b.r1; r <= b.r2; r++) for (let c = b.c1; c <= b.c2; c++) fn(c, r); }
function setStyle(fn) {
  change(() => eachSel((c, r) => { const k = ref(c, r); const o = S.cells[k] || { v: "" }; o.s = Object.assign({}, o.s); fn(o.s); if (!Object.keys(o.s).length) delete o.s; S.cells[k] = o; }));
}

// ------------------------------------------------------------------ editing
function startEdit(initial, fromBar) {
  if (editing) return;
  if (S.protect && !style(cur.c, cur.r).unlocked) { setSaved("🔒 This cell is locked - Review › Unprotect sheet"); return; }
  const el = td(cur.c, cur.r); if (!el) return;
  const wrap = $("#wrap"), rc = el.getBoundingClientRect(), wr = wrap.getBoundingClientRect();
  const inp = document.createElement("input"); inp.id = "editor"; inp.spellcheck = false;
  inp.style.left = (rc.left - wr.left + wrap.scrollLeft) + "px"; inp.style.top = (rc.top - wr.top + wrap.scrollTop) + "px";
  inp.style.width = Math.max(rc.width, 120) + "px"; inp.style.height = rc.height + "px";
  inp.value = initial != null ? initial : raw(cur.c, cur.r);
  wrap.appendChild(inp);
  editing = { c: cur.c, r: cur.r, input: inp, fromBar: !!fromBar };
  if (!fromBar) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
  inp.addEventListener("input", () => { $("#formula").value = inp.value; });
  inp.addEventListener("blur", () => { if (editing && editing.input === inp && !editing.fromBar) commit(0, 0); });
}
function commit(dc, dr) {
  if (!editing) return;
  const { c, r, input } = editing; const v = editing.fromBar ? $("#formula").value : input.value;
  editing = null; input.remove();
  if (v !== raw(c, r)) change(() => setRaw(c, r, v));
  select(c + dc, r + dr);
}
function cancelEdit() { if (!editing) return; editing.input.remove(); editing = null; select(cur.c, cur.r); }

// ------------------------------------------------------------------ rows / columns: move, insert, delete
function remapAll(fn, keepRanges) {  // fn(c, r) -> [c, r] | null for every reference & cell
  const cells = {};
  for (const [k, o] of Object.entries(S.cells)) {
    const p = F.parseRef(k); const to = fn(p.c, p.r);
    if (!to) continue;
    cells[ref(to[0], to[1])] = Object.assign({}, o, { v: F.remapFormula(o.v, fn, keepRanges) });
  }
  S.cells = cells;
}
function permuteRows(order) {        // order[newIndex-1] = oldRow
  const map = {}; order.forEach((old, i) => { map[old] = i + 1; });
  const rh = {}; for (const [r, h] of Object.entries(S.rowH)) rh[map[r] || r] = h; S.rowH = rh;
  remapAll((c, r) => [c, map[r] || r], true);
}
function permuteCols(order) {
  const map = {}; order.forEach((old, i) => { map[old] = i + 1; });
  const cw = {}; for (const [c, w] of Object.entries(S.colW)) cw[map[c] || c] = w; S.colW = cw;
  remapAll((c, r) => [map[c] || c, r], true);
}
function moveRow(from, to) {
  if (from === to || to < 1) return;
  const order = []; for (let r = 1; r <= S.rows; r++) order.push(r);
  order.splice(from - 1, 1); order.splice(to > from ? to - 2 : to - 1, 0, from);
  change(() => permuteRows(order), true);
  select(cur.c, order.indexOf(from) + 1);
}
function moveCol(from, to) {
  if (from === to || to < 1) return;
  const order = []; for (let c = 1; c <= S.cols; c++) order.push(c);
  order.splice(from - 1, 1); order.splice(to > from ? to - 2 : to - 1, 0, from);
  change(() => permuteCols(order), true);
  select(order.indexOf(from) + 1, cur.r);
}
// merged cells follow inserted / deleted rows and columns (a merge that spans the spot grows or shrinks)
function shiftMerges(ax, at, d) {
  const a1 = ax + "1", a2 = ax + "2";
  S.merges = (S.merges || []).map(m => {
    m = Object.assign({}, m);
    if (d > 0) { if (m[a1] >= at) m[a1]++; if (m[a2] >= at) m[a2]++; }
    else { if (m[a1] === at && m[a2] === at) return null; if (m[a1] > at) m[a1]--; if (m[a2] >= at) m[a2]--; }
    return (m.c1 === m.c2 && m.r1 === m.r2) ? null : m;
  }).filter(Boolean);
}
function insertRow(at) { change(() => { S.rows++; const rh = {}; for (const [r, h] of Object.entries(S.rowH)) rh[+r >= at ? +r + 1 : r] = h; S.rowH = rh; remapAll((c, r) => [c, r >= at ? r + 1 : r]); shiftMerges("r", at, 1); }, true); }
function deleteRow(at) { change(() => { const rh = {}; for (const [r, h] of Object.entries(S.rowH)) if (+r !== at) rh[+r > at ? +r - 1 : r] = h; S.rowH = rh; remapAll((c, r) => r === at ? null : [c, r > at ? r - 1 : r]); shiftMerges("r", at, -1); }, true); }
function insertCol(at) { change(() => { S.cols++; const cw = {}; for (const [c, w] of Object.entries(S.colW)) cw[+c >= at ? +c + 1 : c] = w; S.colW = cw; remapAll((c, r) => [c >= at ? c + 1 : c, r]); shiftMerges("c", at, 1); }, true); }
function deleteCol(at) { change(() => { const cw = {}; for (const [c, w] of Object.entries(S.colW)) if (+c !== at) cw[+c > at ? +c - 1 : c] = w; S.colW = cw; remapAll((c, r) => c === at ? null : [c > at ? c - 1 : c, r]); shiftMerges("c", at, -1); }, true); }

// ------------------------------------------------------------------ sort / filter / find
function lastRow() { let m = 1; for (const k of Object.keys(S.cells)) { const p = F.parseRef(k); if (S.cells[k].v !== "" && p.r > m) m = p.r; } return m; }
function isTotalRow(r) {
  for (let c = 1; c <= S.cols; c++) { const v = String(raw(c, r)); if (/^=\s*SUM\(/i.test(v) || /^(grand )?total:?$/i.test(v.trim())) return true; }
  return false;
}
function dataEnd() {                 // last row with real (typed) data, above any TOTAL row
  let last = 1;
  for (let r = 2; r <= S.rows; r++) {
    if (isTotalRow(r)) break;
    for (let c = 1; c <= S.cols; c++) { const v = raw(c, r); if (v !== "" && !String(v).startsWith("=")) { last = r; break; } }
  }
  return last;
}
function sortBy(col, dir) {
  const last = dataEnd(); if (last < 3) return;
  const rows = []; for (let r = 2; r <= last; r++) rows.push(r);
  const key = r => { const v = engine.value(ref(col, r)); return v === "" ? null : v; };
  rows.sort((a, b) => {
    const x = key(a), y = key(b);
    if (x === null && y === null) return a - b; if (x === null) return 1; if (y === null) return -1;
    if (typeof x === "number" && typeof y === "number") return dir * (x - y) || a - b;
    return dir * String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: "base" }) || a - b;
  });
  const order = [1, ...rows]; for (let r = last + 1; r <= S.rows; r++) order.push(r);
  change(() => permuteRows(order), true);
}
function applyFilters() {
  const active = Object.entries(filters).filter(([, t]) => t);
  for (const tr of $$("#grid tbody tr[data-r]")) {
    const r = +tr.dataset.r;
    let show = r === 1 || !active.length;
    if (!show) show = active.every(([c, t]) => display(+c, r).t.toLowerCase().includes(t.toLowerCase()));
    tr.classList.toggle("hidden", !show);
  }
}
let findHits = [], findPos = -1;
function doFind() {
  const t = $("#findtxt").value.trim().toLowerCase();
  for (const el of $$("#grid td.found")) el.classList.remove("found");
  findHits = []; findPos = -1;
  if (!t) { $("#findinfo").textContent = ""; return; }
  for (let r = 1; r <= S.rows; r++) for (let c = 1; c <= S.cols; c++) if (display(c, r).t.toLowerCase().includes(t)) { findHits.push([c, r]); const el = td(c, r); if (el) el.classList.add("found"); }
  $("#findinfo").textContent = findHits.length ? `${findHits.length} found` : "Not found";
  findNext();
}
function findNext() { if (!findHits.length) return; findPos = (findPos + 1) % findHits.length; const [c, r] = findHits[findPos]; select(c, r); $("#findinfo").textContent = `${findPos + 1} of ${findHits.length}`; }

// ------------------------------------------------------------------ copy / paste
function selectionTSV() { const b = rangeBox(); const lines = []; for (let r = b.r1; r <= b.r2; r++) { const row = []; for (let c = b.c1; c <= b.c2; c++) row.push(display(c, r).t); lines.push(row.join("\t")); } return lines.join("\n"); }
let clipRaw = null;
function copySel(cut) {
  const b = rangeBox(); clipRaw = { b, cells: [] };
  for (let r = b.r1; r <= b.r2; r++) { const row = []; for (let c = b.c1; c <= b.c2; c++) row.push(Object.assign({}, cell(c, r))); clipRaw.cells.push(row); }
  clipRaw.text = selectionTSV();
  const ta = document.createElement("textarea"); ta.value = clipRaw.text; document.body.appendChild(ta); ta.select();
  try { document.execCommand("copy"); } catch (e) {} ta.remove();
  if (cut) change(() => eachSel((c, r) => setRaw(c, r, "")));
  setSaved(cut ? "Cut" : "Copied");
}
function pasteText(text) {
  if (clipRaw && text === clipRaw.text) {          // inside MBY Sheet: keep formulas & formats, shift references
    const dc = cur.c - clipRaw.b.c1, dr = cur.r - clipRaw.b.r1;
    change(() => clipRaw.cells.forEach((row, i) => row.forEach((o, j) => {
      const v = F.remapFormula(o.v ?? "", (c, r) => [c + dc, r + dr]);
      S.cells[ref(cur.c + j, cur.r + i)] = Object.assign({}, o, { v });
    })), true);
    return;
  }
  const rows = text.replace(/\r/g, "").replace(/\n$/, "").split("\n").map(l => l.split("\t"));
  change(() => rows.forEach((row, i) => row.forEach((v, j) => setRaw(cur.c + j, cur.r + i, v))), true);
}

// ------------------------------------------------------------------ autofit
const measureCtx = document.createElement("canvas").getContext("2d");
function autofit(c) {
  measureCtx.font = "13px Inter, Cantarell, sans-serif"; let w = 40;
  for (let r = 1; r <= S.rows; r++) { const t = display(c, r).t; if (t) { measureCtx.font = (style(c, r).b || r === 1 ? "700 " : "") + "13px Inter, Cantarell, sans-serif"; w = Math.max(w, measureCtx.measureText(t).width + 16); } }
  S.colW[c] = Math.min(Math.ceil(w), 480);
}

// ------------------------------------------------------------------ templates
const TPL = {
  blank: () => blankSheet(),
  products: () => tpl("Product list", ["Barcode", "Product", "Price (BD)", "Qty", "Total (BD)"], [130, 220, 100, 70, 110],
    r => ({ E: `=IF(D${r}="","",C${r}*D${r})` }), { C: "BHD", E: "BHD" }, "E"),
  sales: () => tpl("Daily sales", ["Date", "Bill no.", "Cash (BD)", "Card (BD)", "Total (BD)"], [110, 90, 110, 110, 120],
    r => ({ E: `=IF(AND(C${r}="",D${r}=""),"",C${r}+D${r})` }), { C: "BHD", D: "BHD", E: "BHD" }, "E"),
  expenses: () => tpl("Expenses", ["Date", "Item", "Category", "Amount (BD)"], [110, 220, 140, 120], () => ({}), { D: "BHD" }, "D"),
};
function tpl(name, heads, widths, perRow, fmts, totalCol) {
  const s = blankSheet(); s.name = name;
  heads.forEach((h, i) => { s.cells[ref(i + 1, 1)] = { v: h, s: { b: true, bg: "#dcfce7" } }; s.colW[i + 1] = widths[i]; });
  const lastData = 40;
  for (let r = 2; r <= lastData; r++) {
    for (const [col, f] of Object.entries(perRow(r))) s.cells[col + r] = { v: f, s: { fmt: fmts[col] } };
    for (const [col, f] of Object.entries(fmts)) if (!s.cells[col + r]) s.cells[col + r] = { v: "", s: { fmt: f } };
  }
  const tr = lastData + 1, tc = F.colToNum(totalCol);
  s.cells[ref(tc - 1, tr)] = { v: "TOTAL", s: { b: true, al: "right" } };
  s.cells[ref(tc, tr)] = { v: `=SUM(${totalCol}2:${totalCol}${lastData})`, s: { b: true, fmt: fmts[totalCol], bg: "#fef9c3", bd: true } };
  return s;
}
function startWith(name) {
  S = Object.assign(blankSheet(), TPL[name]()); hostPath = ""; undoStack = []; redoStack = []; dirty = false; filters = {}; filtersOn = false;
  $("#start").hidden = true; cur = { c: 1, r: 2 }; anchor = { ...cur }; render();
  host.post({ cmd: "new", name: S.name });
}

// ------------------------------------------------------------------ save / autosave
function sheetForSave() { return { name: S.name, rows: lastRow(), cols: S.cols, cells: S.cells, colW: S.colW, rowH: S.rowH,
  objects: S.objects, cf: S.cf, freeze: S.freeze, page: S.page, view: S.view, protect: S.protect }; }
function save(asNew) { if (editing) commit(0, 0); host.post({ cmd: asNew ? "saveas" : "save", sheet: sheetForSave() }); setSaved("Saving…"); }
let autoTimer = 0;
function scheduleAutosave() {
  clearTimeout(autoTimer);
  if (!$("#autosave").checked) return;
  autoTimer = setTimeout(() => { if (dirty) { host.post({ cmd: "autosave", sheet: sheetForSave() }); } }, 3000);
}

// ------------------------------------------------------------------ commands
const CMD = {
  new: () => { if (dirty) save(false); $("#start").hidden = false; },
  open: () => host.post({ cmd: "open" }), save: () => save(false), saveas: () => save(true),
  print: () => host.post({ cmd: "print" }), exportcsv: () => {
    const last = lastRow(); let lastC = 1;
    for (const k of Object.keys(S.cells)) { const p = F.parseRef(k); if (S.cells[k].v !== "" && p.c > lastC) lastC = p.c; }
    const values = []; for (let r = 1; r <= last; r++) { const row = []; for (let c = 1; c <= lastC; c++) { const v = engine.value(ref(c, r)); row.push(F.isErr(v) ? v.err : typeof v === "boolean" ? (v ? "TRUE" : "FALSE") : String(v)); } values.push(row); }
    host.post({ cmd: "exportcsv", sheet: Object.assign(sheetForSave(), { values }) });
  },
  undo, redo, cut: () => copySel(true), copy: () => copySel(false), paste: () => host.post({ cmd: "paste" }),
  bold: () => { const on = !style(cur.c, cur.r).b; setStyle(s => { if (on) s.b = true; else delete s.b; }); },
  italic: () => { const on = !style(cur.c, cur.r).i; setStyle(s => { if (on) s.i = true; else delete s.i; }); },
  borders: () => { const on = !style(cur.c, cur.r).bd; setStyle(s => { if (on) s.bd = true; else delete s.bd; }); },
  clearfmt: () => setStyle(s => { for (const k of Object.keys(s)) delete s[k]; }),
  left: () => setStyle(s => { s.al = "left"; }), center: () => setStyle(s => { s.al = "center"; }), right: () => setStyle(s => { s.al = "right"; }),
  mergecenter: () => { const b = rangeBox(), m = mergeAt(b.c1, b.r1);
    const same = m && m.c1 === b.c1 && m.r1 === b.r1 && m.c2 === b.c2 && m.r2 === b.r2;
    change(() => same ? unmerge(b) : addMerge(b, true), true); },
  mergeacross: () => { const b = rangeBox(); change(() => { for (let r = b.r1; r <= b.r2; r++) addMerge({ c1: b.c1, c2: b.c2, r1: r, r2: r }, false); }, true); },
  mergecells: () => { const b = rangeBox(); change(() => addMerge(b, false), true); },
  unmerge: () => { const b = rangeBox(); change(() => unmerge(b), true); },
  wraptext: () => setStyle(s => { s.wrap = s.wrap ? 0 : 1; }),
  autosum: () => {
    let r = cur.r - 1; while (r >= 1 && typeof engine.value(ref(cur.c, r)) === "number") r--;
    const top = r + 1; if (top >= cur.r) { startEdit("=SUM()"); return; }
    change(() => setRaw(cur.c, cur.r, `=SUM(${ref(cur.c, top)}:${ref(cur.c, cur.r - 1)})`)); select(cur.c, cur.r);
  },
  sortaz: () => sortBy(cur.c, 1), sortza: () => sortBy(cur.c, -1),
  filter: () => { filtersOn = !filtersOn; if (!filtersOn) filters = {}; render(); },
  clearfilter: () => { filters = {}; render(); },
  find: () => { $("#findbar").hidden = false; $("#findtxt").focus(); $("#findtxt").select(); },
  findnext: findNext, findclose: () => { $("#findbar").hidden = true; $("#findtxt").value = ""; doFind(); },
  rowabove: () => insertRow(cur.r), rowbelow: () => { insertRow(cur.r + 1); select(cur.c, cur.r + 1); },
  delrow: () => deleteRow(cur.r), colleft: () => insertCol(cur.c), colright: () => { insertCol(cur.c + 1); select(cur.c + 1, cur.r); }, delcol: () => deleteCol(cur.c),
  today: () => { change(() => setRaw(cur.c, cur.r, new Date().toLocaleDateString("en-GB"))); },
  autofitall: () => change(() => { for (let c = 1; c <= S.cols; c++) autofit(c); }, true),
};

// ------------------------------------------------------------------ mouse: select, resize, drag rows & columns
let drag = null;
$("#wrap").addEventListener("mousedown", e => {
  const t = e.target;
  if (t.id === "editor" || t.closest("tr.filters")) return;
  if (editing && !editing.fromBar) commit(0, 0);
  if (t.classList.contains("cw")) { drag = { kind: "colw", c: +t.dataset.c, x: e.clientX, w: colW(+t.dataset.c), snap: snapshot() }; e.preventDefault(); return; }
  if (t.classList.contains("rh")) { drag = { kind: "rowh", r: +t.dataset.r, y: e.clientY, h: rowH(+t.dataset.r), snap: snapshot() }; e.preventDefault(); return; }
  if (t.classList.contains("handle")) { drag = { kind: "row", from: +t.dataset.r, started: true }; document.body.style.cursor = "grabbing"; e.preventDefault(); return; }
  const th = t.closest("thead th[data-c]");
  if (th) { const c = +th.dataset.c; drag = { kind: "col", from: c, x: e.clientX, started: false }; anchor = { c, r: 1 }; select(c, Math.max(lastRow(), 1), true, true); e.preventDefault(); return; }
  const rth = t.closest("tbody th[data-r]");
  if (rth) { const r = +rth.dataset.r; anchor = { c: 1, r }; select(S.cols, r, true, true); e.preventDefault(); return; }
  const cellEl = t.closest("td[data-c]");
  if (cellEl) {
    const c = +cellEl.dataset.c, r = +cellEl.dataset.r, b = rangeBox();
    if (e.button === 2 && c >= b.c1 && c <= b.c2 && r >= b.r1 && r <= b.r2) { e.preventDefault(); return; }   // right-click inside the selection keeps it
    if (e.shiftKey) select(c, r, true); else select(c, r);
    if (e.button === 0) drag = { kind: "sel" };
    e.preventDefault();
  }
});
window.addEventListener("mousemove", e => {
  if (!drag) return;
  if (drag.kind === "colw") { S.colW[drag.c] = Math.max(30, drag.w + e.clientX - drag.x); document.querySelector(`col[data-c="${drag.c}"]`).style.width = S.colW[drag.c] + "px"; return; }
  if (drag.kind === "rowh") { S.rowH[drag.r] = Math.max(18, drag.h + e.clientY - drag.y); document.querySelector(`tr[data-r="${drag.r}"]`).style.height = S.rowH[drag.r] + "px"; return; }
  const el = document.elementFromPoint(e.clientX, e.clientY); if (!el) return;
  if (drag.kind === "sel") { const c = el.closest && el.closest("td[data-c]"); if (c) select(+c.dataset.c, +c.dataset.r, true); return; }
  const line = $("#dropline"), wrap = $("#wrap"), wr = wrap.getBoundingClientRect();
  if (drag.kind === "row") {
    const tr = el.closest && el.closest("tr[data-r]"); if (!tr) return;
    const rc = tr.getBoundingClientRect(); const after = e.clientY > rc.top + rc.height / 2;
    drag.to = +tr.dataset.r + (after ? 1 : 0);
    Object.assign(line.style, { left: "0px", width: wrap.scrollWidth + "px", height: "3px", top: (rc[after ? "bottom" : "top"] - wr.top + wrap.scrollTop - 1) + "px" }); line.hidden = false;
  } else if (drag.kind === "col") {
    if (!drag.started && Math.abs(e.clientX - drag.x) < 14) return;
    drag.started = true; document.body.style.cursor = "grabbing";
    const th = el.closest && (el.closest("th[data-c]") || el.closest("td[data-c]")); if (!th) return;
    const rc = th.getBoundingClientRect(); const after = e.clientX > rc.left + rc.width / 2;
    drag.to = +th.dataset.c + (after ? 1 : 0);
    Object.assign(line.style, { top: "0px", height: wrap.scrollHeight + "px", width: "3px", left: (rc[after ? "right" : "left"] - wr.left + wrap.scrollLeft - 1) + "px" }); line.hidden = false;
  }
});
window.addEventListener("mouseup", () => {
  if (painter && !drag) return;
  if (drag && drag.kind === "sel" && painter) { const st = painter; painter = null; document.body.classList.remove("painting"); setStyle(s => { for (const k of Object.keys(s)) delete s[k]; Object.assign(s, st); }); drag = null; return; }
  if (!drag) return;
  const d = drag; drag = null; $("#dropline").hidden = true; document.body.style.cursor = "";
  if (d.kind === "colw" || d.kind === "rowh") { undoStack.push(d.snap); redoStack = []; dirty = true; updateTitle(); scheduleAutosave(); return; }
  if (d.kind === "row" && d.to) moveRow(d.from, d.to);
  if (d.kind === "col" && d.started && d.to) moveCol(d.from, d.to);
});
$("#wrap").addEventListener("dblclick", e => {
  const t = e.target;
  if (t.classList.contains("cw")) { const c = +t.dataset.c; change(() => autofit(c), true); return; }
  if (t.closest("td[data-c]")) startEdit();
});
$("#wrap").addEventListener("input", e => { if (e.target.dataset.fc) { filters[e.target.dataset.fc] = e.target.value; applyFilters(); } });

// ------------------------------------------------------------------ keyboard
document.addEventListener("keydown", e => {
  const ctrl = e.ctrlKey || e.metaKey, k = e.key;
  if (ctrl && !e.altKey) {
    const map = { s: "save", o: "open", n: "new", p: "print", z: "undo", y: "redo", b: "bold", i: "italic", f: "find" };
    if (map[k.toLowerCase()] && !(editing && "zybi".includes(k.toLowerCase()))) { e.preventDefault(); if (k.toLowerCase() === "z" && e.shiftKey) redo(); else CMD[map[k.toLowerCase()]](); return; }
    if (!editing && document.activeElement.tagName !== "INPUT") {
      if (k.toLowerCase() === "c") { e.preventDefault(); copySel(false); return; }
      if (k.toLowerCase() === "x") { e.preventDefault(); copySel(true); return; }
      if (k.toLowerCase() === "a") { e.preventDefault(); anchor = { c: 1, r: 1 }; select(S.cols, lastRow(), true); return; }
    }
  }
  if (document.activeElement && document.activeElement.id === "findtxt") { if (k === "Enter") { e.preventDefault(); findHits.length ? findNext() : doFind(); } if (k === "Escape") CMD.findclose(); return; }
  if (document.activeElement && document.activeElement.dataset && document.activeElement.dataset.fc) return;
  if (document.activeElement && document.activeElement.id === "formula") {
    if (k === "Enter") { e.preventDefault(); const v = $("#formula").value; if (v !== raw(cur.c, cur.r)) change(() => setRaw(cur.c, cur.r, v)); $("#formula").blur(); select(cur.c, cur.r + 1); }
    if (k === "Escape") { $("#formula").value = raw(cur.c, cur.r); $("#formula").blur(); }
    return;
  }
  if (editing) {
    if (k === "Enter") { e.preventDefault(); commit(0, 1); }
    else if (k === "Tab") { e.preventDefault(); commit(e.shiftKey ? -1 : 1, 0); }
    else if (k === "Escape") cancelEdit();
    return;
  }
  if (!$("#start").hidden) return;
  const mv = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0], Enter: [0, 1], Tab: [1, 0] }[k];
  if (mv) { e.preventDefault(); const sh = e.shiftKey && k.startsWith("Arrow"); select(cur.c + (k === "Tab" && e.shiftKey ? -1 : mv[0]), cur.r + mv[1], sh); return; }
  if (k === "Delete" || k === "Backspace") { e.preventDefault(); change(() => eachSel((c, r) => setRaw(c, r, ""))); select(cur.c, cur.r, true); return; }
  if (k === "F2") { e.preventDefault(); startEdit(); return; }
  if (k.length === 1 && !ctrl && !e.altKey) { e.preventDefault(); startEdit(k); }
});
document.addEventListener("paste", e => {
  if (editing || (document.activeElement && document.activeElement.tagName === "INPUT")) return;
  e.preventDefault(); pasteText(e.clipboardData.getData("text/plain"));
});
window.MBY.pasteText = pasteText;

// ------------------------------------------------------------------ ribbon wiring
$$("#tabs button").forEach(b => b.addEventListener("click", () => {
  $$("#tabs button").forEach(x => x.classList.toggle("on", x === b));
  $$(".pane").forEach(p => p.classList.toggle("on", p.id === "pane-" + b.dataset.tab));
}));
document.addEventListener("click", e => {
  const b = e.target.closest("[data-cmd]"); if (b) { e.preventDefault(); CMD[b.dataset.cmd](); }
  const t = e.target.closest("[data-tpl]"); if (t) startWith(t.dataset.tpl);
});
$("#fg").addEventListener("input", e => setStyle(s => { s.fg = e.target.value; }));
$("#bg").addEventListener("input", e => setStyle(s => { s.bg = e.target.value; }));
$("#numfmt").addEventListener("change", e => setStyle(s => { delete s.nf; delete s.dp; if (e.target.value) s.fmt = e.target.value; else delete s.fmt; }));
$("#findtxt").addEventListener("input", doFind);
$("#formula").addEventListener("focus", () => { if (editing && !editing.fromBar) commit(0, 0); });
$("#autosave").addEventListener("change", e => host.post({ cmd: "autosave-setting", on: e.target.checked }));
window.addEventListener("beforeunload", () => { if (dirty) host.post({ cmd: "autosave", sheet: sheetForSave() }); });

// ------------------------------------------------------------------ start
render();
if (!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mby)) $("#start").hidden = false;
host.post({ cmd: "ready" });
