/* MBY Sheet - Excel-style extras:
 *  Insert: pictures (floating or in a cell), charts (column / bar / line / pie), links, symbols
 *  Page Layout: orientation, paper, margins, fit to page, gridlines, print selection
 *  Formulas: Insert Function, quick functions, categories, show formulas
 *  Data: conditional formatting, drop-down lists (validation), remove duplicates
 *  Review: notes, protect sheet, sheet info
 *  View: freeze panes, gridlines, headings, zoom, full screen
 *  File: Google Drive sync, open the sheets folder
 * Uses the globals of app.js and menu.js. */
"use strict";

// ================================================================== pictures & charts (floating objects)
let objSel = null;
function objLayer() { return $("#objects"); }
function cellRect(c, r) {          // position of a cell inside the zoom box (unzoomed px)
  const el = td(c, r), box = $("#zoombox"); if (!el) return { x: 0, y: 0, w: 96, h: 24 };
  const z = (S.view.zoom || 100) / 100, a = el.getBoundingClientRect(), b = box.getBoundingClientRect();
  return { x: (a.left - b.left) / z, y: (a.top - b.top) / z, w: a.width / z, h: a.height / z };
}
function drawObjects() {
  const L = objLayer(); if (!L) return;
  L.innerHTML = "";
  (S.objects || []).forEach(o => {
    const d = document.createElement("div"); d.className = "obj" + (objSel === o.id ? " sel" : ""); d.dataset.id = o.id;
    Object.assign(d.style, { left: o.x + "px", top: o.y + "px", width: o.w + "px", height: o.h + "px" });
    if (o.type === "image") { const im = document.createElement("img"); im.src = o.src; im.draggable = false; d.appendChild(im); }
    else { const cv = document.createElement("canvas"); cv.width = o.w * 2; cv.height = o.h * 2; d.appendChild(cv); drawChart(cv, o); }
    if (objSel === o.id) for (const h of ["nw", "ne", "sw", "se"]) { const k = document.createElement("span"); k.className = "hdl " + h; k.dataset.h = h; d.appendChild(k); }
    L.appendChild(d);
  });
}
function addObject(o) {
  const r = cellRect(cur.c, cur.r);
  o = Object.assign({ id: "o" + Date.now().toString(36) + Math.floor(Math.random() * 1000), x: r.x + 4, y: r.y + 4, w: 320, h: 220 }, o);
  change(() => { S.objects = (S.objects || []).concat([o]); }, true); objSel = o.id; drawObjects();
}
function insertPictureFromDataURL(src, inCell) {
  const img = new Image();
  img.onload = () => {
    if (inCell) {                  // fit into the selected cell (the row grows to a nice thumbnail size)
      const h = Math.max(rowH(cur.r), 60), w = Math.min(colW(cur.c) - 6, Math.round(img.width * (h - 6) / img.height));
      change(() => { S.rowH[cur.r] = h; }, true);
      const r = cellRect(cur.c, cur.r);
      addObject({ type: "image", src, cell: ref(cur.c, cur.r), x: r.x + 3, y: r.y + 3, w: Math.max(20, w), h: h - 6 });
    } else {
      const max = 360, k = Math.min(1, max / Math.max(img.width, img.height));
      addObject({ type: "image", src, w: Math.round(img.width * k), h: Math.round(img.height * k) });
    }
    setSaved("Picture added - drag to move, corners to resize, Delete to remove");
  };
  img.src = src;
}
let pictureInCell = false;
window.MBY.picture = src => insertPictureFromDataURL(src, pictureInCell);
function pickPicture(inCell) {
  pictureInCell = inCell;
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.mby) host.post({ cmd: "picture" });
  else { const f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.onchange = () => readImageFile(f.files[0]); f.click(); }
}
function readImageFile(file) { if (!file || !file.type.startsWith("image/")) return; const fr = new FileReader(); fr.onload = () => insertPictureFromDataURL(fr.result, pictureInCell); fr.readAsDataURL(file); }
// drop a picture file from Files onto the sheet
$("#wrap").addEventListener("dragover", e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) e.preventDefault(); });
$("#wrap").addEventListener("drop", e => {
  const f = e.dataTransfer && e.dataTransfer.files[0]; if (!f) return; e.preventDefault();
  const el = document.elementFromPoint(e.clientX, e.clientY), t = el && el.closest("td[data-c]");
  if (t) select(+t.dataset.c, +t.dataset.r);
  pictureInCell = !!t; readImageFile(f);
});

// move / resize / select objects
let objDrag = null;
document.addEventListener("mousedown", e => {
  const d = e.target.closest && e.target.closest(".obj");
  if (!d) { if (objSel && !e.target.closest(".ctx")) { objSel = null; drawObjects(); } return; }
  e.preventDefault(); e.stopPropagation();
  const o = S.objects.find(x => x.id === d.dataset.id); if (!o) return;
  if (objSel !== o.id) { objSel = o.id; drawObjects(); }
  objDrag = { o, h: e.target.dataset.h || null, x: e.clientX, y: e.clientY, start: { ...o }, snap: snapshot() };
}, true);
window.addEventListener("mousemove", e => {
  if (!objDrag) return;
  const z = (S.view.zoom || 100) / 100, dx = (e.clientX - objDrag.x) / z, dy = (e.clientY - objDrag.y) / z, o = objDrag.o, s0 = objDrag.start;
  if (!objDrag.h) { o.x = Math.max(0, s0.x + dx); o.y = Math.max(0, s0.y + dy); }
  else {
    const ar = s0.w / s0.h, h = objDrag.h;
    let w = s0.w + (h.includes("e") ? dx : -dx); w = Math.max(30, w);
    let hh = e.shiftKey ? Math.max(20, s0.h + (h.includes("s") ? dy : -dy)) : w / ar;   // keep the shape unless Shift
    if (h.includes("w")) o.x = s0.x + (s0.w - w); if (h.includes("n")) o.y = s0.y + (s0.h - hh);
    o.w = Math.round(w); o.h = Math.round(hh);
  }
  const el = document.querySelector(`.obj[data-id="${o.id}"]`); if (el) Object.assign(el.style, { left: o.x + "px", top: o.y + "px", width: o.w + "px", height: o.h + "px" });
});
window.addEventListener("mouseup", () => {
  if (!objDrag) return;
  const moved = JSON.stringify(objDrag.start) !== JSON.stringify(objDrag.o);
  if (moved) { undoStack.push(objDrag.snap); redoStack = []; dirty = true; updateTitle(); scheduleAutosave(); delete objDrag.o.cell; drawObjects(); }
  objDrag = null;
});
document.addEventListener("keydown", e => {
  if (!objSel || editing || (document.activeElement && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))) return;
  if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); e.stopImmediatePropagation(); const id = objSel; objSel = null; change(() => { S.objects = S.objects.filter(o => o.id !== id); }, true); }
}, true);

// ---------------- charts (drawn on a canvas, saved as real Excel charts)
const PALETTE = ["#16a34a", "#2563eb", "#f59e0b", "#dc2626", "#7c3aed", "#0891b2", "#db2777", "#65a30d", "#ea580c", "#475569"];
function chartData(o) {
  const A = F.parseRef(o.range.split(":")[0]), B = F.parseRef(o.range.split(":")[1]);
  const c1 = Math.min(A.c, B.c), c2 = Math.max(A.c, B.c), r1 = Math.min(A.r, B.r), r2 = Math.max(A.r, B.r);
  const head = typeof engine.value(ref(c2, r1)) !== "number";            // first row = titles?
  const labelsCol = c2 > c1 && typeof engine.value(ref(c1, r1 + (head ? 1 : 0))) !== "number";
  const vc1 = labelsCol ? c1 + 1 : c1, rs = head ? r1 + 1 : r1;
  const labels = [], series = [];
  for (let r = rs; r <= r2; r++) labels.push(labelsCol ? String(display(c1, r).t) : String(r - rs + 1));
  for (let c = vc1; c <= c2; c++) {
    const vals = []; for (let r = rs; r <= r2; r++) { const v = engine.value(ref(c, r)); vals.push(typeof v === "number" ? v : 0); }
    series.push({ name: head ? String(display(c, r1).t) : F.numToCol(c), vals });
  }
  return { labels, series };
}
function drawChart(cv, o) {
  const g = cv.getContext("2d"), W = cv.width, H = cv.height, k = 2;
  g.fillStyle = "#fff"; g.fillRect(0, 0, W, H);
  let data; try { newEngine(); data = chartData(o); } catch (e) { g.fillStyle = "#c00"; g.fillText("Chart range error", 10, 20); return; }
  g.font = `${13 * k}px Inter, sans-serif`; g.fillStyle = "#222"; g.textAlign = "center";
  g.fillText(o.title || (data.series.map(s => s.name).join(", ")), W / 2, 20 * k);
  const top = 34 * k, left = 44 * k, bottom = H - 34 * k, right = W - 12 * k;
  if (o.kind === "pie") {
    const vals = data.series[0] ? data.series[0].vals : [], tot = vals.reduce((a, b) => a + Math.max(0, b), 0) || 1;
    const cx = (left + right) / 2 - 50 * k, cy = (top + bottom) / 2 + 6 * k, rad = Math.min(right - left - 120 * k, bottom - top) / 2;
    let a0 = -Math.PI / 2;
    vals.forEach((v, i) => { const a1 = a0 + 2 * Math.PI * Math.max(0, v) / tot; g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, rad, a0, a1); g.closePath(); g.fillStyle = PALETTE[i % 10]; g.fill(); a0 = a1; });
    g.textAlign = "left"; g.font = `${11 * k}px Inter, sans-serif`;
    data.labels.forEach((l, i) => { const y = top + i * 16 * k; if (y > bottom) return; g.fillStyle = PALETTE[i % 10]; g.fillRect(cx + rad + 16 * k, y, 10 * k, 10 * k); g.fillStyle = "#333"; g.fillText(`${l} (${Math.round(100 * Math.max(0, vals[i]) / tot)}%)`, cx + rad + 30 * k, y + 9 * k); });
    return;
  }
  const all = data.series.flatMap(s => s.vals); let mx = Math.max(0, ...all), mn = Math.min(0, ...all); if (mx === mn) mx = mn + 1;
  const horiz = o.kind === "bar", n = data.labels.length || 1, ns = data.series.length || 1;
  g.strokeStyle = "#e5e7eb"; g.lineWidth = k; g.fillStyle = "#666"; g.font = `${10 * k}px Inter, sans-serif`;
  for (let i = 0; i <= 4; i++) {          // gridlines + axis numbers
    const v = mn + (mx - mn) * i / 4;
    if (!horiz) { const y = bottom - (bottom - top) * i / 4; g.beginPath(); g.moveTo(left, y); g.lineTo(right, y); g.stroke(); g.textAlign = "right"; g.fillText(+v.toPrecision(4), left - 4 * k, y + 3 * k); }
    else { const x = left + (right - left) * i / 4; g.beginPath(); g.moveTo(x, top); g.lineTo(x, bottom); g.stroke(); g.textAlign = "center"; g.fillText(+v.toPrecision(4), x, bottom + 12 * k); }
  }
  const pos = v => (v - mn) / (mx - mn);
  data.series.forEach((s, si) => {
    g.fillStyle = g.strokeStyle = PALETTE[si % 10]; g.lineWidth = 2.5 * k;
    if (o.kind === "line") {
      g.beginPath(); s.vals.forEach((v, i) => { const x = left + (right - left) * (i + 0.5) / n, y = bottom - (bottom - top) * pos(v); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke();
      s.vals.forEach((v, i) => { const x = left + (right - left) * (i + 0.5) / n, y = bottom - (bottom - top) * pos(v); g.beginPath(); g.arc(x, y, 3.5 * k, 0, 7); g.fill(); });
    } else s.vals.forEach((v, i) => {
      if (!horiz) { const bw = (right - left) / n * 0.7 / ns, x = left + (right - left) * i / n + (right - left) / n * 0.15 + si * bw, y0 = bottom - (bottom - top) * pos(0), y1 = bottom - (bottom - top) * pos(v); g.fillRect(x, Math.min(y0, y1), bw - k, Math.abs(y1 - y0)); }
      else { const bh = (bottom - top) / n * 0.7 / ns, y = top + (bottom - top) * i / n + (bottom - top) / n * 0.15 + si * bh, x0 = left + (right - left) * pos(0), x1 = left + (right - left) * pos(v); g.fillRect(Math.min(x0, x1), y, Math.abs(x1 - x0), bh - k); }
    });
  });
  g.fillStyle = "#444"; g.font = `${10 * k}px Inter, sans-serif`;
  data.labels.forEach((l, i) => {
    const t = l.length > 10 ? l.slice(0, 9) + "…" : l;
    if (!horiz) { g.textAlign = "center"; g.fillText(t, left + (right - left) * (i + 0.5) / n, bottom + 14 * k); }
    else { g.textAlign = "right"; g.fillText(t, left - 4 * k, top + (bottom - top) * (i + 0.5) / n + 3 * k); }
  });
  if (ns > 1) { g.textAlign = "left"; data.series.forEach((s, i) => { g.fillStyle = PALETTE[i % 10]; g.fillRect(left + i * 90 * k, H - 14 * k, 9 * k, 9 * k); g.fillStyle = "#333"; g.fillText(s.name, left + i * 90 * k + 13 * k, H - 6 * k); }); }
}
function insertChart(kind) {
  const b = rangeBox();
  if (b.c1 === b.c2 && b.r1 === b.r2) { alertBox("Select the data first (for example product names and totals, with the title row), then choose a chart."); return; }
  addObject({ type: "chart", kind, range: ref(b.c1, b.r1) + ":" + ref(b.c2, b.r2), w: 440, h: 270 });
}

// ================================================================== conditional formatting
window.cfStyleFor = (c, r) => {
  if (!S.cf || !S.cf.length) return null;
  let out = null;
  for (const rule of S.cf) {
    const [a, b] = rule.range.split(":").map(F.parseRef);
    if (c < Math.min(a.c, b.c) || c > Math.max(a.c, b.c) || r < Math.min(a.r, b.r) || r > Math.max(a.r, b.r)) continue;
    const v = engine.value(ref(c, r)); if (v === "" || v == null) continue;
    let hit = false, n = typeof v === "number" ? v : NaN;
    switch (rule.type) {
      case "gt": hit = n > +rule.v1; break; case "lt": hit = n < +rule.v1; break;
      case "between": hit = n >= +rule.v1 && n <= +rule.v2; break; case "eq": hit = String(v).toLowerCase() === String(rule.v1).toLowerCase(); break;
      case "text": hit = String(v).toLowerCase().includes(String(rule.v1).toLowerCase()); break;
      case "dup": { let k = 0; for (let rr = Math.min(a.r, b.r); rr <= Math.max(a.r, b.r); rr++) if (String(engine.value(ref(c, rr))) === String(v)) k++; hit = k > 1; break; }
      case "scale": {                       // red (low) -> yellow -> green (high)
        if (isNaN(n)) break; let lo = Infinity, hi = -Infinity;
        for (let rr = Math.min(a.r, b.r); rr <= Math.max(a.r, b.r); rr++) for (let cc = Math.min(a.c, b.c); cc <= Math.max(a.c, b.c); cc++) { const x = engine.value(ref(cc, rr)); if (typeof x === "number") { lo = Math.min(lo, x); hi = Math.max(hi, x); } }
        const t = hi > lo ? (n - lo) / (hi - lo) : 0.5, mix = (p, q, u) => Math.round(p + (q - p) * u);
        const [r0, g0, b0] = t < 0.5 ? [248, 105, 107] : [255, 235, 132], [r1, g1, b1] = t < 0.5 ? [255, 235, 132] : [99, 190, 123], u = t < 0.5 ? t * 2 : (t - 0.5) * 2;
        out = { bg: `rgb(${mix(r0, r1, u)},${mix(g0, g1, u)},${mix(b0, b1, u)})` }; continue;
      }
    }
    if (hit) out = { bg: rule.color || "#fde68a", fg: rule.fg || "", b: true };
  }
  return out;
};
function cfDialog() {
  const b = rangeBox(), rng = ref(b.c1, b.r1) + ":" + ref(b.c2, b.r2);
  const list = (S.cf || []).map((r, i) => `<div class="cfrow"><span>${r.range} · ${cfLabel(r)}</span><button data-del="${i}">✕</button></div>`).join("") || `<p class="hint">No rules yet.</p>`;
  const w = dialog("Conditional formatting", `
    <div class="grid2">
      <label>Cells<input id="cf_rng" value="${rng}"></label>
      <label>Rule<select id="cf_type"><option value="gt">Greater than</option><option value="lt">Less than</option><option value="between">Between</option>
        <option value="eq">Equal to</option><option value="text">Text contains</option><option value="dup">Duplicate values</option><option value="scale">Colour scale (red → green)</option></select></label>
      <label>Value<input id="cf_v1" placeholder="e.g. 10"></label><label>And (for Between)<input id="cf_v2" placeholder=""></label>
      <label>Colour<input type="color" id="cf_col" value="#fca5a5"></label>
    </div><h4 style="margin:14px 0 6px">Rules on this sheet</h4><div id="cf_list">${list}</div>`, wrap => {
      const rule = { range: wrap.querySelector("#cf_rng").value.trim().toUpperCase(), type: wrap.querySelector("#cf_type").value, v1: wrap.querySelector("#cf_v1").value, v2: wrap.querySelector("#cf_v2").value, color: wrap.querySelector("#cf_col").value };
      if (!/^[A-Z]+\d+:[A-Z]+\d+$/.test(rule.range)) { alertBox("Cells must look like C2:C40"); return false; }
      change(() => { S.cf = (S.cf || []).concat([rule]); });
    }, "Add rule");
  w.querySelector("#cf_list").addEventListener("click", e => { const i = e.target.dataset.del; if (i != null) { change(() => { S.cf.splice(+i, 1); }); e.target.parentElement.remove(); } });
}
function cfLabel(r) { return { gt: "> " + r.v1, lt: "< " + r.v1, between: `${r.v1} – ${r.v2}`, eq: "= " + r.v1, text: `contains "${r.v1}"`, dup: "duplicates", scale: "colour scale" }[r.type]; }

// ================================================================== drop-down list (data validation) & remove duplicates
function validationDialog() {
  const b = rangeBox(), rng = ref(b.c1, b.r1) + ":" + ref(b.c2, b.r2);
  dialog("Drop-down list", `<label>Cells <input id="dv_rng" value="${rng}"></label>
    <label style="display:block;margin-top:10px">Choices (comma separated)<input id="dv_list" style="width:100%;margin-top:4px" placeholder="Cash, Card, Credit"></label>
    <p class="hint">In those cells a ▾ appears; click it to choose. Leave empty to remove the list.</p>`, wrap => {
      const list = wrap.querySelector("#dv_list").value.split(",").map(x => x.trim()).filter(Boolean);
      const [a, z] = wrap.querySelector("#dv_rng").value.toUpperCase().split(":").map(F.parseRef); if (!a || !z) return false;
      change(() => { for (let r = a.r; r <= z.r; r++) for (let c = a.c; c <= z.c; c++) { const k = ref(c, r), o = S.cells[k] || { v: "" }; o.s = Object.assign({}, o.s); if (list.length) o.s.list = list; else delete o.s.list; S.cells[k] = o; } }, true);
    });
}
function removeDuplicates() {
  const last = dataEnd(); let removed = 0;
  change(() => {
    const seen = new Set(), keep = [1];
    for (let r = 2; r <= last; r++) { const key = []; for (let c = 1; c <= S.cols; c++) { const v = engine.value(ref(c, r)); key.push(typeof v === "object" && v ? JSON.stringify(v) : String(v).toLowerCase()); } const k = key.join("\u0001"); if (key.join("") === "" || !seen.has(k)) { seen.add(k); keep.push(r); } else removed++; }
    const order = keep.slice(); for (let r = 1; r <= S.rows; r++) if (!order.includes(r)) order.push(r);
    permuteRows(order);
    for (let i = 0; i < removed; i++) for (let c = 1; c <= S.cols; c++) delete S.cells[ref(c, keep.length + 1 + i)];
  }, true);
  setSaved(removed ? `Removed ${removed} duplicate row(s)` : "No duplicate rows found");
}
// show ▾ for cells that have a list
const _paintCell = paintCell;
paintCell = function (el, c, r) {
  _paintCell(el, c, r);
  const s = style(c, r);
  if (s.list) { el.classList.add("has-list"); }
  // dark mode: light fill colours keep dark text so they stay readable
  if (S.view && S.view.dark && el.style.background && !s.fg) {
    const m = /rgb\((\d+), (\d+), (\d+)\)/.exec(el.style.background) || /#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i.exec(el.style.background);
    if (m) { const [r_, g_, b_] = m[0].startsWith("#") ? [1, 2, 3].map(i => parseInt(m[i], 16)) : [1, 2, 3].map(i => +m[i]); if (r_ * 0.299 + g_ * 0.587 + b_ * 0.114 > 150) el.style.color = "#111"; }
  }
};
$("#wrap").addEventListener("click", e => {
  const t = e.target.closest("td.has-list"); if (!t) return;
  const rc = t.getBoundingClientRect(); if (e.clientX < rc.right - 18) return;
  const c = +t.dataset.c, r = +t.dataset.r; select(c, r);
  openMenu(rc.left, rc.bottom, style(c, r).list.map(v => item(v, "", () => { change(() => setRaw(c, r, v)); select(c, r + 1); })), false);
});

// ================================================================== freeze panes, view, zoom
window.afterRender = () => {
  const fr = S.freeze || { rows: 0, cols: 0 };
  const headH = document.querySelector("#grid thead tr").getBoundingClientRect().height;
  let top = headH;
  for (const tr of $$("#grid tbody tr[data-r]")) {
    const r = +tr.dataset.r, frozen = r <= fr.rows;
    tr.classList.toggle("frz", frozen);
    for (const cell of tr.children) {
      const stick = frozen && !(cell.rowSpan > 1 && r + cell.rowSpan - 1 > fr.rows);   // a merged cell reaching below the frozen rows scrolls normally
      cell.style.position = stick ? "sticky" : ""; cell.style.top = stick ? top + "px" : ""; }
    if (frozen) top += rowH(r);
    if (!frozen && r > fr.rows) break;
  }
  if (filtersOn) { const f = document.querySelector("tr.filters"); if (f) for (const cell of f.children) { cell.style.position = "sticky"; cell.style.top = top + "px"; } }
  // frozen columns
  let left = 56;
  for (let c = 1; c <= fr.cols; c++) {
    for (const cell of $$(`#grid td[data-c="${c}"], #grid thead th[data-c="${c}"]`)) { if (cell.colSpan > 1 && c + cell.colSpan - 1 > fr.cols) continue; cell.style.position = "sticky"; cell.style.left = left + "px"; cell.style.zIndex = cell.tagName === "TH" ? 4 : 1; cell.classList.add("frzc"); }
    left += colW(c);
  }
  const v = S.view || {};
  $("#zoombox").style.zoom = (v.zoom || 100) / 100; $("#zoomlbl").textContent = (v.zoom || 100) + "%";
  document.body.classList.toggle("nogrid", v.gridlines === false);
  document.body.classList.toggle("nohead", v.headings === false);
  $("#vw_grid").checked = v.gridlines !== false; $("#vw_head").checked = v.headings !== false;
  const p = S.page || {}; $("#pg_orient").value = p.orient || "portrait"; $("#pg_paper").value = p.paper || "A4"; $("#pg_margins").value = p.margins || "normal"; $("#pg_fit").checked = p.fit !== false; $("#pg_grid").checked = !!p.grid;
  applyPageCSS(); drawObjects();
};
function setView(k, v) { S.view = Object.assign({}, S.view, { [k]: v }); dirty = true; render(); scheduleAutosave(); }
function setFreeze(rows, cols) { change(() => { S.freeze = { rows, cols }; }, true); setSaved(rows || cols ? `Frozen: ${rows} row(s), ${cols} column(s)` : "Panes unfrozen"); }

// ================================================================== page layout & printing
function applyPageCSS() {
  const p = S.page || {}; let st = $("#pagecss"); if (!st) { st = document.createElement("style"); st.id = "pagecss"; document.head.appendChild(st); }
  const m = { normal: "12mm", narrow: "6mm", wide: "25mm" }[p.margins || "normal"];
  st.textContent = `@media print { @page { size: ${p.paper || "A4"} ${p.orient || "portrait"}; margin: ${m}; }
    ${p.fit !== false ? "#zoombox { zoom: 1 !important; } #grid { width: 100% !important; }" : ""}
    ${p.grid ? "" : "#grid td { border-color: transparent !important; } #grid td.b-all { border-color:#444 !important; }"} }`;
}
function printSelection() {
  const b = rangeBox();
  for (const tr of $$("#grid tbody tr[data-r]")) { const r = +tr.dataset.r; if (r < b.r1 || r > b.r2) tr.classList.add("noprint"); }
  for (const cell of $$("#grid td[data-c], #grid col[data-c]")) { const c = +cell.dataset.c; if (c < b.c1 || c > b.c2) cell.classList.add("noprint"); }
  CMD.print();
  setTimeout(() => $$(".noprint").forEach(x => x.classList.remove("noprint")), 4000);
}

// ================================================================== formulas
const FN_HELP = {
  math: [["SUM", "Adds numbers", "=SUM(D2:D40)"], ["AVERAGE", "Average", "=AVERAGE(C2:C40)"], ["MIN", "Smallest", "=MIN(C2:C40)"], ["MAX", "Largest", "=MAX(C2:C40)"], ["COUNT", "How many numbers", "=COUNT(C2:C40)"], ["COUNTA", "How many filled cells", "=COUNTA(B2:B40)"],
    ["ROUND", "Round to decimals", "=ROUND(E2,3)"], ["SUMIF", "Sum when a condition matches", '=SUMIF(B2:B40,"Milk",E2:E40)'], ["COUNTIF", "Count when a condition matches", '=COUNTIF(D2:D40,">5")'], ["AVERAGEIF", "Average with a condition", '=AVERAGEIF(C2:C40,">1")'],
    ["MEDIAN", "Middle value", "=MEDIAN(C2:C40)"], ["PRODUCT", "Multiply all", "=PRODUCT(C2,D2)"], ["MOD", "Remainder", "=MOD(10,3)"], ["ABS", "Without minus", "=ABS(E2)"], ["INT", "Whole number", "=INT(E2)"], ["POWER", "Power", "=POWER(2,3)"], ["SQRT", "Square root", "=SQRT(16)"],
    ["SUMIFS", "Sum with several conditions", '=SUMIFS(E2:E40,B2:B40,"Rice",C2:C40,">5")'], ["COUNTIFS", "Count with several conditions", '=COUNTIFS(B2:B40,"Rice",C2:C40,">5")'], ["AVERAGEIFS", "Average with several conditions", '=AVERAGEIFS(E2:E40,B2:B40,"Rice")'],
    ["MAXIFS", "Largest with conditions", '=MAXIFS(E2:E40,B2:B40,"Rice")'], ["MINIFS", "Smallest with conditions", '=MINIFS(E2:E40,B2:B40,"Rice")'], ["SUMPRODUCT", "Qty × price, all added", "=SUMPRODUCT(C2:C40,D2:D40)"],
    ["ROUNDUP", "Round up", "=ROUNDUP(E2,2)"], ["ROUNDDOWN", "Round down", "=ROUNDDOWN(E2,2)"], ["CEILING", "Round up to a step", "=CEILING(E2,0.05)"], ["FLOOR", "Round down to a step", "=FLOOR(E2,0.05)"], ["TRUNC", "Cut decimals", "=TRUNC(E2)"],
    ["LARGE", "2nd, 3rd … largest", "=LARGE(E2:E40,2)"], ["SMALL", "2nd, 3rd … smallest", "=SMALL(E2:E40,2)"], ["RANK", "Position in a list", "=RANK(E2,E$2:E$40)"], ["STDEV", "Standard deviation", "=STDEV(E2:E40)"],
    ["RANDBETWEEN", "Random whole number", "=RANDBETWEEN(1,100)"], ["PI", "π", "=PI()"]],
  lookup: [["VLOOKUP", "Find a row by its first column", '=VLOOKUP(A2,F:H,3,FALSE)'], ["XLOOKUP", "Find and return (newer than VLOOKUP)", "=XLOOKUP(A2,A:A,C:C)"], ["HLOOKUP", "Find by the first row", "=HLOOKUP(\"Qty\",A1:E5,2)"], ["MATCH", "Position in a list", '=MATCH("Milk",B2:B40)'], ["INDEX", "Value at a position", "=INDEX(C2:C40,3)"], ["CHOOSE", "Pick from a list", '=CHOOSE(2,"Low","Mid","High")'], ["UNIQUE", "First distinct value", "=UNIQUE(B2:B40)"]],
  text: [["CONCAT", "Join text", '=CONCAT(B2," - ",C2)'], ["LEFT", "First characters", "=LEFT(A2,4)"], ["RIGHT", "Last characters", "=RIGHT(A2,4)"], ["MID", "Middle characters", "=MID(A2,3,2)"], ["LEN", "Length", "=LEN(B2)"], ["UPPER", "CAPITALS", "=UPPER(B2)"], ["LOWER", "small letters", "=LOWER(B2)"], ["PROPER", "Title Case", "=PROPER(B2)"], ["TRIM", "Remove extra spaces", "=TRIM(B2)"], ["SUBSTITUTE", "Replace text", '=SUBSTITUTE(B2,"-"," ")'], ["TEXT", "Number as text", '=TEXT(E2,"#,##0.000")'], ["VALUE", "Text to number", "=VALUE(A2)"],
    ["TEXTJOIN", "Join with a separator", '=TEXTJOIN(", ",TRUE,B2:B10)'], ["FIND", "Position of text (exact case)", '=FIND("-",A2)'], ["SEARCH", "Position of text (any case, * ?)", '=SEARCH("milk",B2)'], ["REPT", "Repeat text", '=REPT("*",5)'], ["EXACT", "Same text exactly", "=EXACT(A2,B2)"]],
  logic: [["IF", "If … then … else", '=IF(D2>10,"Many","Few")'], ["IFERROR", "Value if error", "=IFERROR(E2/D2,0)"], ["AND", "All true", "=AND(C2>0,D2>0)"], ["OR", "Any true", "=OR(C2=0,D2=0)"], ["NOT", "Opposite", "=NOT(C2>0)"], ["ISBLANK", "Is the cell empty", "=ISBLANK(A2)"], ["ISNUMBER", "Is it a number", "=ISNUMBER(C2)"],
    ["IFS", "Several conditions", '=IFS(E2>100,"High",E2>50,"Mid",TRUE,"Low")'], ["SWITCH", "Pick by value", '=SWITCH(A2,"R","Rice","S","Sugar","Other")'], ["ISTEXT", "Is it text", "=ISTEXT(B2)"], ["ISNA", "Is it #N/A", "=ISNA(F2)"]],
  date: [["TODAY", "Today's date", "=TODAY()"], ["NOW", "Date and time", "=NOW()"], ["DATE", "Make a date", "=DATE(2026,11,25)"], ["YEAR", "Year of a date", "=YEAR(A2)"], ["MONTH", "Month of a date", "=MONTH(A2)"], ["DAY", "Day of a date", "=DAY(A2)"],
    ["DAYS", "Days between two dates", "=DAYS(B2,A2)"], ["EDATE", "Same day, months later", "=EDATE(A2,1)"], ["EOMONTH", "Last day of the month", "=EOMONTH(A2,0)"], ["WEEKDAY", "Day of week (1 = Sunday)", "=WEEKDAY(A2)"],
    ["NETWORKDAYS", "Working days between dates", "=NETWORKDAYS(A2,B2)"], ["HOUR", "Hour of a time", "=HOUR(A2)"], ["MINUTE", "Minute of a time", "=MINUTE(A2)"]],
};
function insertFunction(cat) {
  const cats = cat ? [cat] : Object.keys(FN_HELP);
  const rows = cats.flatMap(k => FN_HELP[k]).map(([n, d, ex]) => `<option value="${esc(ex)}">${n} — ${d}</option>`).join("");
  dialog(cat ? `Functions: ${cat}` : "Insert function", `<input id="fn_q" placeholder="Search a function, e.g. sum, lookup, date" style="width:100%;margin-bottom:8px">
    <select id="fn_l" size="12" style="width:100%">${rows}</select><p class="hint" id="fn_ex">Choose a function; an example is put in the cell for you to edit.</p>`, wrap => {
      const v = wrap.querySelector("#fn_l").value; if (!v) return false;
      startEdit(v.replace(/&quot;/g, '"').replace(/&amp;/g, "&"));
    }, "Insert");
  const q = document.querySelector("#fn_q"), l = document.querySelector("#fn_l");
  q.addEventListener("input", () => { const t = q.value.toLowerCase(); for (const o of l.options) o.hidden = !o.textContent.toLowerCase().includes(t); });
  l.addEventListener("change", () => { document.querySelector("#fn_ex").textContent = "Example: " + l.value; });
}
function quickFn(name) {
  let r = cur.r - 1; while (r >= 1 && typeof engine.value(ref(cur.c, r)) === "number") r--;
  const top = r + 1; if (top >= cur.r) { startEdit(`=${name}()`); return; }
  change(() => setRaw(cur.c, cur.r, `=${name}(${ref(cur.c, top)}:${ref(cur.c, cur.r - 1)})`)); select(cur.c, cur.r);
}

// ================================================================== review
function showNotes() {
  const notes = Object.entries(S.cells).filter(([, o]) => o.s && o.s.note);
  dialog("All notes", notes.length ? `<div class="notes">${notes.map(([k, o]) => `<div><b data-go="${k}" class="go">${k}</b> ${esc(o.s.note)}</div>`).join("")}</div>` : `<p class="hint">There are no notes on this sheet.</p>`, () => {}, "Close");
  document.querySelector(".notes") && document.querySelector(".notes").addEventListener("click", e => { const k = e.target.dataset.go; if (k) { const p = F.parseRef(k); document.querySelector(".dlg-wrap").remove(); select(p.c, p.r); } });
}
function protectToggle() {
  if (S.protect) { S.protect = false; dirty = true; setSaved("🔓 Sheet unprotected"); }
  else { S.protect = true; dirty = true; setSaved("🔒 Sheet protected - cells cannot be changed until you unprotect it"); }
  $("[data-cmd=protect] b") && ($("[data-cmd=protect] b").textContent = S.protect ? "Unprotect sheet" : "Protect sheet");
  scheduleAutosave();
}
function sheetInfo() {
  const filled = Object.values(S.cells).filter(o => o.v !== "").length, formulas = Object.values(S.cells).filter(o => String(o.v).startsWith("=")).length;
  dialog("Sheet info", `<p>Rows with data: <b>${lastRow()}</b><br>Filled cells: <b>${filled}</b><br>Formulas: <b>${formulas}</b><br>Pictures: <b>${(S.objects || []).filter(o => o.type === "image").length}</b> · Charts: <b>${(S.objects || []).filter(o => o.type === "chart").length}</b><br>Notes: <b>${Object.values(S.cells).filter(o => o.s && o.s.note).length}</b> · Rules: <b>${(S.cf || []).length}</b></p>`, () => {}, "Close");
}

// ================================================================== links & symbols
function linkDialog() {
  dialog("Insert link", `<label>Text <input id="lk_t" value="${esc(display(cur.c, cur.r).t)}"></label><label style="display:block;margin-top:8px">Address <input id="lk_u" style="width:100%" placeholder="https://…"></label>`, wrap => {
    const t = wrap.querySelector("#lk_t").value, u = wrap.querySelector("#lk_u").value.trim(); if (!u) return false;
    change(() => { setRaw(cur.c, cur.r, t || u); const o = S.cells[ref(cur.c, cur.r)]; o.s = Object.assign({}, o.s, { link: u, fg: "#1d4ed8" }); });
  });
}
$("#wrap").addEventListener("click", e => { if (!(e.ctrlKey || e.metaKey)) return; const t = e.target.closest("td[data-c]"); if (!t) return; const s = style(+t.dataset.c, +t.dataset.r); if (s.link) host.post({ cmd: "openlink", url: s.link }); });
function symbolDialog() {
  const syms = "₹ $ € £ ﷼ BD د.ب ر.س ✓ ✗ ★ ☆ → ← ↑ ↓ • ° ± × ÷ ½ ¼ ¾ © ® ™ ✔ ✖ ⚠ ☎ ✉ ♥".split(" ");
  const w = dialog("Insert symbol", `<div class="syms">${syms.map(s => `<button data-s="${s}">${s}</button>`).join("")}</div>`, () => {}, "Close");
  w.querySelector(".syms").addEventListener("click", e => { const s = e.target.dataset.s; if (s) { change(() => setRaw(cur.c, cur.r, String(raw(cur.c, cur.r)) + s)); } });
}

// ================================================================== Google Drive
window.MBY.cloud = st => { $("#cloudstate").textContent = st; };

// ================================================================== wire up
Object.assign(CMD, {
  picture: () => pickPicture(false), pictureincell: () => pickPicture(true),
  chart_col: () => insertChart("col"), chart_bar: () => insertChart("bar"), chart_line: () => insertChart("line"), chart_pie: () => insertChart("pie"),
  link: linkDialog, symbol: symbolDialog,
  printarea: printSelection,
  insertfn: () => insertFunction(), fn_AVERAGE: () => quickFn("AVERAGE"), fn_COUNT: () => quickFn("COUNT"), fn_MAX: () => quickFn("MAX"), fn_MIN: () => quickFn("MIN"),
  fncat_lookup: () => insertFunction("lookup"), fncat_text: () => insertFunction("text"), fncat_math: () => insertFunction("math"), fncat_logic: () => insertFunction("logic"), fncat_date: () => insertFunction("date"),
  showformulas: () => setView("formulas", !(S.view && S.view.formulas)), recalc: () => paintAll(),
  cf: cfDialog, validation: validationDialog, dedupe: removeDuplicates,
  shownotes: showNotes, delnotes: () => change(() => { for (const o of Object.values(S.cells)) if (o.s) delete o.s.note; }), protect: protectToggle, stats: sheetInfo,
  freezepanes: () => setFreeze(cur.r - 1, cur.c - 1), freezetop: () => setFreeze(1, 0), freezecol: () => setFreeze(0, 1), unfreeze: () => setFreeze(0, 0),
  zoomin: () => setView("zoom", Math.min(200, (S.view.zoom || 100) + 10)), zoomout: () => setView("zoom", Math.max(50, (S.view.zoom || 100) - 10)), zoom100: () => setView("zoom", 100),
  fullscreen: () => host.post({ cmd: "fullscreen" }),
  cloud: () => host.post({ cmd: "cloud" }), folder: () => host.post({ cmd: "folder" }),
});
$("#vw_grid").addEventListener("change", e => setView("gridlines", e.target.checked));
$("#vw_head").addEventListener("change", e => setView("headings", e.target.checked));
for (const [id, k, type] of [["#pg_orient", "orient"], ["#pg_paper", "paper"], ["#pg_margins", "margins"], ["#pg_fit", "fit", "chk"], ["#pg_grid", "grid", "chk"]])
  $(id).addEventListener("change", e => { S.page = Object.assign({}, S.page, { [k]: type === "chk" ? e.target.checked : e.target.value }); dirty = true; applyPageCSS(); scheduleAutosave(); });
// right-click on a picture/chart
document.addEventListener("contextmenu", e => {
  const d = e.target.closest && e.target.closest(".obj"); if (!d) return;
  e.preventDefault(); e.stopPropagation(); const id = d.dataset.id; objSel = id; drawObjects();
  const o = S.objects.find(x => x.id === id);
  const items = [item("Delete", "🗑️", () => { objSel = null; change(() => { S.objects = S.objects.filter(x => x.id !== id); }, true); }),
    item("Bring to front", "⬆", () => change(() => { S.objects = S.objects.filter(x => x.id !== id).concat([o]); }, true)),
    item("Send to back", "⬇", () => change(() => { S.objects = [o].concat(S.objects.filter(x => x.id !== id)); }, true)),
    item("Original size", "↺", () => { const im = d.querySelector("img"); if (im) change(() => { o.w = im.naturalWidth; o.h = im.naturalHeight; }, true); })];
  if (o.type === "chart") items.push(sep(), item("Chart title…", "✏️", () => dialog("Chart title", `<input id="ct" value="${esc(o.title || "")}" style="width:100%">`, w => change(() => { o.title = w.querySelector("#ct").value; }, true))),
    item("Column chart", "📊", () => change(() => { o.kind = "col"; }, true)), item("Bar chart", "📶", () => change(() => { o.kind = "bar"; }, true)),
    item("Line chart", "📈", () => change(() => { o.kind = "line"; }, true)), item("Pie chart", "🥧", () => change(() => { o.kind = "pie"; }, true)));
  openMenu(e.clientX, e.clientY, items, false);
}, true);
render();

// ================================================================== View: dark mode, navigation, formula bar, focus cell, zoom box
function applyViewExtras() {
  const v = S.view || {};
  document.body.classList.toggle("dark", !!v.dark);
  $("#fbar").style.display = v.fbar === false ? "none" : "";
  $("#vw_fbar").checked = v.fbar !== false; $("#vw_focus").checked = !!v.focus;
  document.body.classList.toggle("focuscell", !!v.focus);
  markFocus();
}
function markFocus() {
  for (const el of $$("#grid .focusline")) el.classList.remove("focusline");
  if (!(S.view && S.view.focus)) return;
  for (const el of $$(`#grid td[data-r="${cur.r}"], #grid td[data-c="${cur.c}"]`)) el.classList.add("focusline");
}
const _afterRender = window.afterRender;
window.afterRender = () => { _afterRender(); applyViewExtras(); if (!$("#navpane").hidden) fillNav(); };
const _select = select;
select = function (c, r, k, n) { _select(c, r, k, n); markFocus(); };
function fillNav() {
  const q = ($("#navq").value || "").toLowerCase(), out = [];
  const heads = []; for (let c = 1; c <= S.cols; c++) { const t = display(c, 1).t; if (t) heads.push([`📋 ${t}`, c, 1]); }
  if (heads.length) out.push(["Columns", heads]);
  const objs = (S.objects || []).map((o, i) => [`${o.type === "chart" ? "📊 Chart" : "🖼️ Picture"} ${i + 1}${o.title ? ": " + o.title : ""}`, null, null, o]);
  if (objs.length) out.push(["Pictures & charts", objs]);
  const notes = Object.entries(S.cells).filter(([, o]) => o.s && o.s.note).map(([k, o]) => { const p = F.parseRef(k); return [`📝 ${k}: ${o.s.note}`, p.c, p.r]; });
  if (notes.length) out.push(["Notes", notes]);
  const tots = []; for (let r = 2; r <= S.rows; r++) if (isTotalRow(r)) tots.push([`Σ Total row ${r}`, 1, r]);
  if (tots.length) out.push(["Totals", tots]);
  const found = [];
  if (q) for (let r = 1; r <= S.rows; r++) for (let c = 1; c <= S.cols; c++) { const t = display(c, r).t; if (t && t.toLowerCase().includes(q)) found.push([`${ref(c, r)}: ${t}`, c, r]); }
  if (q) out.unshift(["Search results", found.slice(0, 200)]);
  $("#navlist").innerHTML = out.map(([h, items], gi) => `<div class="navgrp"><div class="navg">${esc(h)} (${items.length})</div>${items.filter(it => !q || gi === 0 || it[0].toLowerCase().includes(q)).map((it, i) => `<div class="navit" data-g="${gi}" data-i="${i}">${esc(it[0])}</div>`).join("")}</div>`).join("") || `<p class="hint" style="padding:8px">Nothing to show yet.</p>`;
  $("#navlist").onclick = e => {
    const d = e.target.closest(".navit"); if (!d) return; const it = out[+d.dataset.g][1][+d.dataset.i];
    if (it[3]) { objSel = it[3].id; drawObjects(); const el = document.querySelector(`.obj[data-id="${it[3].id}"]`); if (el) el.scrollIntoView({ block: "center", inline: "center" }); }
    else select(it[1], it[2]);
  };
}
$("#navq").addEventListener("input", fillNav);
$("#navq").addEventListener("keydown", e => e.stopPropagation());
function zoomDialog() {
  const z = S.view.zoom || 100;
  dialog("Zoom", `<div class="zoomopts">${[200, 150, 125, 100, 90, 75, 50].map(v => `<label class="chk"><input type="radio" name="zv" value="${v}"${v === z ? " checked" : ""}> ${v}%</label>`).join("")}
    <label class="chk"><input type="radio" name="zv" value="fit"> Fit selection</label>
    <label class="chk"><input type="radio" name="zv" value="custom"${[200, 150, 125, 100, 90, 75, 50].includes(z) ? "" : " checked"}> Custom: <input type="number" id="zc" min="10" max="400" value="${z}" style="width:70px">%</label></div>`, w => {
      const sel = w.querySelector("input[name=zv]:checked").value;
      if (sel === "fit") zoomToSelection(); else setView("zoom", Math.max(10, Math.min(400, sel === "custom" ? +w.querySelector("#zc").value : +sel)));
    });
}
function zoomToSelection() {
  const b = rangeBox(); let w = 56, h = 30;
  for (let c = b.c1; c <= b.c2; c++) w += colW(c); for (let r = b.r1; r <= b.r2; r++) h += rowH(r);
  const box = $("#wrap").getBoundingClientRect();
  const z = Math.max(10, Math.min(400, Math.floor(Math.min(box.width / w, box.height / h) * 100)));
  setView("zoom", z); select(b.c1, b.r1, true);
}
Object.assign(CMD, {
  darkmode: () => setView("dark", !(S.view && S.view.dark)),
  navpane: () => { $("#navpane").hidden = !$("#navpane").hidden; document.body.classList.toggle("withnav", !$("#navpane").hidden); if (!$("#navpane").hidden) fillNav(); },
  zoomdlg: zoomDialog, zoomsel: zoomToSelection,
});
$("#vw_fbar").addEventListener("change", e => setView("fbar", e.target.checked));
$("#vw_focus").addEventListener("change", e => setView("focus", e.target.checked));
// Ctrl + mouse wheel zooms, like Excel
$("#wrap").addEventListener("wheel", e => { if (!e.ctrlKey) return; e.preventDefault(); setView("zoom", Math.max(10, Math.min(400, (S.view.zoom || 100) + (e.deltaY < 0 ? 10 : -10)))); }, { passive: false });
applyViewExtras();
