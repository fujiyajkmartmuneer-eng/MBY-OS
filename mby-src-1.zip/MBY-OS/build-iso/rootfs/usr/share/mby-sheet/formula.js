/* MBY Sheet - formula engine (no DOM). Excel-style formulas:
 *   =A1*B1   =SUM(D2:D20)   =IF(C2>10,"Many","Few")   =VLOOKUP(A2,F:G,2,FALSE)
 * Works in the app and in node (tests). */
(function (root) {
"use strict";
const ERR = s => ({ err: s });
const isErr = v => v && typeof v === "object" && "err" in v;

function colToNum(c) { let n = 0; for (const ch of c.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64); return n; }
function numToCol(n) { let s = ""; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }
function parseRef(ref) { const m = /^\$?([A-Z]{1,3})\$?(\d+)$/i.exec(ref); return m ? { c: colToNum(m[1]), r: +m[2] } : null; }
function refName(c, r) { return numToCol(c) + r; }

// a date typed as text ("26/11/2026", "2026-11-26", "26-Nov-2026") -> Excel serial number, or null
function dateSerial(v) {
  const s = String(v).trim(); let y, m, d, x;
  if ((x = /^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/.exec(s))) { d = +x[1]; m = +x[2]; y = +x[3]; }
  else if ((x = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s))) { y = +x[1]; m = +x[2]; d = +x[3]; }
  else if ((x = /^(\d{1,2})[ -]([A-Za-z]{3})[a-z]*[ -](\d{4})$/.exec(s))) { const i = "janfebmaraprmayjunjulaugsepoctnovdec".indexOf(x[2].toLowerCase()); if (i < 0) return null; d = +x[1]; m = i / 3 + 1; y = +x[3]; }
  else return null;
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  return Math.round((Date.UTC(y, m - 1, d) - Date.UTC(1899, 11, 30)) / 864e5);
}

// ---------------- tokenizer ----------------
function tokenize(src) {
  const t = []; let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '"') { let j = i + 1, s = ""; while (j < src.length) { if (src[j] === '"') { if (src[j + 1] === '"') { s += '"'; j += 2; continue; } break; } s += src[j++]; }
      if (j >= src.length) throw "#VALUE!"; t.push({ k: "str", v: s }); i = j + 1; continue; }
    let m;
    const rest = src.slice(i);
    if ((m = /^(\$?[A-Z]{1,3}\$?\d+)(:\$?[A-Z]{1,3}\$?\d+)?/i.exec(rest)) && !/^[A-Z]{1,3}\d+\(/i.test(rest)) {
      const u = x => x.replace(/\$/g, "").toUpperCase();
      t.push(m[2] ? { k: "range", a: u(m[1]), b: u(m[2].slice(1)) } : { k: "ref", v: u(m[1]) }); i += m[0].length; continue; }
    if ((m = /^\$?([A-Z]{1,3}):\$?([A-Z]{1,3})(?![\w(])/i.exec(rest))) {         // whole columns  F:G
      t.push({ k: "range", a: m[1].toUpperCase() + "1", b: m[2].toUpperCase() + "100000" }); i += m[0].length; continue; }
    if ((m = /^\$?(\d+):\$?(\d+)(?![\w(])/.exec(rest)) && /^\$?\d+:/.test(rest)) {          // whole rows  2:5
      t.push({ k: "range", a: "A" + m[1], b: "ZZ" + m[2] }); i += m[0].length; continue; }
    if ((m = /^\d+(\.\d+)?([eE][+-]?\d+)?/.exec(rest))) { t.push({ k: "num", v: parseFloat(m[0]) }); i += m[0].length; continue; }
    if ((m = /^(TRUE|FALSE)(?![\w(])/i.exec(rest))) { t.push({ k: "bool", v: m[1].toUpperCase() === "TRUE" }); i += m[0].length; continue; }
    if ((m = /^([A-Z][A-Z0-9.]*)\s*\(/i.exec(rest))) { t.push({ k: "fn", v: m[1].toUpperCase() }); i += m[0].length; continue; }
    if ((m = /^(<=|>=|<>|[-+*/^&=<>(),%:;])/.exec(rest))) { t.push({ k: "op", v: m[1] === ";" ? "," : m[1] }); i += m[0].length; continue; }
    throw "#NAME?";
  }
  return t;
}

// ---------------- parser (precedence climbing) ----------------
function parse(tokens) {
  let p = 0;
  const peek = () => tokens[p], next = () => tokens[p++];
  const isOp = (v) => peek() && peek().k === "op" && peek().v === v;
  function primary() {
    const tk = next();
    if (!tk) throw "#VALUE!";
    if (tk.k === "num" || tk.k === "str" || tk.k === "bool") return { t: "lit", v: tk.v };
    if (tk.k === "ref") return { t: "ref", v: tk.v };
    if (tk.k === "range") return { t: "range", a: tk.a, b: tk.b };
    if (tk.k === "fn") {
      const args = [];
      if (!isOp(")")) { do { args.push(isOp(",") || isOp(")") ? { t: "lit", v: "" } : expr(0)); } while (isOp(",") && next()); }
      if (!isOp(")")) throw "#VALUE!"; next();
      return { t: "fn", name: tk.v, args };
    }
    if (tk.k === "op" && tk.v === "(") { const e = expr(0); if (!isOp(")")) throw "#VALUE!"; next(); return e; }
    if (tk.k === "op" && (tk.v === "-" || tk.v === "+")) { const e = unary(); return tk.v === "-" ? { t: "neg", e } : e; }
    throw "#VALUE!";
  }
  function unary() { let e = primary(); while (isOp("%")) { next(); e = { t: "bin", op: "/", a: e, b: { t: "lit", v: 100 } }; } return e; }
  const PREC = { "=": 1, "<>": 1, "<": 1, ">": 1, "<=": 1, ">=": 1, "&": 2, "+": 3, "-": 3, "*": 4, "/": 4, "^": 5 };
  function expr(min) {
    let a = unary();
    while (peek() && peek().k === "op" && PREC[peek().v] !== undefined && PREC[peek().v] >= min) {
      const op = next().v, prec = PREC[op];
      const b = expr(prec + 1);                 // left to right, like Excel (2^3^2 = 64)
      a = { t: "bin", op, a, b };
    }
    return a;
  }
  const e = expr(0);
  if (p < tokens.length) throw "#VALUE!";
  return e;
}

// ---------------- evaluator ----------------
function makeEngine(getRaw) {
  const cache = new Map(), busy = new Set();
  function toNum(v) {
    if (isErr(v)) throw v.err;
    if (typeof v === "number") return v;
    if (typeof v === "boolean") return v ? 1 : 0;
    if (v === "" || v == null) return 0;
    const n = Number(String(v).replace(/,/g, ""));
    if (isNaN(n)) { const d = dateSerial(v); if (d != null) return d; throw "#VALUE!"; }
    return n;
  }
  const toStr = v => { if (isErr(v)) throw v.err; if (typeof v === "boolean") return v ? "TRUE" : "FALSE"; return v == null ? "" : String(v); };
  const truthy = v => typeof v === "string" ? (v.toUpperCase() === "TRUE" ? true : v === "" ? false : (() => { throw "#VALUE!"; })()) : !!toNum(v);

  function literal(raw) {
    if (raw == null || raw === "") return "";
    if (typeof raw === "number") return raw;
    const s = String(raw).trim();
    if (/^0\d+$/.test(s) || /^\d{12,}$/.test(s)) return s;      // barcodes / phone numbers stay text
    if (/^[-+]?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?([eE][+-]?\d+)?%?$/.test(s)) { const pc = s.endsWith("%"); const n = Number(s.replace(/[,%]/g, "")); return pc ? n / 100 : n; }
    if (/^(true|false)$/i.test(s)) return s.toUpperCase() === "TRUE";
    return String(raw);
  }

  function value(ref) {
    if (cache.has(ref)) return cache.get(ref);
    const raw = getRaw(ref);
    let v;
    if (typeof raw === "string" && raw.startsWith("=") && raw.length > 1) {
      if (busy.has(ref)) return ERR("#CIRC!");
      busy.add(ref);
      try { v = evaluate(parse(tokenize(raw.slice(1)))); if (Array.isArray(v)) v = v[0] ? v[0][0] : ""; }
      catch (e) { v = ERR(typeof e === "string" ? e : "#VALUE!"); }
      busy.delete(ref);
    } else v = literal(raw);
    cache.set(ref, v);
    return v;
  }

  function rangeVals(a, b) {
    const A = parseRef(a), B = parseRef(b); if (!A || !B) throw "#REF!";
    const r1 = Math.min(A.r, B.r), r2 = Math.min(Math.max(A.r, B.r), getRaw.maxRow ? getRaw.maxRow() : 100000);
    const c1 = Math.min(A.c, B.c), c2 = Math.max(A.c, B.c);
    const out = [];
    for (let r = r1; r <= r2; r++) { const row = []; for (let c = c1; c <= c2; c++) row.push(value(refName(c, r))); out.push(row); }
    return out;
  }
  const flat = args => args.flatMap(a => Array.isArray(a) ? a.flat() : [a]);
  // numbers in ranges are counted; a number typed straight into the function ("5", TRUE) counts too, like Excel
  const nums = args => args.flatMap(a => Array.isArray(a) ? a.flat().filter(v => { if (isErr(v)) throw v.err; return typeof v === "number"; })
    : (isErr(a) ? (() => { throw a.err; })() : a === "" || a == null ? [] : [toNum(a)]));
  const wild = s => new RegExp("^" + String(s).replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/~\*/g, "\u0001").replace(/~\?/g, "\u0002").replace(/\*/g, ".*").replace(/\?/g, ".").replace(/\u0001/g, "\\*").replace(/\u0002/g, "\\?") + "$", "i");
  const crit = (c) => { const m = /^(<=|>=|<>|<|>|=)?(.*)$/.exec(String(c)); const op = m[1] || "="; const rhs = literal(m[2]);
    if (typeof rhs === "string" && /[*?]/.test(rhs) && (op === "=" || op === "<>")) { const re = wild(rhs); return v => (typeof v === "string" && re.test(v)) === (op === "="); }
    if (typeof rhs === "string" && rhs === "" && op === "=") return v => v === "" || v == null;
    return v => { const a = typeof rhs === "number" ? (typeof v === "number" ? v : NaN) : String(v).toLowerCase(), b = typeof rhs === "number" ? rhs : String(rhs).toLowerCase();
      switch (op) { case "=": return a === b; case "<>": return a !== b; case "<": return a < b; case ">": return a > b; case "<=": return a <= b; default: return a >= b; } }; };
  const dpart = v => { if (typeof v === "number") return new Date(Date.UTC(1899, 11, 30) + v * 864e5); const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(String(v)); if (m) return new Date(+m[3], +m[2] - 1, +m[1]); const d = new Date(v); if (isNaN(d)) throw "#VALUE!"; return d; };
  // Excel rounds half away from zero and ignores binary noise (1.005 -> 1.01)
  const round = (n, d, f) => { const k = Math.pow(10, d), x = +(n * k).toPrecision(15);
    const r = f ? f(x) : Math.sign(x) * Math.round(Math.abs(x)); return +(r / k).toPrecision(15); };
  const dfmt = d => d.toLocaleDateString("en-GB");
  const serialToDate = n => new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 864e5);
  const dserial = d => Math.round((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(1899, 11, 30)) / 864e5);
  const D = v => serialToDate(typeof v === "number" ? v : toNum(v));
  const stats = a => { const n = nums(a); const m = n.reduce((x, y) => x + y, 0) / n.length; return { n, m, ss: n.reduce((x, y) => x + (y - m) ** 2, 0) }; };
  const multi = (a, from) => { const tests = []; for (let i = from; i < a.length; i += 2) tests.push([a[i].flat(), crit(a[i + 1])]); return idx => tests.every(([r, t]) => t(r[idx])); };

  const FN = {
    SUM: a => nums(a).reduce((x, y) => x + y, 0),
    AVERAGE: a => { const n = nums(a); if (!n.length) throw "#DIV/0!"; return n.reduce((x, y) => x + y, 0) / n.length; },
    MIN: a => { const n = nums(a); return n.length ? Math.min(...n) : 0; },
    MAX: a => { const n = nums(a); return n.length ? Math.max(...n) : 0; },
    COUNT: a => nums(a).length,
    COUNTA: a => flat(a).filter(v => v !== "" && v != null).length,
    IF: a => truthy(a[0]) ? (a.length > 1 ? a[1] : true) : (a.length > 2 ? a[2] : false),
    IFERROR: a => isErr(a[0]) ? a[1] : a[0],
    AND: a => flat(a).every(truthy), OR: a => flat(a).some(truthy), NOT: a => !truthy(a[0]),
    ROUND: a => round(toNum(a[0]), toNum(a[1] ?? 0)),
    ROUNDUP: a => round(toNum(a[0]), toNum(a[1] ?? 0), x => x < 0 ? Math.floor(x) : Math.ceil(x)),
    ROUNDDOWN: a => round(toNum(a[0]), toNum(a[1] ?? 0), Math.trunc),
    INT: a => Math.floor(toNum(a[0])), ABS: a => Math.abs(toNum(a[0])),
    LEN: a => toStr(a[0]).length, UPPER: a => toStr(a[0]).toUpperCase(), LOWER: a => toStr(a[0]).toLowerCase(),
    TRIM: a => toStr(a[0]).trim().replace(/\s+/g, " "),
    CONCAT: a => flat(a).map(toStr).join(""), CONCATENATE: a => flat(a).map(toStr).join(""),
    TODAY: () => dfmt(new Date()),
    NOW: () => new Date().toLocaleString("en-GB"),
    SUMIF: a => { const test = crit(a[1]); const r = a[0].flat(), s = (a[2] || a[0]).flat(); let t = 0; r.forEach((v, i) => { if (test(v) && typeof s[i] === "number") t += s[i]; }); return t; },
    COUNTIF: a => { const test = crit(a[1]); return a[0].flat().filter(v => test(v)).length; },
    MEDIAN: a => { const n = nums(a).sort((x, y) => x - y); if (!n.length) throw "#NUM!"; const m = n.length >> 1; return n.length % 2 ? n[m] : (n[m - 1] + n[m]) / 2; },
    PRODUCT: a => nums(a).reduce((x, y) => x * y, 1),
    MOD: a => { const d = toNum(a[1]); if (d === 0) throw "#DIV/0!"; const x = toNum(a[0]); return x - d * Math.floor(x / d); },
    POWER: a => Math.pow(toNum(a[0]), toNum(a[1])),
    SQRT: a => { const x = toNum(a[0]); if (x < 0) throw "#NUM!"; return Math.sqrt(x); },
    COUNTBLANK: a => flat(a).filter(v => v === "" || v == null).length,
    AVERAGEIF: a => { const test = crit(a[1]); const r = a[0].flat(), s = (a[2] || a[0]).flat(); let t = 0, n = 0; r.forEach((v, i) => { if (test(v) && typeof s[i] === "number") { t += s[i]; n++; } }); if (!n) throw "#DIV/0!"; return t / n; },
    LEFT: a => toStr(a[0]).slice(0, a.length > 1 ? toNum(a[1]) : 1),
    RIGHT: a => { const s = toStr(a[0]), n = a.length > 1 ? toNum(a[1]) : 1; return n ? s.slice(-n) : ""; },
    MID: a => toStr(a[0]).substr(toNum(a[1]) - 1, toNum(a[2])),
    SUBSTITUTE: a => toStr(a[0]).split(toStr(a[1])).join(toStr(a[2])),
    PROPER: a => toStr(a[0]).toLowerCase().replace(/(^|\s)\S/g, m => m.toUpperCase()),
    TEXT: a => { const n = toNum(a[0]), f = toStr(a[1]); const d = (f.split(".")[1] || "").replace(/[^0#]/g, "").length; return n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d, useGrouping: f.includes(",") }); },
    VALUE: a => toNum(a[0]),
    ISBLANK: a => a[0] === "" || a[0] == null, ISNUMBER: a => typeof a[0] === "number", ISERROR: a => isErr(a[0]),
    DATE: a => dfmt(new Date(toNum(a[0]), toNum(a[1]) - 1, toNum(a[2]))),
    YEAR: a => D(a[0]).getUTCFullYear(), MONTH: a => D(a[0]).getUTCMonth() + 1, DAY: a => D(a[0]).getUTCDate(),
    DAYS: a => Math.floor(toNum(a[0])) - Math.floor(toNum(a[1])),
    EDATE: a => { const d = D(a[0]); return dfmt(new Date(d.getUTCFullYear(), d.getUTCMonth() + toNum(a[1]), d.getUTCDate())); },
    EOMONTH: a => { const d = D(a[0]); return dfmt(new Date(d.getUTCFullYear(), d.getUTCMonth() + toNum(a[1]) + 1, 0)); },
    WEEKDAY: a => { const w = D(a[0]).getUTCDay(), t = toNum(a[1] ?? 1); return t === 2 ? (w + 6) % 7 + 1 : t === 3 ? (w + 6) % 7 : w + 1; },
    NETWORKDAYS: a => { let s = Math.floor(toNum(a[0])), e = Math.floor(toNum(a[1])), sg = 1; if (s > e) { [s, e] = [e, s]; sg = -1; }
      const hol = new Set(a[2] ? flat([a[2]]).filter(x => x !== "").map(x => Math.floor(toNum(x))) : []); let n = 0;
      for (let d = s; d <= e; d++) { const w = serialToDate(d).getUTCDay(); if (w && w !== 6 && !hol.has(d)) n++; } return n * sg; },
    HOUR: a => { const v = a[0]; if (typeof v === "string" && /^\d{1,2}:\d{2}/.test(v)) return +v.split(":")[0]; return Math.floor((toNum(v) % 1) * 24 + 1e-9); },
    MINUTE: a => { const v = a[0]; if (typeof v === "string" && /^\d{1,2}:\d{2}/.test(v)) return +v.split(":")[1]; return Math.floor(((toNum(v) * 24) % 1) * 60 + 1e-9); },
    SUMPRODUCT: a => { const L = a.map(x => (Array.isArray(x) ? x : [[x]]).flat()); const n = L[0].length; if (L.some(l => l.length !== n)) throw "#VALUE!";
      let t = 0; for (let i = 0; i < n; i++) t += L.reduce((p, l) => p * (typeof l[i] === "number" ? l[i] : 0), 1); return t; },
    IFS: a => { for (let i = 0; i < a.length; i += 2) if (truthy(a[i])) return a[i + 1]; throw "#N/A"; },
    SWITCH: a => { const v = a[0]; let i = 1; for (; i + 1 < a.length; i += 2) if (a[i] === v) return a[i + 1]; if (i < a.length) return a[i]; throw "#N/A"; },
    COUNTIFS: a => { const ok = multi(a, 0); return a[0].flat().filter((_, i) => ok(i)).length; },
    SUMIFS: a => { const ok = multi(a, 1); return a[0].flat().reduce((t, v, i) => t + (ok(i) && typeof v === "number" ? v : 0), 0); },
    AVERAGEIFS: a => { const ok = multi(a, 1); const v = a[0].flat().filter((x, i) => ok(i) && typeof x === "number"); if (!v.length) throw "#DIV/0!"; return v.reduce((x, y) => x + y, 0) / v.length; },
    MAXIFS: a => { const ok = multi(a, 1); const v = a[0].flat().filter((x, i) => ok(i) && typeof x === "number"); return v.length ? Math.max(...v) : 0; },
    MINIFS: a => { const ok = multi(a, 1); const v = a[0].flat().filter((x, i) => ok(i) && typeof x === "number"); return v.length ? Math.min(...v) : 0; },
    UNIQUE: a => { const seen = []; for (const v of flat(a)) if (v !== "" && !seen.includes(v)) seen.push(v); return seen.length ? seen[0] : ""; },
    TEXTJOIN: a => { const sep = toStr(a[0]), skip = truthy(a[1]); return flat(a.slice(2)).map(toStr).filter(x => !skip || x !== "").join(sep); },
    CEILING: a => { const x = toNum(a[0]), s = toNum(a[1] ?? 1); return s ? +(Math.ceil(+(x / s).toPrecision(15)) * s).toPrecision(15) : 0; },
    FLOOR: a => { const x = toNum(a[0]), s = toNum(a[1] ?? 1); if (!s) throw "#DIV/0!"; return +(Math.floor(+(x / s).toPrecision(15)) * s).toPrecision(15); },
    TRUNC: a => round(toNum(a[0]), toNum(a[1] ?? 0), Math.trunc), SIGN: a => Math.sign(toNum(a[0])),
    RAND: () => Math.random(), RANDBETWEEN: a => { const lo = Math.ceil(toNum(a[0])), hi = Math.floor(toNum(a[1])); return lo + Math.floor(Math.random() * (hi - lo + 1)); },
    PI: () => Math.PI, EXP: a => Math.exp(toNum(a[0])), LN: a => { const x = toNum(a[0]); if (x <= 0) throw "#NUM!"; return Math.log(x); },
    LOG10: a => { const x = toNum(a[0]); if (x <= 0) throw "#NUM!"; return Math.log10(x); }, LOG: a => { const x = toNum(a[0]); if (x <= 0) throw "#NUM!"; return Math.log(x) / Math.log(toNum(a[1] ?? 10)); },
    FIND: a => { const i = toStr(a[1]).indexOf(toStr(a[0]), toNum(a[2] ?? 1) - 1); if (i < 0) throw "#VALUE!"; return i + 1; },
    SEARCH: a => { const s = toStr(a[1]).slice(toNum(a[2] ?? 1) - 1), m = new RegExp(wild(a[0]).source.slice(1, -1), "i").exec(s); if (!m) throw "#VALUE!"; return m.index + toNum(a[2] ?? 1); },
    REPT: a => toStr(a[0]).repeat(Math.max(0, toNum(a[1]))), EXACT: a => toStr(a[0]) === toStr(a[1]),
    CHOOSE: a => { const i = toNum(a[0]); if (i < 1 || i >= a.length) throw "#VALUE!"; return a[i]; },
    ISTEXT: a => typeof a[0] === "string" && a[0] !== "", ISNA: a => isErr(a[0]) && a[0].err === "#N/A", N: a => typeof a[0] === "number" ? a[0] : 0,
    LARGE: a => { const n = nums([a[0]]).sort((x, y) => y - x), k = toNum(a[1]); if (k < 1 || k > n.length) throw "#NUM!"; return n[k - 1]; },
    SMALL: a => { const n = nums([a[0]]).sort((x, y) => x - y), k = toNum(a[1]); if (k < 1 || k > n.length) throw "#NUM!"; return n[k - 1]; },
    RANK: a => { const v = toNum(a[0]), n = nums([a[1]]), asc = a[2] && truthy(a[2]); if (!n.includes(v)) throw "#N/A"; return 1 + n.filter(x => asc ? x < v : x > v).length; },
    STDEV: a => { const s = stats(a); if (s.n.length < 2) throw "#DIV/0!"; return Math.sqrt(s.ss / (s.n.length - 1)); },
    STDEVP: a => { const s = stats(a); if (!s.n.length) throw "#DIV/0!"; return Math.sqrt(s.ss / s.n.length); },
    VAR: a => { const s = stats(a); if (s.n.length < 2) throw "#DIV/0!"; return s.ss / (s.n.length - 1); },
    MATCH: a => { const key = a[0], arr = a[1].flat(); const k = typeof key === "string" ? key.toLowerCase() : key; const i = arr.findIndex(v => (typeof v === "string" ? v.toLowerCase() : v) === k); if (i < 0) throw "#N/A"; return i + 1; },
    INDEX: a => { const t = a[0]; if (!Array.isArray(t)) throw "#REF!"; const r = toNum(a[1]), c = a.length > 2 ? toNum(a[2]) : 1; const row = t.length === 1 && a.length === 2 ? t[0] : (t[r - 1] || null); if (!row) throw "#REF!"; const v = t.length === 1 && a.length === 2 ? row[r - 1] : row[c - 1]; if (v === undefined) throw "#REF!"; return v; },
    XLOOKUP: a => { const key = a[0], look = a[1].flat(), ret = a[2]; const k = typeof key === "string" ? key.toLowerCase() : key; const i = look.findIndex(v => (typeof v === "string" ? v.toLowerCase() : v) === k); if (i < 0) { if (a.length > 3) return a[3]; throw "#N/A"; } return ret.length === 1 ? ret[0][i] : ret[i][0]; },
    HLOOKUP: a => { const key = a[0], t = a[1], r = toNum(a[2]); const k = typeof key === "string" ? key.toLowerCase() : key; const i = t[0].findIndex(v => (typeof v === "string" ? v.toLowerCase() : v) === k); if (i < 0) throw "#N/A"; if (!t[r - 1]) throw "#REF!"; return t[r - 1][i]; },
    VLOOKUP: a => {
      const key = a[0], table = a[1], col = toNum(a[2]), exact = a.length > 3 ? !truthy(a[3]) : false;
      if (!Array.isArray(table)) throw "#VALUE!"; if (col < 1 || col > table[0].length) throw "#REF!";
      const k = typeof key === "string" ? key.toLowerCase() : key;
      for (const row of table) { const v = typeof row[0] === "string" ? row[0].toLowerCase() : row[0]; if (v === k) return row[col - 1]; }
      if (!exact) { let best = null; for (const row of table) if (typeof row[0] === "number" && typeof key === "number" && row[0] <= key) best = row; if (best) return best[col - 1]; }
      throw "#N/A";
    },
  };

  const AGG = new Set(["SUM", "AVERAGE", "MIN", "MAX", "COUNT", "PRODUCT", "MEDIAN", "STDEV", "STDEVP", "VAR", "STDEV.S", "STDEV.P", "VAR.S"]);
  FN["RANK.EQ"] = FN.RANK; FN["STDEV.S"] = FN.STDEV; FN["STDEV.P"] = FN.STDEVP; FN["VAR.S"] = FN.VAR; FN["CEILING.MATH"] = FN.CEILING; FN["FLOOR.MATH"] = FN.FLOOR;
  function evaluate(n) {
    switch (n.t) {
      case "lit": return n.v;
      case "ref": { const v = value(n.v); if (isErr(v)) throw v.err; return v; }
      case "range": return rangeVals(n.a, n.b);
      case "neg": return -toNum(evaluate(n.e));
      case "fn": {
        const f = FN[n.name]; if (!f) throw "#NAME?";
        if (n.name === "IFERROR") { let v; try { v = evaluate(n.args[0]); } catch (e) { v = ERR(e); } return isErr(v) ? evaluate(n.args[1]) : v; }
        if (n.name === "IF") { return truthy(evaluate(n.args[0])) ? (n.args[1] ? evaluate(n.args[1]) : true) : (n.args[2] ? evaluate(n.args[2]) : false); }
        if (AGG.has(n.name)) return f(n.args.map(x => x.t === "ref" ? [[evaluate(x)]] : evaluate(x)));   // a cell reference acts like a 1-cell range (text in it is skipped)
        return f(n.args.map(evaluate));
      }
      case "bin": {
        const a = evaluate(n.a), b = evaluate(n.b);
        switch (n.op) {
          case "+": return toNum(a) + toNum(b);
          case "-": return toNum(a) - toNum(b);
          case "*": return toNum(a) * toNum(b);
          case "/": { const d = toNum(b); if (d === 0) throw "#DIV/0!"; return toNum(a) / d; }
          case "^": return Math.pow(toNum(a), toNum(b));
          case "&": return toStr(a) + toStr(b);
          default: {
            let x = typeof a === "string" ? a.toLowerCase() : a, y = typeof b === "string" ? b.toLowerCase() : b;
            if (typeof a === "string" && typeof b === "string" && dateSerial(a) != null && dateSerial(b) != null) { x = dateSerial(a); y = dateSerial(b); }
            switch (n.op) { case "=": return x === y; case "<>": return x !== y; case "<": return x < y; case ">": return x > y; case "<=": return x <= y; case ">=": return x >= y; }
          }
        }
      }
    }
    throw "#VALUE!";
  }
  return { value, reset: () => cache.clear(), literal };
}

// Re-map every cell reference in a formula: fn(col,row) -> [col,row] or null (=#REF!)
// keepRanges: references inside a range (A2:A40) are left alone - used when rows/columns are
// moved or sorted, so =SUM(E2:E40) keeps covering the same block, as in Excel.
function remapFormula(raw, fn, keepRanges, absFixed) {      // absFixed: copy/paste - $A$1 parts don't move
  if (typeof raw !== "string" || !raw.startsWith("=")) return raw;
  let out = "", inStr = false;
  const s = raw;
  let i = 0;
  while (i < s.length) {
    if (s[i] === '"') { inStr = !inStr; out += s[i++]; continue; }
    if (!inStr) {
      const prev = i > 0 ? s[i - 1] : "";
      const R = !keepRanges && !/[A-Za-z0-9_.:]/.test(prev) && /^(\$?)([A-Z]{1,3})(\$?)(\d+):(\$?)([A-Z]{1,3})(\$?)(\d+)/.exec(s.slice(i));
      if (R) {                      // a range like B2:D2: when its edge is deleted it shrinks (Excel), #REF! only if all of it is gone
        const c1 = colToNum(R[2]), r1 = +R[4], c2 = colToNum(R[6]), r2 = +R[8];
        let a = null, z = null;
        for (let c = c1; c <= c2 && !a; c++) for (let r = r1; r <= r2 && !a; r++) a = fn(c, r);
        for (let c = c2; c >= c1 && !z; c--) for (let r = r2; r >= r1 && !z; r--) z = fn(c, r);
        if (absFixed) { const one = (d1, cc, d2, rr) => { const t = fn(colToNum(cc), +rr) || [colToNum(cc), +rr]; return d1 + (d1 ? cc : numToCol(t[0])) + d2 + (d2 ? rr : t[1]); };
          out += one(R[1], R[2], R[3], R[4]) + ":" + one(R[5], R[6], R[7], R[8]); i += R[0].length; continue; }
        out += a && z ? R[1] + numToCol(a[0]) + R[3] + a[1] + ":" + R[5] + numToCol(z[0]) + R[7] + z[1] : "#REF!";
        i += R[0].length; continue;
      }
      const m = /^(\$?)([A-Z]{1,3})(\$?)(\d+)/.exec(s.slice(i));
      if (m && !/[A-Za-z0-9_.]/.test(prev) && !/^[A-Z]{1,3}\d+\s*\(/.test(s.slice(i))) {
        const inRange = prev === ":" || s[i + m[0].length] === ":";
        if (keepRanges && inRange) { out += m[0]; i += m[0].length; continue; }
        const r = fn(colToNum(m[2]), +m[4]);
        if (absFixed && r) { out += m[1] + (m[1] ? m[2] : numToCol(r[0])) + m[3] + (m[3] ? m[4] : r[1]); i += m[0].length; continue; }
        out += r ? m[1] + numToCol(r[0]) + m[3] + r[1] : "#REF!";
        i += m[0].length; continue;
      }
    }
    out += s[i++];
  }
  return out;
}

const api = { dateSerial, makeEngine, tokenize, parse, colToNum, numToCol, parseRef, refName, remapFormula, isErr };
if (typeof module !== "undefined") module.exports = api; else root.MBYFormula = api;
})(this);
