/* MBY Sheet - formula engine (no DOM). Excel-style formulas:
 *   =A1*B1   =SUM(D2:D20)   =IF(C2>10,"Many","Few")   =VLOOKUP(A2,F:G,2,FALSE)
 * Works in the app and in node (tests). */
(function (root) {
"use strict";
const ERR = s => ({ err: s });
const isErr = v => v && typeof v === "object" && "err" in v;

function colToNum(c) { let n = 0; for (const ch of c.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64); return n; }
function numToCol(n) { let s = ""; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }
function parseRef(ref) { const m = /^\$?([A-Z]{1,3})\$?(\d+)$/i.exec(ref); return m ? { c: colToNum(m[1]), r: +m[2] } : null; }
function refName(c, r) { return numToCol(c) + r; }

// ---------------- tokenizer ----------------
function tokenize(src) {
  const t = []; let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '"') { let j = i + 1, s = ""; while (j < src.length) { if (src[j] === '"') { if (src[j + 1] === '"') { s += '"'; j += 2; continue; } break; } s += src[j++]; }
      if (j >= src.length) throw "#VALUE!"; t.push({ k: "str", v: s }); i = j + 1; continue; }
    let m;
    const rest = src.slice(i);
    if ((m = /^(\$?[A-Z]{1,3}\$?\d+)(:\$?[A-Z]{1,3}\$?\d+)?/i.exec(rest)) && !/^[A-Z]{1,3}\d+\(/i.test(rest)) {
      t.push(m[2] ? { k: "range", a: m[1].toUpperCase(), b: m[2].slice(1).toUpperCase() } : { k: "ref", v: m[1].toUpperCase() }); i += m[0].length; continue; }
    if ((m = /^\$?([A-Z]{1,3}):\$?([A-Z]{1,3})(?![\w(])/i.exec(rest))) {         // whole columns  F:G
      t.push({ k: "range", a: m[1].toUpperCase() + "1", b: m[2].toUpperCase() + "100000" }); i += m[0].length; continue; }
    if ((m = /^\d+(\.\d+)?([eE][+-]?\d+)?/.exec(rest))) { t.push({ k: "num", v: parseFloat(m[0]) }); i += m[0].length; continue; }
    if ((m = /^(TRUE|FALSE)(?![\w(])/i.exec(rest))) { t.push({ k: "bool", v: m[1].toUpperCase() === "TRUE" }); i += m[0].length; continue; }
    if ((m = /^([A-Z][A-Z0-9.]*)\s*\(/i.exec(rest))) { t.push({ k: "fn", v: m[1].toUpperCase() }); i += m[0].length; continue; }
    if ((m = /^(<=|>=|<>|[-+*/^&=<>(),%:;])/.exec(rest))) { t.push({ k: "op", v: m[1] === ";" ? "," : m[1] }); i += m[0].length; continue; }
    throw "#NAME?";
  }
  return t;
}

// ---------------- parser (precedence climbing) ----------------
function parse(tokens) {
  let p = 0;
  const peek = () => tokens[p], next = () => tokens[p++];
  const isOp = (v) => peek() && peek().k === "op" && peek().v === v;
  function primary() {
    const tk = next();
    if (!tk) throw "#VALUE!";
    if (tk.k === "num" || tk.k === "str" || tk.k === "bool") return { t: "lit", v: tk.v };
    if (tk.k === "ref") return { t: "ref", v: tk.v };
    if (tk.k === "range") return { t: "range", a: tk.a, b: tk.b };
    if (tk.k === "fn") {
      const args = [];
      if (!isOp(")")) { do { args.push(isOp(",") || isOp(")") ? { t: "lit", v: "" } : expr(0)); } while (isOp(",") && next()); }
      if (!isOp(")")) throw "#VALUE!"; next();
      return { t: "fn", name: tk.v, args };
    }
    if (tk.k === "op" && tk.v === "(") { const e = expr(0); if (!isOp(")")) throw "#VALUE!"; next(); return e; }
    if (tk.k === "op" && (tk.v === "-" || tk.v === "+")) { const e = unary(); return tk.v === "-" ? { t: "neg", e } : e; }
    throw "#VALUE!";
  }
  function unary() { let e = primary(); while (isOp("%")) { next(); e = { t: "bin", op: "/", a: e, b: { t: "lit", v: 100 } }; } return e; }
  const PREC = { "=": 1, "<>": 1, "<": 1, ">": 1, "<=": 1, ">=": 1, "&": 2, "+": 3, "-": 3, "*": 4, "/": 4, "^": 5 };
  function expr(min) {
    let a = unary();
    while (peek() && peek().k === "op" && PREC[peek().v] !== undefined && PREC[peek().v] > min - (peek().v === "^" ? 1 : 0) && PREC[peek().v] >= min) {
      const op = next().v; const prec = PREC[op];
      const b = expr(op === "^" ? prec : prec + 1);
      a = { t: "bin", op, a, b };
    }
    return a;
  }
  const e = expr(0);
  if (p < tokens.length) throw "#VALUE!";
  return e;
}

// ---------------- evaluator ----------------
function makeEngine(getRaw) {
  const cache = new Map(), busy = new Set();
  function toNum(v) {
    if (isErr(v)) throw v.err;
    if (typeof v === "number") return v;
    if (typeof v === "boolean") return v ? 1 : 0;
    if (v === "" || v == null) return 0;
    const n = Number(String(v).replace(/,/g, ""));
    if (isNaN(n)) throw "#VALUE!";
    return n;
  }
  const toStr = v => { if (isErr(v)) throw v.err; if (typeof v === "boolean") return v ? "TRUE" : "FALSE"; return v == null ? "" : String(v); };
  const truthy = v => typeof v === "string" ? (v.toUpperCase() === "TRUE" ? true : v === "" ? false : (() => { throw "#VALUE!"; })()) : !!toNum(v);

  function literal(raw) {
    if (raw == null || raw === "") return "";
    if (typeof raw === "number") return raw;
    const s = String(raw).trim();
    if (/^0\d+$/.test(s) || /^\d{12,}$/.test(s)) return s;      // barcodes / phone numbers stay text
    if (/^[-+]?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?([eE][+-]?\d+)?%?$/.test(s)) { const pc = s.endsWith("%"); const n = Number(s.replace(/[,%]/g, "")); return pc ? n / 100 : n; }
    if (/^(true|false)$/i.test(s)) return s.toUpperCase() === "TRUE";
    return String(raw);
  }

  function value(ref) {
    if (cache.has(ref)) return cache.get(ref);
    const raw = getRaw(ref);
    let v;
    if (typeof raw === "string" && raw.startsWith("=") && raw.length > 1) {
      if (busy.has(ref)) return ERR("#CIRC!");
      busy.add(ref);
      try { v = evaluate(parse(tokenize(raw.slice(1)))); if (Array.isArray(v)) v = v[0] ? v[0][0] : ""; }
      catch (e) { v = ERR(typeof e === "string" ? e : "#VALUE!"); }
      busy.delete(ref);
    } else v = literal(raw);
    cache.set(ref, v);
    return v;
  }

  function rangeVals(a, b) {
    const A = parseRef(a), B = parseRef(b); if (!A || !B) throw "#REF!";
    const r1 = Math.min(A.r, B.r), r2 = Math.min(Math.max(A.r, B.r), getRaw.maxRow ? getRaw.maxRow() : 100000);
    const c1 = Math.min(A.c, B.c), c2 = Math.max(A.c, B.c);
    const out = [];
    for (let r = r1; r <= r2; r++) { const row = []; for (let c = c1; c <= c2; c++) row.push(value(refName(c, r))); out.push(row); }
    return out;
  }
  const flat = args => args.flatMap(a => Array.isArray(a) ? a.flat() : [a]);
  const nums = args => flat(args).filter(v => { if (isErr(v)) throw v.err; return typeof v === "number"; });
  const crit = (c) => { const m = /^(<=|>=|<>|<|>|=)?(.*)$/.exec(String(c)); const op = m[1] || "="; const rhs = literal(m[2]);
    return v => { const a = typeof rhs === "number" ? (typeof v === "number" ? v : NaN) : String(v).toLowerCase(), b = typeof rhs === "number" ? rhs : String(rhs).toLowerCase();
      switch (op) { case "=": return a === b; case "<>": return a !== b; case "<": return a < b; case ">": return a > b; case "<=": return a <= b; default: return a >= b; } }; };
  const round = (n, d, f = Math.round) => { const k = Math.pow(10, d); return f(n * k + (f === Math.round ? 0 : 0)) / k; };

  const FN = {
    SUM: a => nums(a).reduce((x, y) => x + y, 0),
    AVERAGE: a => { const n = nums(a); if (!n.length) throw "#DIV/0!"; return n.reduce((x, y) => x + y, 0) / n.length; },
    MIN: a => { const n = nums(a); return n.length ? Math.min(...n) : 0; },
    MAX: a => { const n = nums(a); return n.length ? Math.max(...n) : 0; },
    COUNT: a => nums(a).length,
    COUNTA: a => flat(a).filter(v => v !== "" && v != null).length,
    IF: a => truthy(a[0]) ? (a.length > 1 ? a[1] : true) : (a.length > 2 ? a[2] : false),
    IFERROR: a => isErr(a[0]) ? a[1] : a[0],
    AND: a => flat(a).every(truthy), OR: a => flat(a).some(truthy), NOT: a => !truthy(a[0]),
    ROUND: a => round(toNum(a[0]), toNum(a[1] ?? 0)),
    ROUNDUP: a => round(toNum(a[0]), toNum(a[1] ?? 0), x => x < 0 ? Math.floor(x) : Math.ceil(x)),
    ROUNDDOWN: a => round(toNum(a[0]), toNum(a[1] ?? 0), Math.trunc),
    INT: a => Math.floor(toNum(a[0])), ABS: a => Math.abs(toNum(a[0])),
    LEN: a => toStr(a[0]).length, UPPER: a => toStr(a[0]).toUpperCase(), LOWER: a => toStr(a[0]).toLowerCase(),
    TRIM: a => toStr(a[0]).trim().replace(/\s+/g, " "),
    CONCAT: a => flat(a).map(toStr).join(""), CONCATENATE: a => flat(a).map(toStr).join(""),
    TODAY: () => { const d = new Date(); return d.toLocaleDateString("en-GB"); },
    NOW: () => new Date().toLocaleString("en-GB"),
    SUMIF: a => { const test = crit(a[1]); const r = a[0].flat(), s = (a[2] || a[0]).flat(); let t = 0; r.forEach((v, i) => { if (test(v) && typeof s[i] === "number") t += s[i]; }); return t; },
    COUNTIF: a => { const test = crit(a[1]); return a[0].flat().filter(v => test(v)).length; },
    VLOOKUP: a => {
      const key = a[0], table = a[1], col = toNum(a[2]), exact = a.length > 3 ? !truthy(a[3]) : false;
      if (!Array.isArray(table)) throw "#VALUE!"; if (col < 1 || col > table[0].length) throw "#REF!";
      const k = typeof key === "string" ? key.toLowerCase() : key;
      for (const row of table) { const v = typeof row[0] === "string" ? row[0].toLowerCase() : row[0]; if (v === k) return row[col - 1]; }
      if (!exact) { let best = null; for (const row of table) if (typeof row[0] === "number" && typeof key === "number" && row[0] <= key) best = row; if (best) return best[col - 1]; }
      throw "#N/A";
    },
  };

  function evaluate(n) {
    switch (n.t) {
      case "lit": return n.v;
      case "ref": { const v = value(n.v); if (isErr(v)) throw v.err; return v; }
      case "range": return rangeVals(n.a, n.b);
      case "neg": return -toNum(evaluate(n.e));
      case "fn": {
        const f = FN[n.name]; if (!f) throw "#NAME?";
        if (n.name === "IFERROR") { let v; try { v = evaluate(n.args[0]); } catch (e) { v = ERR(e); } return isErr(v) ? evaluate(n.args[1]) : v; }
        if (n.name === "IF") { return truthy(evaluate(n.args[0])) ? (n.args[1] ? evaluate(n.args[1]) : true) : (n.args[2] ? evaluate(n.args[2]) : false); }
        return f(n.args.map(evaluate));
      }
      case "bin": {
        const a = evaluate(n.a), b = evaluate(n.b);
        switch (n.op) {
          case "+": return toNum(a) + toNum(b);
          case "-": return toNum(a) - toNum(b);
          case "*": return toNum(a) * toNum(b);
          case "/": { const d = toNum(b); if (d === 0) throw "#DIV/0!"; return toNum(a) / d; }
          case "^": return Math.pow(toNum(a), toNum(b));
          case "&": return toStr(a) + toStr(b);
          default: {
            const x = typeof a === "string" ? a.toLowerCase() : a, y = typeof b === "string" ? b.toLowerCase() : b;
            switch (n.op) { case "=": return x === y; case "<>": return x !== y; case "<": return x < y; case ">": return x > y; case "<=": return x <= y; case ">=": return x >= y; }
          }
        }
      }
    }
    throw "#VALUE!";
  }
  return { value, reset: () => cache.clear(), literal };
}

// Re-map every cell reference in a formula: fn(col,row) -> [col,row] or null (=#REF!)
// keepRanges: references inside a range (A2:A40) are left alone - used when rows/columns are
// moved or sorted, so =SUM(E2:E40) keeps covering the same block, as in Excel.
function remapFormula(raw, fn, keepRanges) {
  if (typeof raw !== "string" || !raw.startsWith("=")) return raw;
  let out = "", inStr = false;
  const s = raw;
  let i = 0;
  while (i < s.length) {
    if (s[i] === '"') { inStr = !inStr; out += s[i++]; continue; }
    if (!inStr) {
      const m = /^(\$?)([A-Z]{1,3})(\$?)(\d+)/.exec(s.slice(i));
      const prev = i > 0 ? s[i - 1] : "";
      if (m && !/[A-Za-z0-9_.]/.test(prev) && !/^[A-Z]{1,3}\d+\s*\(/.test(s.slice(i))) {
        const inRange = prev === ":" || s[i + m[0].length] === ":";
        if (keepRanges && inRange) { out += m[0]; i += m[0].length; continue; }
        const r = fn(colToNum(m[2]), +m[4]);
        out += r ? m[1] + numToCol(r[0]) + m[3] + r[1] : "#REF!";
        i += m[0].length; continue;
      }
    }
    out += s[i++];
  }
  return out;
}

const api = { makeEngine, tokenize, parse, colToNum, numToCol, parseRef, refName, remapFormula, isErr };
if (typeof module !== "undefined") module.exports = api; else root.MBYFormula = api;
})(this);
