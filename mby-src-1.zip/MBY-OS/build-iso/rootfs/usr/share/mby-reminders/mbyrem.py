"""MBY Reminders - shared code: the reminder list and the Google Calendar link.

Reminders live in ~/.local/share/mby-reminders/reminders.json:
  {"id", "text", "when": "YYYY-MM-DD HH:MM", "repeat": "none|daily|weekdays|weekly|monthly",
   "note", "google": true|false, "gsynced": "YYYY-MM-DD HH:MM", "snooze", "done", "done_at"}

Google Calendar works through GNOME Online Accounts (Settings > Online Accounts > Google):
Evolution Data Server keeps the calendar in sync, and this module reads / writes it.
Every call here is defensive: without a Google account (or offline) MBY Reminders keeps
working locally, and reminders are sent to Google later.
"""
import datetime as dt, json, os, time, uuid

DATA = os.path.join(os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")), "mby-reminders")
CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "mby-reminders")
STORE = os.path.join(DATA, "reminders.json")
FMT = "%Y-%m-%d %H:%M"
REPEATS = [("none", "Does not repeat"), ("daily", "Every day"), ("weekdays", "Every weekday (Sun–Thu)"),
           ("weekly", "Every week"), ("monthly", "Every month"), ("yearly", "Every year")]


def fmt(t): return t.strftime(FMT)
def parse(s): return dt.datetime.strptime(s, FMT)


def load():
    try:
        with open(STORE) as f:
            return json.load(f)
    except Exception:
        return []


def save(items):
    os.makedirs(DATA, exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(items, f, indent=1, ensure_ascii=False)
    os.replace(tmp, STORE)


def add(r):
    r = dict(r); r.setdefault("id", uuid.uuid4().hex[:10]); r.setdefault("repeat", "none")
    items = load(); items.append(r); save(items)
    if r.get("google"):
        push_to_google(r)
    return r


def update(r):
    items = [r if x["id"] == r["id"] else x for x in load()]
    save(items)
    if r.get("google") or r.get("gsynced"):
        push_to_google(r)


def delete(rid):
    items = load(); r = next((x for x in items if x["id"] == rid), None)
    save([x for x in items if x["id"] != rid])
    if r and r.get("gsynced"):
        remove_from_google(r)


def next_time(r, after=None):
    """next time for a repeating reminder (None when it does not repeat)"""
    rep = r.get("repeat", "none")
    if rep == "none":
        return None
    if rep == "monthly" and not r.get("day"):
        r["day"] = parse(r["when"]).day                # remembered so the 31st stays the 31st
    t = parse(r["when"]); now = after or dt.datetime.now()
    while t <= now:
        if rep == "daily": t += dt.timedelta(days=1)
        elif rep == "weekly": t += dt.timedelta(weeks=1)
        elif rep == "weekdays":                       # Bahrain / Gulf working week: Sunday-Thursday
            t += dt.timedelta(days=1)
            while t.weekday() in (4, 5):              # skip Friday, Saturday
                t += dt.timedelta(days=1)
        elif rep == "monthly":                        # keeps the original day (31st -> 28/30/31)
            anchor = int(r.get("day") or parse(r["when"]).day)
            m = t.month % 12 + 1; y = t.year + (t.month == 12)
            day = min(anchor, [31, 29 if y % 4 == 0 and (y % 100 or y % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1])
            t = t.replace(year=y, month=m, day=day)
        elif rep == "yearly":
            try: t = t.replace(year=t.year + 1)
            except ValueError: t = t.replace(year=t.year + 1, day=28)
        else:
            return None
    return t


def watch(callback):
    """call callback() when the reminder list changes (the app saved something)"""
    from gi.repository import Gio
    os.makedirs(DATA, exist_ok=True)
    mon = Gio.File.new_for_path(DATA).monitor_directory(Gio.FileMonitorFlags.NONE, None)
    mon.connect("changed", lambda *a: callback())
    return mon


# ======================================================================= Google Calendar (EDS)
_reg = None


def _eds():
    import gi
    gi.require_version("EDataServer", "1.2"); gi.require_version("ECal", "2.0"); gi.require_version("ICalGLib", "3.0")
    from gi.repository import EDataServer, ECal, ICalGLib
    return EDataServer, ECal, ICalGLib


def _registry():
    global _reg
    if _reg is None:
        EDataServer, _, _ = _eds()
        _reg = EDataServer.SourceRegistry.new_sync(None)
    return _reg


def google_calendars():
    """enabled calendars that belong to a Google account in Online Accounts"""
    EDataServer, _, _ = _eds()
    reg = _registry(); out = []
    for s in reg.list_sources(EDataServer.SOURCE_EXTENSION_CALENDAR):
        if not s.get_enabled():
            continue
        backend = s.get_extension(EDataServer.SOURCE_EXTENSION_CALENDAR).get_backend_name() or ""
        parent = reg.ref_source(s.get_parent()) if s.get_parent() else None
        is_goa = parent is not None and parent.has_extension(EDataServer.SOURCE_EXTENSION_GOA)
        if backend == "google" or (is_goa and backend in ("caldav", "webdav")):
            out.append(s)
    return out


def google_connected():
    try:
        return bool(google_calendars())
    except Exception:
        return False


def _target_calendar():
    """the Google calendar to write to: the default calendar if it is Google, else the first one"""
    cals = google_calendars()
    if not cals:
        return None
    try:
        d = _registry().ref_default_calendar()
        for c in cals:
            if d is not None and c.get_uid() == d.get_uid():
                return c
    except Exception:
        pass
    for c in cals:                                   # the account's main calendar (named like the e-mail)
        if "@" in (c.get_display_name() or ""):
            return c
    return cals[0]


def _client(source):
    _, ECal, _ = _eds()
    return ECal.Client.connect_sync(source, ECal.ClientSourceType.EVENTS, 30, None)


def _local_zone():
    _, _, ICalGLib = _eds()
    name = None
    try:
        name = os.path.realpath("/etc/localtime").split("zoneinfo/")[1]
    except Exception:
        pass
    z = ICalGLib.Timezone.get_builtin_timezone(name) if name else None
    return z or ICalGLib.Timezone.get_utc_timezone()


RRULE = {"daily": "FREQ=DAILY", "weekdays": "FREQ=WEEKLY;BYDAY=SU,MO,TU,WE,TH", "weekly": "FREQ=WEEKLY",
         "monthly": "FREQ=MONTHLY", "yearly": "FREQ=YEARLY"}


def _make_component(r):
    _, ECal, ICalGLib = _eds()
    zone = _local_zone()
    start = parse(r["when"])
    ts = int(time.mktime(start.timetuple()))
    comp = ECal.Component.new()
    comp.set_new_vtype(ECal.ComponentVType.EVENT)
    comp.set_uid(f"mby-{r['id']}@mby.os")
    comp.set_summary(ECal.ComponentText.new("🔔 " + r["text"], None))
    if r.get("note"):
        comp.set_descriptions([ECal.ComponentText.new(r["note"], None)])
    it0 = ICalGLib.Time.new_from_timet_with_zone(ts, False, zone)
    it1 = ICalGLib.Time.new_from_timet_with_zone(ts + 15 * 60, False, zone)
    comp.set_dtstart(ECal.ComponentDateTime.new(it0, zone.get_tzid()))
    comp.set_dtend(ECal.ComponentDateTime.new(it1, zone.get_tzid()))
    if r.get("repeat", "none") in RRULE:
        comp.set_rrules([ICalGLib.Recurrence.new_from_string(RRULE[r["repeat"]])])
    alarm = ECal.ComponentAlarm.new()               # the phone reminds at the exact time
    alarm.set_action(ECal.ComponentAlarmAction.DISPLAY)
    alarm.set_description(ECal.ComponentText.new(r["text"], None))
    alarm.set_trigger(ECal.ComponentAlarmTrigger.new_relative(ECal.ComponentAlarmTriggerKind.RELATIVE_START, ICalGLib.Duration.new_null_duration()))
    comp.add_alarm(alarm)
    comp.commit_sequence()
    return comp


def push_to_google(r):
    """create / update / remove the Google copy; on failure it is retried later by sync_pending()"""
    try:
        if r.get("done"):
            if r.get("gsynced"):
                remove_from_google(r)
            return True
        if not r.get("google"):
            return False
        src = _target_calendar()
        if src is None:
            return False
        _, ECal, _ = _eds()
        cl = _client(src)
        ical = _make_component(r).get_icalcomponent()
        uid = f"mby-{r['id']}@mby.os"
        exists = False
        try:
            cl.get_object_sync(uid, None, None); exists = True
        except Exception:
            pass
        if exists:
            cl.modify_object_sync(ical, ECal.ObjModType.ALL, ECal.OperationFlags.NONE, None)
        else:
            cl.create_object_sync(ical, ECal.OperationFlags.NONE, None)
        items = load()
        for x in items:
            if x["id"] == r["id"]:
                x["gsynced"] = fmt(dt.datetime.now()); x["gcal"] = src.get_display_name()
        save(items)
        return True
    except Exception as e:
        print("google push:", e)
        return False


def remove_from_google(r):
    try:
        _, ECal, _ = _eds()
        for src in google_calendars():
            try:
                _client(src).remove_object_sync(f"mby-{r['id']}@mby.os", None, ECal.ObjModType.ALL, ECal.OperationFlags.NONE, None)
            except Exception:
                pass
    except Exception:
        pass


def sync_pending():
    """send reminders that were made offline / before Google was connected"""
    if not google_connected():
        return
    for r in load():
        if r.get("google") and not r.get("done") and not r.get("gsynced"):
            push_to_google(r)


def google_alarms(hours=24):
    """alarms of Google Calendar events between 12 h ago and `hours` ahead:
       [{key, summary, start, fire, where, mby}]"""
    _, ECal, ICalGLib = _eds()
    zone = _local_zone()
    now = int(time.time()); t0, t1 = now - 12 * 3600, now + hours * 3600
    out = []
    for src in google_calendars():
        try:
            cl = _client(src)
        except Exception:
            continue
        found = []

        def cb(icomp, istart, iend, *rest):
            found.append((icomp.clone(), istart, iend))
            return True
        try:
            cl.generate_instances_sync(t0, t1, None, cb)
        except TypeError:
            cl.generate_instances_sync(t0, t1, None, cb, None)
        for icomp, istart, _iend in found:
            comp = ECal.Component.new_from_icalcomponent(icomp)
            if comp is None:
                continue
            tz = istart.get_timezone() or zone
            start_ts = istart.as_timet_with_zone(tz)
            summ = comp.get_summary().get_value() if comp.get_summary() else "Event"
            uid = comp.get_uid() or ""
            loc = comp.get_location() or ""
            for al in comp.get_all_alarms() or []:
                trig = al.get_trigger()
                if trig is None:
                    continue
                kind = trig.get_kind()
                if kind == ECal.ComponentAlarmTriggerKind.ABSOLUTE:
                    fire_ts = trig.get_absolute_time().as_timet()
                else:
                    secs = trig.get_duration().as_int_seconds()
                    fire_ts = start_ts + secs        # RELATIVE_END is rare; treated like start
                key = f"{uid}|{start_ts}|{fire_ts}"
                out.append({"key": key, "summary": summ.replace("🔔 ", ""), "start": dt.datetime.fromtimestamp(start_ts),
                            "fire": dt.datetime.fromtimestamp(fire_ts), "where": loc, "mby": uid.startswith("mby-")})
    return out
