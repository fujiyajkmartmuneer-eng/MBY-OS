// MBY Weather page. Data comes from the host (Open-Meteo); the host also keeps the city list.
const $ = s => document.querySelector(s);
const post = m => { try { window.webkit.messageHandlers.mby.postMessage(JSON.stringify(m)); } catch (e) {} };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let conf = { cities: [], sel: 0, unit: "c" }, data = null, tab = "today", timer = null;

const WMO = c => c === 0 ? ["☀", "Clear"] : c <= 2 ? ["🌤", c === 1 ? "Mainly clear" : "Partly cloudy"] : c === 3 ? ["☁", "Cloudy"]
  : c <= 48 ? ["🌫", "Fog"] : c <= 57 ? ["🌦", "Drizzle"] : c <= 67 ? ["🌧", "Rain"] : c <= 77 ? ["🌨", "Snow"]
  : c <= 82 ? ["🌦", "Showers"] : c <= 86 ? ["🌨", "Snow showers"] : ["⛈", "Thunderstorm"];
const icon = (c, day = 1) => (!day && c <= 2) ? "🌙" : WMO(c)[0];
const T = v => v == null ? "--" : Math.round(v) + "°";
const hm = iso => { const d = new Date(iso); let h = d.getHours(), m = d.getMinutes(); const ap = h >= 12 ? "PM" : "AM"; h = h % 12 || 12; return `${h}:${String(m).padStart(2, "0")} ${ap}`; };
const hh = iso => { let h = new Date(iso).getHours(); const ap = h >= 12 ? "PM" : "AM"; return `${h % 12 || 12} ${ap}`; };
const dname = iso => new Date(iso + "T12:00").toLocaleDateString("en", { weekday: "short" });
const compass = d => ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round(d / 45) % 8];
const arrow = d => ["↓", "↙", "←", "↖", "↑", "↗", "→", "↘"][Math.round(d / 45) % 8];   // where the wind blows to

window.MBY = {
  receive(m) {
    if (m.type === "conf") { conf = m.conf; drawLocs(); load(); }
    else if (m.type === "data") { data = m.data; $("#msg").hidden = true; render(); }
    else if (m.type === "error") { showMsg(m.msg); }
    else if (m.type === "search") { showResults(m.results, m.error); }
  }
};
function showMsg(t) { $("#msg").textContent = t; $("#msg").hidden = false; $("#upd").textContent = "offline"; }
function save() { post({ cmd: "save", cities: conf.cities, sel: conf.sel, unit: conf.unit }); }
function load() { $("#upd").textContent = "updating…"; post({ cmd: "load" }); }
function unitSym() { return conf.unit === "f" ? "°F" : "°C"; }

function drawLocs() {
  const temps = {}; for (const x of (data && data.mine) || []) temps[x.name] = x;
  $("#locs").innerHTML = conf.cities.map((c, i) => `<div class="loc${i === conf.sel ? " on" : ""}" data-i="${i}">
    <span>${i === conf.sel ? "📍 " : ""}${esc(c.name)}<small>${esc(c.region || "")}</small></span><b>${temps[c.name] ? icon(temps[c.name].code) + " " + T(temps[c.name].temp) : ""}</b>
    ${conf.cities.length > 1 ? `<span class="x" data-del="${i}" title="Remove">✕</span>` : ""}</div>`).join("");
  $("#unit").textContent = unitSym();
}
$("#locs").onclick = e => {
  const del = e.target.closest("[data-del]");
  if (del) { const i = +del.dataset.del; conf.cities.splice(i, 1); if (conf.sel >= conf.cities.length) conf.sel = 0; else if (i < conf.sel) conf.sel--; save(); drawLocs(); load(); return; }
  const l = e.target.closest(".loc"); if (!l) return; conf.sel = +l.dataset.i; save(); drawLocs(); load();
};
$("#unit").onclick = () => { conf.unit = conf.unit === "c" ? "f" : "c"; save(); drawLocs(); load(); };
$("#refresh").onclick = load;
document.querySelectorAll(".tabs span").forEach(s => s.onclick = () => { tab = s.dataset.tab; document.querySelectorAll(".tabs span").forEach(x => x.classList.toggle("on", x === s)); if (data) drawChart(); });
// add a city
$("#add").onclick = () => { $("#dlg").hidden = false; $("#q").value = ""; $("#res").innerHTML = ""; $("#q").focus(); };
$("#dclose").onclick = () => $("#dlg").hidden = true;
$("#dlg").onclick = e => { if (e.target.id === "dlg") $("#dlg").hidden = true; };
let qt = null, found = [];
$("#q").oninput = () => { clearTimeout(qt); const q = $("#q").value.trim(); if (q.length < 2) { $("#res").innerHTML = ""; return; } qt = setTimeout(() => { $("#res").innerHTML = `<p class="muted" style="padding:8px">Searching…</p>`; post({ cmd: "search", q }); }, 350); };
$("#q").onkeydown = e => { if (e.key === "Escape") $("#dlg").hidden = true; if (e.key === "Enter" && found[0]) pick(0); };
function showResults(r, err) {
  found = r;
  $("#res").innerHTML = err ? `<p class="muted" style="padding:8px">No internet - can't search right now.</p>` : r.length ? r.map((x, i) => `<div data-i="${i}">📍 ${esc(x.name)}<small>${esc(x.region)}</small></div>`).join("") : `<p class="muted" style="padding:8px">No city found.</p>`;
}
$("#res").onclick = e => { const d = e.target.closest("[data-i]"); if (d) pick(+d.dataset.i); };
function pick(i) { const c = found[i]; conf.cities.push(c); conf.sel = conf.cities.length - 1; save(); $("#dlg").hidden = true; drawLocs(); load(); }

// ---------------------------------------------------------------- render
function nowIndex(h, cur) { const k = cur.slice(0, 13); const i = h.time.findIndex(t => t.slice(0, 13) === k); return i < 0 ? 0 : i; }
function render() {
  const f = data.forecast, c = f.current, d = f.daily, h = f.hourly, u = unitSym(), wu = conf.unit === "f" ? "mph" : "km/h";
  $("#title").textContent = `${data.city.name} weather`;
  $("#upd").textContent = `${new Date(c.time).toLocaleDateString("en", { weekday: "short", day: "numeric", month: "short" })} · updated ${data.fetched}${data.offline ? " · offline (last saved)" : ""}`;
  drawLocs(); $("#cu").textContent = u; $("#chartu").textContent = u;
  $("#now").innerHTML = `<div class="ph">Now</div><div class="big">${Math.round(c.temperature_2m)}<sup>${u}</sup></div><div class="muted">${icon(c.weather_code, c.is_day)} ${WMO(c.weather_code)[1]} · feels ${T(c.apparent_temperature)}</div>`;
  $("#hilo").innerHTML = `<div class="ph">High / Low</div><div class="big" style="font-size:34px">${T(d.temperature_2m_max[0])} <span class="lo">/ ${T(d.temperature_2m_min[0])}</span></div>`;
  $("#wind").innerHTML = `<div class="ph">Wind</div><div class="big" style="font-size:34px">${Math.round(c.wind_speed_10m)}<sup>${wu}</sup></div><div class="muted">${arrow(c.wind_direction_10m)} from ${compass(c.wind_direction_10m)} · gusts ${Math.round(c.wind_gusts_10m)}</div>`;
  $("#pres").innerHTML = `<div class="ph">Pressure</div><div class="big" style="font-size:34px">${Math.round(c.pressure_msl)}</div><div class="muted">hPa</div>`;
  // humidity donut
  const hum = Math.round(c.relative_humidity_2m), L = 2 * Math.PI * 66;
  $("#hum").innerHTML = `<svg width="170" height="170" viewBox="0 0 170 170"><circle cx="85" cy="85" r="66" fill="none" stroke="#e3e5e9" stroke-width="16"/><circle cx="85" cy="85" r="66" fill="none" stroke="#f59e0b" stroke-width="16" stroke-dasharray="${L * hum / 100} ${L}" transform="rotate(-90 85 85)" stroke-linecap="round"/><text x="85" y="92" text-anchor="middle" font-size="30" font-weight="600" fill="#1f2329">${hum}%</text><text x="85" y="112" text-anchor="middle" font-size="11" fill="#8a8f98">dew point ${T(c.dew_point_2m)}</text></svg>`;
  $("#rise").textContent = hm(d.sunrise[0]).replace(/ [AP]M/, ""); $("#set").textContent = hm(d.sunset[0]).replace(/ [AP]M/, "");
  $("#rise").nextElementSibling.textContent = "Sunrise " + hm(d.sunrise[0]).slice(-2); $("#set").nextElementSibling.textContent = "Sunset " + hm(d.sunset[0]).slice(-2);
  const aqi = data.air && data.air.current ? Math.round(data.air.current.us_aqi) : null;
  $("#aqi").textContent = aqi == null ? "--" : aqi;
  $("#aqit").textContent = "AQI · " + (aqi == null ? "n/a" : aqi <= 50 ? "Good" : aqi <= 100 ? "Moderate" : aqi <= 150 ? "Sensitive" : aqi <= 200 ? "Unhealthy" : "Very unhealthy");
  const uv = Math.round(d.uv_index_max[0] || 0); $("#uvs").textContent = uv;
  // UV gauge
  const G = 2 * Math.PI * 58, part = Math.min(uv, 11) / 11 * 0.75;
  $("#uvg").innerHTML = `<defs><linearGradient id="gg"><stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#f97316"/></linearGradient></defs><circle cx="75" cy="75" r="58" fill="none" stroke="#2b2f36" stroke-width="14" stroke-dasharray="${G * .75} ${G}" transform="rotate(135 75 75)" stroke-linecap="round"/><circle cx="75" cy="75" r="58" fill="none" stroke="url(#gg)" stroke-width="14" stroke-linecap="round" stroke-dasharray="${Math.max(G * part, 1)} ${G}" transform="rotate(135 75 75)"/><text x="75" y="84" text-anchor="middle" fill="#fff" font-size="30" font-weight="300">${uv} UV</text>`;
  $("#uvt").innerHTML = uv <= 2 ? "Low.<br>No protection needed." : uv <= 5 ? "Moderate.<br>Sunglasses &amp; cap<br>around midday." : uv <= 7 ? "High.<br>Shade 11 AM – 3 PM,<br>sunscreen." : "Very high.<br>Avoid the sun at midday.";
  // hour by hour (next 10 hours, every 2)
  const i0 = nowIndex(h, c.time), maxW = Math.max(...h.wind_speed_10m.slice(i0, i0 + 12), 1);
  $("#hours").innerHTML = [0, 2, 4, 6, 8].map(k => { const i = i0 + k; if (i >= h.time.length) return "";
    return `<div class="row"><span style="width:50px;color:#9aa0aa">${k ? hh(h.time[i]) : "Now"}</span><span>${icon(h.weather_code[i], h.is_day[i])}</span><span style="width:36px;color:#fff">${T(h.temperature_2m[i])}</span><div class="bar" style="width:${Math.max(8, h.wind_speed_10m[i] / maxW * 180)}px"></div><span style="margin-left:auto;color:#22d3ee">${Math.round(h.wind_speed_10m[i])} ${wu}</span></div>`; }).join("");
  // 7 days
  const lo = Math.min(...d.temperature_2m_min), hi = Math.max(...d.temperature_2m_max), span = Math.max(hi - lo, 1);
  $("#days").innerHTML = d.time.slice(1, 6).map((t, k) => { const i = k + 1;
    return `<div class="day"><span class="d">${dname(t)}</span><span>${icon(d.weather_code[i])}</span><span class="lo">${T(d.temperature_2m_min[i])}</span><div class="track"><i style="left:${(d.temperature_2m_min[i] - lo) / span * 100}%;width:${Math.max(4, (d.temperature_2m_max[i] - d.temperature_2m_min[i]) / span * 100)}%"></i></div><span class="hi">${T(d.temperature_2m_max[i])}</span></div>`; }).join("");
  // rain chance (7 days)
  const pr = d.precipitation_probability_max.map(v => v || 0), xs = k => 18 + k * (258 / 6), ys = v => 140 - v * 1.25;
  const pts = pr.map((v, k) => `${xs(k)},${ys(v)}`).join(" L");
  $("#rain").innerHTML = `<path d="M${pts}" fill="none" stroke="#f97316" stroke-width="2.5"/><path d="M${pts} L${xs(6)},150 L${xs(0)},150Z" fill="#f97316" opacity=".12"/>` +
    pr.map((v, k) => `<text x="${xs(k)}" y="${ys(v) - 7}" fill="#e5e7eb" font-size="10" text-anchor="middle">${v}</text><text x="${xs(k)}" y="166" fill="#7d828c" font-size="10" text-anchor="middle">${dname(d.time[k])}</text>`).join("");
  // Bahrain cities
  const bh = data.bahrain || [], bmax = Math.max(...bh.map(x => x.temp), 1), bmin = Math.min(...bh.map(x => x.temp), 0);
  $("#bh").innerHTML = bh.length ? bh.map(x => `<div class="row"><span style="width:96px">${esc(x.name)}</span><span>${icon(x.code)}</span><div class="bar" style="width:${40 + (x.temp - bmin) / Math.max(bmax - bmin, 1) * 150}px"></div><span style="margin-left:auto;color:#fff">${T(x.temp)}</span></div>`).join("") : `<p class="muted">Not available offline.</p>`;
  // sky glow: warm by day, cool at night
  document.querySelector("#glow stop").setAttribute("stop-color", c.is_day ? "#f59e0b" : "#3b82f6");
  drawChart();
}
function drawChart() {
  const f = data.forecast, h = f.hourly, d = f.daily;
  let a, b, labels, hdr, mark;
  if (tab === "today") {
    const i0 = nowIndex(h, f.current.time);
    a = h.temperature_2m.slice(i0, i0 + 25); b = h.apparent_temperature.slice(i0, i0 + 25);
    labels = a.map((_, k) => k % 4 === 0 ? (k ? hh(h.time[i0 + k]) : "Now") : ""); hdr = "Temperature · next 24 hours";
  } else {
    a = d.temperature_2m_max; b = d.temperature_2m_min; labels = d.time.map(dname); hdr = "High &amp; low · 7 days";
  }
  $("#charth").innerHTML = hdr;
  $(".legend").innerHTML = tab === "today" ? `<span>● Temp</span><span style="color:#f59e0b">● Feels like</span>` : `<span>● High</span><span style="color:#f59e0b">● Low</span>`;
  const all = a.concat(b), lo = Math.min(...all) - 1, hi = Math.max(...all) + 1, W = 740, H = 210, n = a.length;
  const X = k => 10 + k * (W - 20) / (n - 1), Y = v => 20 + (hi - v) / (hi - lo) * (H - 40);
  const path = arr => arr.map((v, k) => (k ? "L" : "M") + X(k).toFixed(1) + " " + Y(v).toFixed(1)).join(" ");
  const imax = a.indexOf(Math.max(...a));
  $("#chart").innerHTML = `<g stroke="#2a2e35"><line x1="0" y1="40" x2="740" y2="40"/><line x1="0" y1="110" x2="740" y2="110"/><line x1="0" y1="180" x2="740" y2="180"/></g>
    <path d="${path(a)}" fill="none" stroke="#e5e7eb" stroke-width="2.5" stroke-linejoin="round"/>
    <path d="${path(b)}" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="6 5"/>
    <circle cx="${X(imax)}" cy="${Y(a[imax])}" r="6" fill="#f59e0b" stroke="#14161a" stroke-width="3"/>
    <text x="${X(imax)}" y="${Y(a[imax]) - 12}" fill="#fff" font-size="13" font-weight="700" text-anchor="middle">${T(a[imax])}</text>
    ${tab === "week" ? b.map((v, k) => `<text x="${X(k)}" y="${Y(v) + 18}" fill="#f59e0b" font-size="11" text-anchor="middle">${T(v)}</text>`).join("") : ""}
    ${labels.map((l, k) => l ? `<text x="${Math.min(Math.max(X(k), 18), W - 22)}" y="240" fill="#7d828c" font-size="11" text-anchor="middle">${l}</text>` : "").join("")}`;
}
// trees
(() => { let s = ""; const tree = (x, base, h, w) => { for (let i = 0; i < 4; i++) { const y = base - h + i * h * .22, ww = w * (.45 + i * .2); s += `<path d="M${x} ${y} L${x + ww / 2} ${y + h * .34} L${x - ww / 2} ${y + h * .34}Z"/>`; } s += `<rect x="${x - 6}" y="${base - h * .02}" width="12" height="${620 - base + h * .02}"/>`; };
  tree(300, 560, 460, 200); tree(170, 600, 300, 140); tree(395, 600, 320, 130); $("#trees").innerHTML = s; })();
timer = setInterval(load, 15 * 60 * 1000);   // refresh every 15 minutes
post({ cmd: "init" });
