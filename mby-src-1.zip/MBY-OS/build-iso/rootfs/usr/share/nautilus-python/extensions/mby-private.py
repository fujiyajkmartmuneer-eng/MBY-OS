"""MBY Private Folder: Lock / Unlock in the Files (File Explorer) right-click menu."""
import os, subprocess
from urllib.parse import unquote
from gi.repository import Nautilus, GObject

MNT = os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "mby-private")

def is_open():
    return os.path.ismount(MNT)

def path_of(f):
    uri = f.get_uri()
    return unquote(uri[7:]) if uri.startswith("file://") else ""

def run(*args):
    subprocess.Popen(["/usr/local/bin/mby-private", *args])

class MbyPrivateMenu(GObject.GObject, Nautilus.MenuProvider):
    def _items(self, inside):
        if is_open():
            i = Nautilus.MenuItem(name="MbyPrivate::Lock", label="🔒 Lock Private Folder")
            i.connect("activate", lambda *_: run("lock"))
            return [i]
        if not inside:
            i = Nautilus.MenuItem(name="MbyPrivate::Unlock", label="🔓 Unlock Private Folder")
            i.connect("activate", lambda *_: run("open"))
            return [i]
        return []

    def get_file_items(self, files):
        # right-click on the Private Folder itself (e.g. in the sidebar location or its parent)
        if len(files) == 1 and path_of(files[0]).rstrip("/") == MNT:
            return self._items(False)
        return []

    def get_background_items(self, folder):
        p = path_of(folder)
        if p == MNT or p.startswith(MNT + "/"):
            return self._items(True)
        # Home folder background: quick Unlock / Lock
        if p.rstrip("/") == os.path.expanduser("~"):
            return self._items(False)
        return []
