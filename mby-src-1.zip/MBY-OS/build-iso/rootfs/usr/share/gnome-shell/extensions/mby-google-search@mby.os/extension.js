/* MBY Google Search - a small search box in the top bar, next to the app name.
 * Type, press Enter: Google opens in the default browser. Esc or a search leaves the box. */
const { St, Clutter, Gio, GLib } = imports.gi;
const Main = imports.ui.main;

const MIN_PANEL_WIDTH = 1150;      // hidden on small screens so the clock and tray keep their room

class Extension {
    enable() {
        this._box = new St.BoxLayout({ style_class: 'mby-gsearch-box', y_align: Clutter.ActorAlign.CENTER });
        this._entry = new St.Entry({
            style_class: 'mby-gsearch',
            hint_text: 'Search Google',
            can_focus: true,
            track_hover: true,
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._entry.set_primary_icon(new St.Label({ text: 'G', style_class: 'mby-gsearch-g', y_align: Clutter.ActorAlign.CENTER }));
        this._box.add_child(this._entry);

        const text = this._entry.clutter_text;
        text.connect('activate', () => this._search());
        text.connect('key-press-event', (a, ev) => {
            if (ev.get_key_symbol() === Clutter.KEY_Escape) { this._leave(); return Clutter.EVENT_STOP; }
            return Clutter.EVENT_PROPAGATE;
        });

        Main.panel._leftBox.add_child(this._box);       // after Activities and the app name
        this._sizeId = Main.panel.connect('notify::width', () => this._fit());
        this._overviewIds = [
            Main.overview.connect('showing', () => this._box.hide()),
            Main.overview.connect('hidden', () => this._fit()),
        ];
        this._fit();
    }

    disable() {
        if (this._sizeId) Main.panel.disconnect(this._sizeId);
        for (const id of this._overviewIds || []) Main.overview.disconnect(id);
        this._overviewIds = null; this._sizeId = 0;
        if (this._box) this._box.destroy();
        this._box = null; this._entry = null;
    }

    _fit() {
        if (!this._box) return;
        this._box.visible = Main.panel.width >= MIN_PANEL_WIDTH && !Main.overview.visible;
    }

    _leave() {
        this._entry.set_text('');
        global.stage.set_key_focus(null);
    }

    _search() {
        const q = this._entry.get_text().trim();
        if (!q) return;
        const looksLikeSite = /^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(q) && !/\s/.test(q);
        const uri = looksLikeSite ? `https://${q}` : `https://www.google.com/search?q=${encodeURIComponent(q)}`;
        try {
            Gio.AppInfo.launch_default_for_uri(uri, global.create_app_launch_context(0, -1));
        } catch (e) {
            Main.notify('Could not open the browser', e.message);
        }
        this._leave();
    }
}

function init() { return new Extension(); }
