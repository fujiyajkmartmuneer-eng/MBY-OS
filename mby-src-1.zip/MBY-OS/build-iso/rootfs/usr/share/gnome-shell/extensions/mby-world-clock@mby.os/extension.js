/* MBY World Clock - India (IST) and Bahrain (AST) time in the top bar.
   GNOME Shell 43/44 (classic imports). */
const { St, GLib, Clutter, Gio } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

const ZONES = [
    { flag: '🇮🇳', short: 'IST', name: 'India', city: 'Kolkata', tz: 'Asia/Kolkata', fmt: '%-I:%M %p' },   // India: 12-hour (2:56 PM)
    { flag: '🇧🇭', short: 'AST', name: 'Bahrain', city: 'Manama', tz: 'Asia/Bahrain', fmt: '%H:%M' },
];

function zoneNow(id) {
    let tz;
    try { tz = GLib.TimeZone.new_identifier(id); } catch (e) { tz = null; }
    if (!tz) tz = GLib.TimeZone.new(id);
    return GLib.DateTime.new_now(tz);
}

class WorldClock {
    constructor() {
        this._button = new PanelMenu.Button(0.5, 'MBY World Clock', false);
        const box = new St.BoxLayout({ style_class: 'mby-wc-pill', y_align: Clutter.ActorAlign.CENTER });
        this._seps = [];
        this._labels = ZONES.map((z, i) => {
            if (i > 0) { const sp = new St.Label({ text: '·', style_class: 'mby-wc-sep', y_align: Clutter.ActorAlign.CENTER }); box.add_child(sp); this._seps[i] = sp; }
            const l = new St.Label({ text: '', style_class: 'mby-wc-time', y_align: Clutter.ActorAlign.CENTER });
            box.add_child(l);
            return l;
        });
        this._button.add_child(box);

        this._rows = ZONES.map(z => {
            const item = new PopupMenu.PopupBaseMenuItem({ reactive: false, style_class: 'mby-wc-row' });
            const col = new St.BoxLayout({ vertical: true, x_expand: true });
            const title = new St.Label({ text: `${z.flag}  ${z.name}`, style_class: 'mby-wc-title' });
            const sub = new St.Label({ text: '', style_class: 'mby-wc-sub' });
            col.add_child(title); col.add_child(sub);
            const big = new St.Label({ text: '', style_class: 'mby-wc-big', y_align: Clutter.ActorAlign.CENTER });
            item.add_child(col); item.add_child(big);
            this._button.menu.addMenuItem(item);
            return { sub, big, z };
        });
        this._button.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const open = new PopupMenu.PopupMenuItem('Open Clocks');
        open.connect('activate', () => {
            try { Gio.DesktopAppInfo.new('org.gnome.clocks.desktop').launch([], null); } catch (e) { logError(e); }
        });
        this._button.menu.addMenuItem(open);

        Main.panel.addToStatusArea('mby-world-clock', this._button, 0, 'right');
        this._update();
        this._mon = Main.layoutManager.connect('monitors-changed', () => this._update());
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 15, () => { this._update(); return GLib.SOURCE_CONTINUE; });
    }

    _update() {
        // the zone the computer already shows in the main clock is not repeated in the top bar (only in the menu),
        // and on a small screen the pill gets short so the top bar never overlaps
        let local = '';
        try { local = GLib.TimeZone.new_local().get_identifier(); } catch (e) {}
        const mon = Main.layoutManager.primaryMonitor, narrow = mon && mon.width / (mon.geometry_scale || 1) < 1400;
        let shown = 0;
        ZONES.forEach((z, i) => {
            const now = zoneNow(z.tz), same = z.tz === local || (local === 'Asia/Riyadh' && z.tz === 'Asia/Bahrain');
            const vis = !same && !(narrow && shown >= 1);
            this._labels[i].visible = vis; if (this._seps[i]) this._seps[i].visible = vis && shown > 0;
            if (vis) shown++;
            this._labels[i].text = narrow ? `${z.flag} ${now.format(z.fmt)}` : `${z.flag} ${z.short} ${now.format(z.fmt)}`;
            const r = this._rows[i];
            r.big.text = now.format(z.fmt);
            r.sub.text = `${z.city} · ${now.format('%a %d %b')} · UTC${now.format('%:z')}`;
        });
        this._button.visible = shown > 0;
    }

    destroy() {
        if (this._timer) { GLib.source_remove(this._timer); this._timer = 0; }
        if (this._mon) { Main.layoutManager.disconnect(this._mon); this._mon = 0; }
        this._button.destroy();
    }
}

class Extension {
    enable() { this._clock = new WorldClock(); }
    disable() { if (this._clock) { this._clock.destroy(); this._clock = null; } }
}

function init() { return new Extension(); }
