/* MBY Rate and Calendars - two small items in the top bar:
   "₹ 233.45"      1 BD in Indian rupees (menu: last update, set an alert rate)
   "15 Jumada II"  today's Hijri date (menu: Hijri, Malayalam and English dates, next holidays)
   The numbers come from mby-rate and mby-calendars (user timers) via ~/.cache. */
const { GLib, Gio, St, Clutter } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;
const cache = n => GLib.build_filenamev([GLib.get_user_cache_dir(), n]);
const read = n => { try { const [ok, d] = GLib.file_get_contents(cache(n)); if (ok) return JSON.parse(new TextDecoder().decode(d)); } catch (e) {} return null; };
const run = a => { try { Gio.Subprocess.new(a, Gio.SubprocessFlags.NONE); } catch (e) { logError(e); } };
const item = (menu, text, cb) => { const i = new PopupMenu.PopupMenuItem(text); if (cb) i.connect('activate', cb); else i.setSensitive(false); menu.addMenuItem(i); };

class Info {
    constructor() {
        this._rate = new PanelMenu.Button(0.5, 'MBY Rate');
        this._rl = new St.Label({ text: '₹ …', y_align: Clutter.ActorAlign.CENTER, style: 'font-weight: bold;' });
        this._rate.add_child(this._rl);
        this._rate.menu.connect('open-state-changed', (_m, o) => { if (o) this._rateMenu(); });
        this._cal = new PanelMenu.Button(0.5, 'MBY Calendars');
        this._cl = new St.Label({ text: '', y_align: Clutter.ActorAlign.CENTER });
        this._cal.add_child(this._cl);
        this._cal.menu.connect('open-state-changed', (_m, o) => { if (o) this._calMenu(); });
        Main.panel.addToStatusArea('mby-rate', this._rate, 2, 'right');
        Main.panel.addToStatusArea('mby-calendars', this._cal, 2, 'center');
        // GNOME does not open an empty menu, so the menus are filled now and refreshed every minute
        this._update();
        this._t = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 60, () => { this._update(); return GLib.SOURCE_CONTINUE; });
    }
    _update() {
        const r = read('mby-rate.json'), c = read('mby-calendars.json');
        if (r) this._rl.text = `₹ ${r.inr.toFixed(2)}` + (r.prev ? (r.inr > r.prev ? ' ▲' : r.inr < r.prev ? ' ▼' : '') : '');
        if (c) this._cl.text = c.hijri_short;
        if (!this._rate.menu.isOpen) this._rateMenu();
        if (!this._cal.menu.isOpen) this._calMenu();
    }
    _rateMenu() {
        const m = this._rate.menu; m.removeAll(); const r = read('mby-rate.json');
        item(m, r ? `1 Bahraini dinar = ₹ ${r.inr.toFixed(2)}` : 'Rate not loaded yet (needs internet)');
        if (r) { item(m, `100 BD = ₹ ${(r.inr * 100).toFixed(0)}`); item(m, `Updated ${r.time}`); }
        m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        item(m, 'Set alert rate…', () => run(['/usr/local/bin/mby-rate', 'set']));
        item(m, 'Refresh now', () => run(['/usr/local/bin/mby-rate']));
    }
    _calMenu() {
        const m = this._cal.menu; m.removeAll(); const c = read('mby-calendars.json');
        if (!c) { item(m, 'Calendars are loading…'); return; }
        item(m, `🕌  ${c.hijri}`); item(m, `🌾  ${c.malayalam_ml}  (${c.malayalam})`); item(m, `📅  ${c.gregorian}`);
        m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Next holidays'));
        for (const h of c.holidays) item(m, `${h.in === 0 ? 'Today' : h.in === 1 ? 'Tomorrow' : 'In ' + h.in + ' days'}  ·  ${h.name}  (${h.date})`);
        item(m, 'Hijri dates can differ by a day from the moon sighting');
    }
    destroy() { if (this._t) GLib.source_remove(this._t); this._rate.destroy(); this._cal.destroy(); }
}
class Extension {
    enable() { this._i = new Info(); }
    disable() { if (this._i) this._i.destroy(); this._i = null; }
}
function init() { return new Extension(); }
