/* MBY Uninstall - adds "Uninstall…" to app right-click menus (GNOME Shell 43/44).
   The menu item runs /usr/local/bin/mby-uninstall, which asks before removing anything. */
const { GLib } = imports.gi;
const AppMenuModule = imports.ui.appMenu;

let _origSetApp = null;
let _enabled = false;

function _isProtected(id) {
    return !id || id.startsWith('mby-') ||
        ['org.gnome.Nautilus.desktop', 'org.gnome.Settings.desktop', 'org.gnome.Terminal.desktop',
         'org.gnome.Software.desktop', 'org.gnome.Extensions.desktop'].includes(id);
}

function _patchedSetApp(app) {
    _origSetApp.call(this, app);
    try {
        this._mbyApp = app;
        if (!this._mbyUninstall) {
            this._mbyUninstall = this.addAction('Uninstall…', () => {
                const id = this._mbyApp ? this._mbyApp.get_id() : null;
                if (_enabled && id)
                    GLib.spawn_command_line_async(`/usr/local/bin/mby-uninstall ${GLib.shell_quote(id)}`);
            });
        }
        this._mbyUninstall.visible = _enabled && !!app && !_isProtected(app.get_id());
    } catch (e) {
        logError(e, 'mby-uninstall');
    }
}

class Extension {
    enable() {
        if (!AppMenuModule || !AppMenuModule.AppMenu || !AppMenuModule.AppMenu.prototype.setApp) return;
        _origSetApp = AppMenuModule.AppMenu.prototype.setApp;
        AppMenuModule.AppMenu.prototype.setApp = _patchedSetApp;
        _enabled = true;
    }
    disable() {
        _enabled = false;
        if (_origSetApp) {
            AppMenuModule.AppMenu.prototype.setApp = _origSetApp;
            _origSetApp = null;
        }
    }
}

function init() { return new Extension(); }
