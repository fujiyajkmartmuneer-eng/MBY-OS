/* MBY AI Button - a small animated infinity sign in the bottom-right corner of the screen.
 * Click it, or press the Copilot key (Shift+Super+F23), to open an "Ask AI" box.
 * The box is connected to the window that was open: its text is read from the screen (OCR) and
 * sent to Claude with the question ("Use this page" can be switched off). Esc or a click elsewhere closes it.
 * Right-click: In front of windows / Behind windows (only shows on the free desktop) / Hide.
 * The choice is kept in ~/.config/mby/ai-orb. The Copilot key works in every mode.
 * The animation pauses while a window is fullscreen, the screen is locked, or the overview is open. */
const { St, Clutter, GLib, Gio, Meta, Shell } = imports.gi;
const Main = imports.ui.main;
const PopupMenu = imports.ui.popupMenu;
const CONF = GLib.build_filenamev([GLib.get_user_config_dir(), 'mby', 'ai-orb']);
const SHOT = GLib.build_filenamev([GLib.get_user_runtime_dir() || GLib.get_tmp_dir(), 'mby-ai-page.png']);
const MODES = [['front', 'In front of windows'], ['back', 'Behind windows (desktop only)'], ['hidden', 'Hide (Copilot key still works)']];

const W = 64, H = 40, MARGIN = 14, FPS = 30;
const KEYS = ['<Shift><Super>F23', '<Shift><Super>XF86TouchpadOff', '<Super>F23', 'F23'];

function point(t) {                         // lemniscate of Bernoulli, centred in the button
    const s = Math.sin(t), d = 1 + s * s, a = W * 0.40;
    return [W / 2 + a * Math.cos(t) / d, H / 2 + a * s * Math.cos(t) / d];
}

function hsl(h, s, l) {                      // -> [r, g, b] in 0..1
    s /= 100; l /= 100;
    const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [f(0), f(8), f(4)];
}

class Extension {
    enable() {
        this._t0 = GLib.get_monotonic_time();
        this._area = new St.DrawingArea({ width: W, height: H, reactive: true, track_hover: true });
        this._area.connect('repaint', a => this._paint(a));
        this._area.connect('button-release-event', (a, ev) => {
            if (ev.get_button() === 3) { this._close(); this._menu.toggle(); }
            else this._toggle();
            return Clutter.EVENT_STOP;
        });
        Main.layoutManager.addChrome(this._area, { affectsStruts: false, trackFullscreen: true });

        this._mode = 'front';
        try {
            const [ok, b] = GLib.file_get_contents(CONF);
            const m = ok ? new TextDecoder().decode(b).trim() : '';
            if (MODES.some(x => x[0] === m)) this._mode = m;
        } catch (e) {}
        this._menu = new PopupMenu.PopupMenu(this._area, 0.5, St.Side.BOTTOM);
        Main.uiGroup.add_actor(this._menu.actor);
        this._menu.actor.hide();
        this._menuMgr = new PopupMenu.PopupMenuManager(this._area);
        this._menuMgr.addMenu(this._menu);
        this._modeItems = {};
        for (const [m, label] of MODES) {
            const it = new PopupMenu.PopupMenuItem(label);
            it.connect('activate', () => this._setMode(m));
            this._menu.addMenuItem(it);
            this._modeItems[m] = it;
        }
        this._menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._menu.addAction('Ask AI…', () => this._toggle());

        this._popup = new St.BoxLayout({ vertical: true, style_class: 'mby-orb-popup', visible: false, reactive: true });
        this._popup.add_child(new St.Label({ text: 'Ask AI', style_class: 'mby-orb-title' }));
        this._entry = new St.Entry({ style_class: 'mby-orb-entry', hint_text: 'Ask anything… (any language)', can_focus: true });
        this._popup.add_child(this._entry);
        this._pageBtn = new St.Button({ style_class: 'mby-orb-page', x_align: Clutter.ActorAlign.START, can_focus: true });
        this._pageBtn.connect('clicked', () => { this._usePage = !this._usePage; this._showPage(); });
        this._popup.add_child(this._pageBtn);
        this._popup.add_child(new St.Label({ text: 'Enter → opens Claude    ·    Esc → close', style_class: 'mby-orb-hint' }));
        Main.layoutManager.addChrome(this._popup, { affectsStruts: false });
        const text = this._entry.clutter_text;
        text.connect('activate', () => this._ask());
        text.connect('key-press-event', (a, ev) => {
            if (ev.get_key_symbol() === Clutter.KEY_Escape) { this._close(); return Clutter.EVENT_STOP; }
            return Clutter.EVENT_PROPAGATE;
        });

        this._accels = [];
        for (const k of KEYS) {
            const id = global.display.grab_accelerator(k, Meta.KeyBindingFlags.NONE);
            if (id > 0) {
                const name = Meta.external_binding_name_for_action(id);
                Main.wm.allowKeybinding(name, Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW);
                this._accels.push([id, name]);
            }
        }
        this._accelId = global.display.connect('accelerator-activated', (d, id) => {
            if (this._accels.some(a => a[0] === id)) this._toggle();
        });

        this._ids = [
            [Main.layoutManager, Main.layoutManager.connect('monitors-changed', () => this._place())],
            [Main.overview, Main.overview.connect('showing', () => this._close())],
        ];
        this._place();
        this._setMode(this._mode, false);
        this._tick = 0;
        this._timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT_IDLE, Math.round(1000 / FPS), () => {
            if (++this._tick % 15 === 0) this._updateVisible();
            if (this._area.visible && this._area.mapped && !Main.sessionMode.isLocked && !Main.overview.visible)
                this._area.queue_repaint();
            return GLib.SOURCE_CONTINUE;
        });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        this._timer = 0;
        this._close();
        for (const [obj, id] of this._ids || []) obj.disconnect(id);
        if (this._accelId) global.display.disconnect(this._accelId);
        for (const [id, name] of this._accels || []) {
            global.display.ungrab_accelerator(id);
            Main.wm.allowKeybinding(name, Shell.ActionMode.NONE);
        }
        this._accels = [];
        this._menu?.destroy();
        this._menu = this._menuMgr = null;
        this._popup?.destroy();
        this._area?.destroy();
        this._popup = this._area = this._entry = null;
    }

    _place() {
        const m = Main.layoutManager.primaryMonitor;
        if (!m) return;
        this._rect = { x: m.x + m.width - W - MARGIN, y: m.y + m.height - H - MARGIN, w: W, h: H };
        this._area.set_position(this._rect.x, this._rect.y);
    }

    _setMode(m, save = true) {
        this._mode = m;
        for (const [k, it] of Object.entries(this._modeItems))
            it.setOrnament(k === m ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
        if (save) {
            try {
                GLib.mkdir_with_parents(GLib.path_get_dirname(CONF), 0o755);
                GLib.file_set_contents(CONF, m + '\n');
            } catch (e) {}
        }
        this._updateVisible();
    }

    // "back" mode: show only when no window covers the corner (the free desktop)
    _updateVisible() {
        if (!this._area) return;
        let show = this._mode !== 'hidden';
        if (show && this._mode === 'back' && this._rect) {
            const ws = global.workspace_manager.get_active_workspace();
            const r = this._rect;
            show = !global.get_window_actors().some(a => {
                const w = a.meta_window;
                if (!w || w.minimized || w.skip_taskbar || !w.located_on_workspace(ws) ||
                    w.get_window_type() !== Meta.WindowType.NORMAL) return false;
                const f = w.get_frame_rect();
                return f.x < r.x + r.w && f.x + f.width > r.x && f.y < r.y + r.h && f.y + f.height > r.y;
            });
        }
        if (show !== this._area.visible) show ? this._area.show() : this._area.hide();
    }

    _showPage() {
        if (!this._page) { this._pageBtn.hide(); return; }
        this._pageBtn.show();
        const t = this._page.title.length > 42 ? this._page.title.slice(0, 41) + '…' : this._page.title;
        this._pageBtn.label = (this._usePage ? '☑  Use this page: ' : '☐  Use this page: ') + t;
    }

    // remember the window that was open and take a picture of it (read with OCR when asking)
    _capturePage() {
        this._page = null;
        const w = global.display.focus_window;
        if (!w || w.skip_taskbar || w.get_window_type() !== Meta.WindowType.NORMAL) return Promise.resolve();
        const title = w.get_title() || w.get_wm_class() || 'window';
        return new Promise(resolve => {
            try {
                const file = Gio.File.new_for_path(SHOT);
                const stream = file.replace(null, false, Gio.FileCreateFlags.NONE, null);
                new Shell.Screenshot().screenshot_window(false, false, stream, (o, res) => {
                    try {
                        o.screenshot_window_finish(res);
                        stream.close(null);
                        this._page = { title };
                    } catch (e) { try { stream.close(null); } catch (e2) {} }
                    resolve();
                });
            } catch (e) { resolve(); }
        });
    }

    _paint(area) {
        const cr = area.get_context();
        const T = (GLib.get_monotonic_time() - this._t0) / 1e6;
        const hover = this._area.hover || this._popup.visible;
        cr.setLineCap(1);                    // round
        // faint full loop
        cr.setSourceRGBA(0.55, 0.62, 0.75, hover ? 0.35 : 0.22);
        cr.setLineWidth(3);
        for (let i = 0; i <= 80; i++) {
            const [x, y] = point(i / 80 * Math.PI * 2);
            i ? cr.lineTo(x, y) : cr.moveTo(x, y);
        }
        cr.stroke();
        // bright comet running along the loop; colour drifts blue -> teal
        const head = T * (hover ? 3.4 : 2.4), hue = 215 - 40 * (0.5 + 0.5 * Math.sin(T * 0.8));
        const N = 36;
        for (let pass = 0; pass < 2; pass++) {          // pass 0 = soft glow, pass 1 = core
            for (let k = N; k > 0; k--) {
                const al = 1 - k / N;
                const [x0, y0] = point(head - k * 0.07), [x1, y1] = point(head - (k - 1) * 0.07);
                const [r, g, b] = hsl(hue, 90, pass ? 58 + 32 * al : 60);
                cr.setSourceRGBA(r, g, b, pass ? al : al * 0.25);
                cr.setLineWidth(pass ? 1.2 + 2.6 * al : 4 + 6 * al);
                cr.moveTo(x0, y0); cr.lineTo(x1, y1); cr.stroke();
            }
        }
        cr.$dispose();
    }

    async _toggle() {
        if (this._popup.visible) { this._close(); return; }
        if (this._opening) return;
        this._opening = true;
        if (Main.overview.visible) Main.overview.hide();
        await this._capturePage();
        this._opening = false;
        if (!this._popup) return;
        this._usePage = !!this._page;
        this._showPage();
        const m = Main.layoutManager.primaryMonitor;
        const ay = this._rect ? this._rect.y : m.y + m.height - H - MARGIN;
        this._popup.show();
        const [, pw] = this._popup.get_preferred_width(-1), [, ph] = this._popup.get_preferred_height(pw);
        this._popup.set_position(Math.max(m.x + 8, m.x + m.width - pw - MARGIN), Math.round(ay - ph - 8));
        this._entry.set_text('');
        try { this._grab = Main.pushModal(this._popup, { actionMode: Shell.ActionMode.POPUP }); } catch (e) { this._grab = null; }
        this._entry.grab_key_focus();
        this._clickId = global.stage.connect('captured-event', (s, ev) => {
            if (ev.type() !== Clutter.EventType.BUTTON_PRESS) return Clutter.EVENT_PROPAGATE;
            const src = ev.get_source();
            if (src && (this._popup.contains(src) || src === this._area)) return Clutter.EVENT_PROPAGATE;
            this._close();
            return Clutter.EVENT_PROPAGATE;
        });
    }

    _close() {
        if (this._clickId) { global.stage.disconnect(this._clickId); this._clickId = 0; }
        if (this._grab) { Main.popModal(this._grab); this._grab = null; }
        this._popup?.hide();
    }

    _ask() {
        const q = this._entry.get_text().trim();
        this._close();
        let argv;
        if (this._page && this._usePage) argv = ['/usr/local/bin/mby-ask-page', q, this._page.title, SHOT];
        else argv = q ? ['/usr/local/bin/mby-ask-claude', q] : ['/usr/local/bin/mby-ask-claude'];
        try { GLib.spawn_async(null, argv, null, GLib.SpawnFlags.SEARCH_PATH, null); }
        catch (e) { Main.notify('MBY AI', 'Could not open Claude: ' + e.message); }
    }
}

function init() { return new Extension(); }
