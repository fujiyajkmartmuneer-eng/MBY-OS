/* MBY Reminders bell - top bar: count of upcoming reminders, the next ones, New reminder. */
const { GLib, Gio, GObject, St, Clutter } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;
const MessageTray = imports.ui.messageTray;

/* Smart suggestions: copy a sentence that mentions a day or a time ("meeting tomorrow 10 AM")
   and a notification offers "Add to Reminders". The text never leaves this computer. */
const TIME_RE = /\b(today|tonight|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d{1,2}([:.]\d{2})?\s?(am|pm)|\d{1,2}:\d{2})\b/i;
class Suggest {
    constructor() { this._last = ''; this._first = true; }
    check() {
        St.Clipboard.get_default().get_text(St.ClipboardType.CLIPBOARD, (_c, text) => {
            if (!text || text === this._last) return;
            this._last = text;
            if (this._first) { this._first = false; return; }   // ignore what was on the clipboard at login
            const t = text.trim();
            if (t.length < 8 || t.length > 160 || !t.includes(' ') || t.includes('\n') || !TIME_RE.test(t)) return;
            this._notify(t);
        });
    }
    _notify(t) {
        if (!this._source) {
            this._source = new MessageTray.Source('Reminders', 'mby-reminders');
            this._source.connect('destroy', () => { this._source = null; });
            Main.messageTray.add(this._source);
        }
        const n = new MessageTray.Notification(this._source, 'Add to Reminders?', t);
        n.setTransient(true);
        n.addAction('Add to Reminders', () => run(['/usr/local/bin/mby-reminders', '--new', '--text', t]));
        this._source.showNotification(n);
    }
    destroy() { if (this._source) this._source.destroy(); this._source = null; }
}

const CACHE = GLib.build_filenamev([GLib.get_user_cache_dir(), 'mby-reminders', 'upcoming.json']);
const run = args => { try { Gio.Subprocess.new(args, Gio.SubprocessFlags.NONE); } catch (e) { logError(e); } };

const Bell = GObject.registerClass(
class Bell extends PanelMenu.Button {
    _init() {
        super._init(0.5, 'Reminders');
        const box = new St.BoxLayout({ style_class: 'panel-status-menu-box' });
        box.add_child(new St.Label({ text: '🔔', y_align: Clutter.ActorAlign.CENTER }));
        this._count = new St.Label({ text: '', y_align: Clutter.ActorAlign.CENTER, style: 'margin-left: 2px; font-weight: bold;' });
        box.add_child(this._count);
        this.add_child(box);
        this.menu.connect('open-state-changed', (_m, open) => { if (open) this._fill(); });
        this._update();
    }
    _read() {
        try { const [ok, d] = GLib.file_get_contents(CACHE); if (ok) return JSON.parse(new TextDecoder().decode(d)); } catch (e) {}
        return { items: [], count: 0, google: false };
    }
    _update() {
        const j = this._read(), overdue = j.items.filter(i => i.overdue).length;
        this._count.text = j.count ? String(j.count) : '';
        this._count.style = 'margin-left: 2px; font-weight: bold;' + (overdue ? ' color: #f87171;' : '');
    }
    _fill() {
        this.menu.removeAll();
        const j = this._read();
        const add = new PopupMenu.PopupMenuItem('＋  New reminder');
        add.connect('activate', () => run(['/usr/local/bin/mby-reminders', '--new']));
        this.menu.addMenuItem(add);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem(j.count ? 'Coming up' : 'No reminders'));
        for (const it of j.items.slice(0, 8)) {
            const mi = new PopupMenu.PopupMenuItem(`${it.overdue ? '⚠️' : '⏰'}  ${it.label}  —  ${it.text}`);
            mi.connect('activate', () => run(['/usr/local/bin/mby-reminders']));
            this.menu.addMenuItem(mi);
        }
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const open = new PopupMenu.PopupMenuItem('Open Reminders' + (j.google ? '   ☁ Google connected' : ''));
        open.connect('activate', () => run(['/usr/local/bin/mby-reminders']));
        this.menu.addMenuItem(open);
    }
});

class Extension {
    enable() {
        this._bell = new Bell();
        Main.panel.addToStatusArea('mby-reminders', this._bell, 1, 'right');
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 15, () => { this._bell._update(); return GLib.SOURCE_CONTINUE; });
        this._suggest = new Suggest();
        this._clip = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => { this._suggest.check(); return GLib.SOURCE_CONTINUE; });
    }
    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        this._timer = 0;
        if (this._clip) GLib.source_remove(this._clip);
        this._clip = 0;
        if (this._suggest) this._suggest.destroy();
        this._suggest = null;
        if (this._bell) this._bell.destroy();
        this._bell = null;
    }
}
function init() { return new Extension(); }
