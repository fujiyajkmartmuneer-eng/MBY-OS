/* MBY Reminders bell - top bar: count of upcoming reminders, the next ones, New reminder. */
const { GLib, Gio, GObject, St, Clutter } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

const CACHE = GLib.build_filenamev([GLib.get_user_cache_dir(), 'mby-reminders', 'upcoming.json']);
const run = args => { try { Gio.Subprocess.new(args, Gio.SubprocessFlags.NONE); } catch (e) { logError(e); } };

const Bell = GObject.registerClass(
class Bell extends PanelMenu.Button {
    _init() {
        super._init(0.5, 'Reminders');
        const box = new St.BoxLayout({ style_class: 'panel-status-menu-box' });
        box.add_child(new St.Label({ text: '🔔', y_align: Clutter.ActorAlign.CENTER }));
        this._count = new St.Label({ text: '', y_align: Clutter.ActorAlign.CENTER, style: 'margin-left: 2px; font-weight: bold;' });
        box.add_child(this._count);
        this.add_child(box);
        this.menu.connect('open-state-changed', (_m, open) => { if (open) this._fill(); });
        this._update();
    }
    _read() {
        try { const [ok, d] = GLib.file_get_contents(CACHE); if (ok) return JSON.parse(new TextDecoder().decode(d)); } catch (e) {}
        return { items: [], count: 0, google: false };
    }
    _update() {
        const j = this._read(), overdue = j.items.filter(i => i.overdue).length;
        this._count.text = j.count ? String(j.count) : '';
        this._count.style = 'margin-left: 2px; font-weight: bold;' + (overdue ? ' color: #f87171;' : '');
    }
    _fill() {
        this.menu.removeAll();
        const j = this._read();
        const add = new PopupMenu.PopupMenuItem('＋  New reminder');
        add.connect('activate', () => run(['/usr/local/bin/mby-reminders', '--new']));
        this.menu.addMenuItem(add);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem(j.count ? 'Coming up' : 'No reminders'));
        for (const it of j.items.slice(0, 8)) {
            const mi = new PopupMenu.PopupMenuItem(`${it.overdue ? '⚠️' : '⏰'}  ${it.label}  —  ${it.text}`);
            mi.connect('activate', () => run(['/usr/local/bin/mby-reminders']));
            this.menu.addMenuItem(mi);
        }
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const open = new PopupMenu.PopupMenuItem('Open Reminders' + (j.google ? '   ☁ Google connected' : ''));
        open.connect('activate', () => run(['/usr/local/bin/mby-reminders']));
        this.menu.addMenuItem(open);
    }
});

class Extension {
    enable() {
        this._bell = new Bell();
        Main.panel.addToStatusArea('mby-reminders', this._bell, 1, 'right');
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 15, () => { this._bell._update(); return GLib.SOURCE_CONTINUE; });
    }
    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        this._timer = 0;
        if (this._bell) this._bell.destroy();
        this._bell = null;
    }
}
function init() { return new Extension(); }
