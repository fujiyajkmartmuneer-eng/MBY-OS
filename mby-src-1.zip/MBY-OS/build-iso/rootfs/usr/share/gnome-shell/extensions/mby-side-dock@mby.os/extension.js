/* MBY Side Dock - Stage Manager-style window organiser for GNOME 43/44.
 *
 * Looks and works like macOS Stage Manager:
 *  the window you are using (and its group) stays in the centre; every other window on
 *  this workspace waits on the left as a tilted thumbnail with its app icon.
 *  - click a thumbnail                      -> it comes to the centre, the current one goes to the side
 *  - drag a thumbnail OUT onto the desktop  -> it joins the windows in the centre (side by side)
 *  - drag a window IN to the left edge      -> it goes to the side dock
 *  - drag a window ONTO a thumbnail         -> it goes INSIDE that group
 *  - drop a thumbnail on another thumbnail  -> the two become one group
 *  - right-click a thumbnail                -> split the group again
 *  - ✕ on a thumbnail                       -> closes that window (or the whole group)
 *  - Win+W or Quick Settings "Side Dock"    -> on / off
 */
const { Clutter, GLib, GObject, Meta, Shell, St } = imports.gi;
const Main = imports.ui.main;
const DND = imports.ui.dnd;
const QuickSettings = imports.ui.quickSettings;
const PopupMenu = imports.ui.popupMenu;
const ExtensionUtils = imports.misc.extensionUtils;

const MARGIN = 10;
const SIZES = [['Small', 100], ['Medium', 130], ['Large', 170]];
const stripW = st => st.get_int('thumb-width') + 30;      // slim, like macOS Stage Manager
const onRight = st => st.get_string('position') === 'right';

function normalWindows() {
    const ws = global.workspace_manager.get_active_workspace();
    return ws.list_windows().filter(w =>
        w.get_window_type() === Meta.WindowType.NORMAL && !w.skip_taskbar && !w.get_transient_for() &&
        !w.is_on_all_workspaces() && w.get_monitor() === Main.layoutManager.primaryIndex);
}

const Thumb = GObject.registerClass(
class Thumb extends St.BoxLayout {
    _init(dock, win) {
        super._init({ vertical: true, reactive: true, track_hover: true, style_class: 'mby-sd-item', x_align: Clutter.ActorAlign.CENTER });
        this._dock = dock; this.metaWindow = win; this._delegate = this;
        const tw = dock._settings.get_int('thumb-width'), th = Math.round(tw * 0.66);
        const group = dock._groupOf(win).slice(0, 3);
        const holder = new St.Widget({ layout_manager: new Clutter.BinLayout(), width: tw, height: th + 10 });
        // a group shows as a small stack of windows, like macOS
        group.slice().reverse().forEach((w, i) => {
            const actor = w.get_compositor_private(); if (!actor) return;
            const r = w.get_frame_rect(), k = group.length - 1 - i;
            const sc = Math.min((tw - 14) / Math.max(r.width, 1), (th - 6) / Math.max(r.height, 1));
            const card = new St.Bin({ style_class: 'mby-sd-card', x_align: Clutter.ActorAlign.START, y_align: Clutter.ActorAlign.START,
                translation_x: k * 7, translation_y: k * 5, opacity: k ? 200 : 255 });
            card.set_child(new Clutter.Clone({ source: actor, width: Math.round(actor.width * sc), height: Math.round(actor.height * sc) }));
            holder.add_child(card);
        });
        const app = Shell.WindowTracker.get_default().get_window_app(win);
        if (app) {
            const badge = new St.Bin({ style_class: 'mby-sd-badge', x_align: Clutter.ActorAlign.START, y_align: Clutter.ActorAlign.END, x_expand: true, y_expand: true });
            badge.set_child(app.create_icon_texture(24));
            holder.add_child(badge);
        }
        const close = new St.Button({ label: '✕', style_class: 'mby-sd-close', x_align: Clutter.ActorAlign.END, y_align: Clutter.ActorAlign.START, x_expand: true, y_expand: true, opacity: 0 });
        close.connect('clicked', () => dock._groupOf(win).forEach(w => w.delete(global.get_current_time())));
        holder.add_child(close);
        const tilt = onRight(dock._settings) ? -16 : 16;
        holder.set_pivot_point(onRight(dock._settings) ? 1 : 0, 0.5);
        holder.rotation_angle_y = tilt;              // Stage Manager tilt (towards the screen centre)
        this._holder = holder;
        this.add_child(holder);
        const label = new St.Label({ text: (app ? app.get_name() : win.get_title() || 'Window') + (group.length > 1 ? `  +${dock._groupOf(win).length - 1}` : ''),
            style_class: 'mby-sd-label', x_align: Clutter.ActorAlign.START });
        label.clutter_text.ellipsize = 3;
        this.add_child(label);
        this.connect('notify::hover', () => {
            close.opacity = this.hover ? 255 : 0;
            holder.ease({ rotation_angle_y: this.hover ? 0 : tilt, scale_x: this.hover ? 1.06 : 1, scale_y: this.hover ? 1.06 : 1,
                duration: 180, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
        });
        this.connect('button-release-event', (a, e) => {
            if (e.get_button() === 3) { dock._openMenu(win); return Clutter.EVENT_STOP; }
            if (e.get_button() === 1 && !this._dragged) dock._bring(win);
            this._dragged = false; return Clutter.EVENT_STOP;
        });
        this._draggable = DND.makeDraggable(this, { restoreOnSuccess: true, manualMode: false, dragActorMaxSize: 160, dragActorOpacity: 220 });
        this._draggable.connect('drag-begin', () => { this._dragged = true; });
        // dropped outside the dock (on the desktop / centre) -> join the windows in the centre
        this._draggable.connect('drag-cancelled', () => {
            const [px] = global.get_pointer();
            if (px < dock._strip.x || px > dock._strip.x + dock._strip.width) GLib.idle_add(GLib.PRIORITY_DEFAULT, () => { dock._addToStage(win); return GLib.SOURCE_REMOVE; });
        });
    }
    getDragActor() { return new Clutter.Clone({ source: this._holder, reactive: false }); }
    getDragActorSource() { return this._holder; }
    containsPointer() {
        const [px, py] = global.get_pointer(), [x, y] = this.get_transformed_position(), [w, h] = this.get_transformed_size();
        return px >= x && px <= x + w && py >= y && py <= y + h;
    }
    handleDragOver(source) {
        if (source === this || !source.metaWindow) return DND.DragMotionResult.NO_DROP;
        this.add_style_class_name('mby-sd-drop');
        if (!this._leaveId) this._leaveId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, () => { this.remove_style_class_name('mby-sd-drop'); this._leaveId = 0; return GLib.SOURCE_REMOVE; });
        return DND.DragMotionResult.MOVE_DROP;
    }
    acceptDrop(source) {
        this.remove_style_class_name('mby-sd-drop');
        if (source === this || !source.metaWindow) return false;
        this._dock._join(this.metaWindow, source.metaWindow);
        return true;
    }
});

class SideDock {
    constructor(settings) {
        this._settings = settings; this._groups = new Map(); this._next = 1; this._ids = [];
        this._strip = new St.BoxLayout({ vertical: true, style_class: 'mby-sd-strip', reactive: true });
        this._scroll = new St.ScrollView({ hscrollbar_policy: St.PolicyType.NEVER, vscrollbar_policy: St.PolicyType.AUTOMATIC, overlay_scrollbars: true, x_expand: true, y_expand: true });
        this._list = new St.BoxLayout({ vertical: true, style: 'spacing: 14px;' });
        this._scroll.add_actor(this._list);
        this._strip.add_child(this._scroll);
        // The strip is real shell chrome: it always gets clicks and drags (a strip hidden inside the
        // window group lost them to the desktop-icons window), and it reserves its own space (a strut)
        // like macOS Stage Manager, so maximized windows / opened files sit beside it instead of over it.
        Main.layoutManager.addChrome(this._strip, { affectsStruts: true, affectsInputRegion: true, trackFullscreen: true });
        this._ids.push([global.display, global.display.connect('restacked', () => this._dodge())]);
        this._place(); this._away = false;
        // after the reserved space is applied, maximized windows move beside the strip: check again
        this._chkId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 800, () => { this._chkId = 0; this._dodge(); return GLib.SOURCE_REMOVE; });
        this._ids.push([settings, settings.connect('changed', (_s, key) => { if (key !== 'enabled') GLib.idle_add(GLib.PRIORITY_DEFAULT, () => { if (this._strip) { this._place(); this._dodge(); this._queue(); } return GLib.SOURCE_REMOVE; }); })]);
        // right-click on the empty part of the Side Dock -> its options
        this._strip.connect('button-release-event', (_a, e) => { if (e.get_button() === 3) { this._openMenu(null); return Clutter.EVENT_STOP; } return Clutter.EVENT_PROPAGATE; });
        const d = global.display, wm = global.workspace_manager;
        this._ids.push([d, d.connect('notify::focus-window', () => this._onFocus())]);
        this._ids.push([d, d.connect('window-created', () => this._queue())]);
        this._ids.push([d, d.connect('grab-op-end', (_d, win) => { this._onDragEnd(win); this._dodge(); })]);
        this._ids.push([wm, wm.connect('active-workspace-changed', () => this._queue())]);
        this._ids.push([Main.layoutManager, Main.layoutManager.connect('monitors-changed', () => { this._place(); this._queue(); })]);
        this._ids.push([global.window_manager, global.window_manager.connect('minimize', () => this._queue())]);
        this._ids.push([global.window_manager, global.window_manager.connect('unminimize', () => this._queue())]);
        this._ids.push([global.window_manager, global.window_manager.connect('destroy', () => this._queue())]);
        this._onFocus();
    }
    _dodge() {                                   // a window moved over the strip by hand: the strip steps aside (unless "keep in front")
        if (!this._strip) return;
        const [sx, sy] = this._strip.get_position(), sw = this._strip.width, sh = this._strip.height;
        const over = !this._settings.get_boolean('on-top') && normalWindows().some(w => { if (w.minimized) return false; const r = w.get_frame_rect();
            return r.x < sx + sw - 4 && r.x + r.width > sx + 4 && r.y < sy + sh && r.y + r.height > sy; });
        if (over === this._away) return;
        this._away = over;
        // the strip itself stays (so its reserved space stays); only its content fades and lets clicks through
        this._strip.reactive = !over;
        if (over) this._scroll.ease({ opacity: 0, duration: 150, mode: Clutter.AnimationMode.EASE_OUT_QUAD, onComplete: () => { if (this._away) this._scroll.hide(); } });
        else { this._scroll.show(); this._scroll.ease({ opacity: 255, duration: 150, mode: Clutter.AnimationMode.EASE_OUT_QUAD }); }
    }
    _watchFocus(win) {                           // follow the window in use while it is moved / resized
        if (this._fw && this._fwIds) this._fwIds.forEach(id => { try { this._fw.disconnect(id); } catch (e) {} });
        this._fw = win; this._fwIds = win ? [win.connect('position-changed', () => this._dodge()), win.connect('size-changed', () => this._dodge())] : null;
        this._dodge();
    }
    _openMenu(win) {                             // right-click menu: the window's actions + Side Dock options
        if (!this._menu) {
            this._menu = new PopupMenu.PopupMenu(this._strip, 0.5, onRight(this._settings) ? St.Side.RIGHT : St.Side.LEFT);
            Main.uiGroup.add_actor(this._menu.actor); this._menu.actor.hide();
            this._menuMgr = new PopupMenu.PopupMenuManager(this._strip); this._menuMgr.addMenu(this._menu);
        }
        const m = this._menu, st = this._settings; m.removeAll();
        const add = (text, cb, on) => { const i = new PopupMenu.PopupMenuItem(text); if (on) i.setOrnament(PopupMenu.Ornament.DOT); i.connect('activate', cb); m.addMenuItem(i); return i; };
        if (win) {
            const g = this._groupOf(win);
            add('Open in the centre', () => this._bring(win));
            if (g.length > 1) add(`Split this group (${g.length} windows)`, () => this._split(win));
            add(g.length > 1 ? 'Close these windows' : 'Close window', () => g.forEach(w => w.delete(global.get_current_time())));
            m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Side Dock'));
        } else m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem('Side Dock options'));
        add('Position: left side', () => st.set_string('position', 'left'), !onRight(st));
        add('Position: right side', () => st.set_string('position', 'right'), onRight(st));
        m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        for (const [name, w] of SIZES) add(`Size: ${name}`, () => st.set_int('thumb-width', w), st.get_int('thumb-width') === w);
        m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const top = new PopupMenu.PopupSwitchMenuItem('Keep in front of windows', st.get_boolean('on-top'));
        top.connect('toggled', (_i, v) => st.set_boolean('on-top', v)); m.addMenuItem(top);
        add('Turn off Side Dock  (Win+W)', () => st.set_boolean('enabled', false));
        m.open(true);
    }
    _place() {
        const m = Main.layoutManager.primaryMonitor; if (!m) return;
        const top = Main.panel.height + MARGIN, bottom = 90;      // leave room for the bottom dock
        const W = stripW(this._settings);
        this._strip.set_position(onRight(this._settings) ? m.x + m.width - W - MARGIN : m.x, m.y + top);   // touches the edge (needed for the reserved space)
        this._strip.set_size(W + MARGIN, m.height - top - bottom);
        this._strip.style = onRight(this._settings) ? `padding-right: ${MARGIN + 6}px;` : `padding-left: ${MARGIN + 6}px;`;
        if (this._menu) { this._menu.destroy(); this._menu = null; }   // re-made on the right side next time
    }
    _groupOf(win) {
        const id = this._groups.get(win);
        return id ? normalWindows().filter(w => this._groups.get(w) === id) : [win];
    }
    _join(a, b) {
        const id = this._groups.get(a) || this._groups.get(b) || this._next++;
        this._groups.set(a, id); this._groups.set(b, id);
        this._queue();
    }
    _split(win) {                                // right-click: take the group apart again
        const g = this._groupOf(win); if (g.length < 2) return;
        g.forEach(w => this._groups.delete(w));
        Main.notify('Side Dock', 'Group split - each window has its own thumbnail again.');
        this._queue();
    }
    _addToStage(win) {                           // thumbnail dragged out -> joins the centre
        const f = global.display.focus_window;
        if (f && normalWindows().includes(f) && f !== win) this._join(f, win);
        this._bring(win);
    }
    _onFocus() {
        const w = global.display.focus_window;
        this._watchFocus(w && normalWindows().includes(w) ? w : null);
        if (w && normalWindows().includes(w)) this._stage(w);
        this._queue();
    }
    _stage(win) {
        const keep = this._groupOf(win);
        for (const w of normalWindows()) if (!keep.includes(w) && !w.minimized) w.minimize();
        if (keep.length > 1) this._tile(keep);
    }
    _bring(win) {
        const group = this._groupOf(win);
        for (const w of group) { w.unminimize(); }
        Main.activateWindow(win);
        if (group.length > 1) this._tile(group);
    }
    _tile(wins) {                                // side by side inside the work area
        const wa = Main.layoutManager.getWorkAreaForMonitor(Main.layoutManager.primaryIndex);
        const n = wins.length, w = Math.floor(wa.width / n);
        wins.forEach((win, i) => {
            if (win.get_maximized()) win.unmaximize(Meta.MaximizeFlags.BOTH);
            win.move_resize_frame(true, wa.x + i * w, wa.y, w, wa.height);
        });
    }
    _onDragEnd(win) {                            // window dropped at the far left -> to the side dock
        if (!win || !normalWindows().includes(win)) return;
        const m = Main.layoutManager.primaryMonitor, r = win.get_frame_rect();
        const [px] = global.get_pointer();
        // dropped ON a thumbnail -> the window goes inside that group
        const target = this._list.get_children().find(t => t.metaWindow && t.metaWindow !== win && t.containsPointer && t.containsPointer());
        if (target) {
            this._join(target.metaWindow, win);
            win.minimize();
            const next = normalWindows().filter(w => !w.minimized).sort((a, b) => b.get_user_time() - a.get_user_time())[0];
            if (next) Main.activateWindow(next);
            return;
        }
        const W = stripW(this._settings);
        const atEdge = onRight(this._settings) ? (px >= m.x + m.width - W - MARGIN && r.x + r.width > m.x + m.width - W - MARGIN)
                                               : (px <= m.x + W + MARGIN && r.x < m.x + W + MARGIN);
        if (atEdge) {
            this._groups.delete(win);
            win.minimize();
            const next = normalWindows().filter(w => !w.minimized).sort((a, b) => b.get_user_time() - a.get_user_time())[0];
            if (next) Main.activateWindow(next);
        }
    }
    _queue() {
        if (this._refreshId) return;
        this._refreshId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 120, () => { this._refreshId = 0; this._refresh(); return GLib.SOURCE_REMOVE; });
    }
    _refresh() {
        this._list.destroy_all_children();
        const focus = global.display.focus_window;
        const stage = focus ? this._groupOf(focus) : [];
        const seen = new Set();
        const side = normalWindows().filter(w => !stage.includes(w)).sort((a, b) => b.get_user_time() - a.get_user_time());
        for (const w of side) {
            if (seen.has(w)) continue;
            this._groupOf(w).forEach(x => seen.add(x));      // one thumbnail per group
            try { this._list.add_child(new Thumb(this, w)); } catch (e) { logError(e, 'mby-side-dock'); }
        }
        if (!side.length) this._list.add_child(new St.Label({ text: 'Other windows wait here\nRight-click for options', style_class: 'mby-sd-empty', x_align: Clutter.ActorAlign.CENTER }));
    }
    destroy() {
        if (this._refreshId) GLib.source_remove(this._refreshId);
        if (this._menu) this._menu.destroy();
        if (this._chkId) { GLib.source_remove(this._chkId); this._chkId = 0; }
        for (const [obj, id] of this._ids) { try { obj.disconnect(id); } catch (e) {} }
        this._watchFocus(null);
        Main.layoutManager.removeChrome(this._strip);
        this._strip.destroy(); this._strip = null;
        // give every window back
        for (const w of normalWindows()) if (w.minimized) w.unminimize();
    }
}

const SideDockToggle = GObject.registerClass(
class SideDockToggle extends QuickSettings.QuickToggle {
    _init(settings) {
        super._init({ label: 'Side Dock', iconName: 'view-sidebar-start-symbolic', toggleMode: true });
        try { this.title = 'Side Dock'; } catch (e) {}
        settings.bind('enabled', this, 'checked', 0);
    }
});
const Indicator = GObject.registerClass(
class Indicator extends QuickSettings.SystemIndicator {
    _init(settings) {
        super._init();
        this.quickSettingsItems.push(new SideDockToggle(settings));
        Main.panel.statusArea.quickSettings._addItems(this.quickSettingsItems);
    }
    destroy() { this.quickSettingsItems.forEach(i => i.destroy()); super.destroy(); }
});

class Extension {
    enable() {
        this._settings = ExtensionUtils.getSettings();
        this._indicator = new Indicator(this._settings);
        this._sid = this._settings.connect('changed::enabled', () => this._sync());
        Main.wm.addKeybinding('toggle-key', this._settings, Meta.KeyBindingFlags.NONE, Shell.ActionMode.NORMAL,
            () => this._settings.set_boolean('enabled', !this._settings.get_boolean('enabled')));
        this._sync();
    }
    _sync() {
        const on = this._settings.get_boolean('enabled');
        if (on && !this._dock) {
            this._dock = new SideDock(this._settings);
            Main.notify('Side Dock is on', 'The window you use stays in the centre; the others wait at the side. Right-click the Side Dock for options. Win+W turns it off.');
        } else if (!on && this._dock) { this._dock.destroy(); this._dock = null; }
    }
    disable() {
        Main.wm.removeKeybinding('toggle-key');
        if (this._sid) this._settings.disconnect(this._sid);
        if (this._dock) this._dock.destroy();
        if (this._indicator) this._indicator.destroy();
        this._dock = null; this._indicator = null; this._settings = null;
    }
}

function init() { return new Extension(); }
