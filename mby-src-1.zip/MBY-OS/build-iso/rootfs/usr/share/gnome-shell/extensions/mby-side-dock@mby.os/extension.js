/* MBY Side Dock - Stage Manager-style window organiser for GNOME 43/44.
 *
 * Looks and works like macOS Stage Manager:
 *  the window you are using (and its group) stays in the centre; every other window on
 *  this workspace waits on the left as a tilted thumbnail with its app icon.
 *  - click a thumbnail                      -> it comes to the centre, the current one goes to the side
 *  - drag a thumbnail OUT onto the desktop  -> it joins the windows in the centre (side by side)
 *  - drag a window IN to the left edge      -> it goes to the side dock
 *  - drag a window ONTO a thumbnail         -> it goes INSIDE that group
 *  - drop a thumbnail on another thumbnail  -> the two become one group
 *  - right-click a thumbnail                -> split the group again
 *  - ✕ on a thumbnail                       -> closes that window (or the whole group)
 *  - Win+W or Quick Settings "Side Dock"    -> on / off
 */
const { Clutter, GLib, GObject, Meta, Shell, St } = imports.gi;
const Main = imports.ui.main;
const DND = imports.ui.dnd;
const QuickSettings = imports.ui.quickSettings;
const ExtensionUtils = imports.misc.extensionUtils;

const STRIP_W = 212, MARGIN = 10;

function normalWindows() {
    const ws = global.workspace_manager.get_active_workspace();
    return ws.list_windows().filter(w =>
        w.get_window_type() === Meta.WindowType.NORMAL && !w.skip_taskbar && !w.get_transient_for() &&
        !w.is_on_all_workspaces() && w.get_monitor() === Main.layoutManager.primaryIndex);
}

const Thumb = GObject.registerClass(
class Thumb extends St.BoxLayout {
    _init(dock, win) {
        super._init({ vertical: true, reactive: true, track_hover: true, style_class: 'mby-sd-item', x_align: Clutter.ActorAlign.CENTER });
        this._dock = dock; this.metaWindow = win; this._delegate = this;
        const tw = dock._settings.get_int('thumb-width'), th = Math.round(tw * 0.66);
        const group = dock._groupOf(win).slice(0, 3);
        const holder = new St.Widget({ layout_manager: new Clutter.BinLayout(), width: tw, height: th + 10 });
        // a group shows as a small stack of windows, like macOS
        group.slice().reverse().forEach((w, i) => {
            const actor = w.get_compositor_private(); if (!actor) return;
            const r = w.get_frame_rect(), k = group.length - 1 - i;
            const sc = Math.min((tw - 14) / Math.max(r.width, 1), (th - 6) / Math.max(r.height, 1));
            const card = new St.Bin({ style_class: 'mby-sd-card', x_align: Clutter.ActorAlign.START, y_align: Clutter.ActorAlign.START,
                translation_x: k * 7, translation_y: k * 5, opacity: k ? 200 : 255 });
            card.set_child(new Clutter.Clone({ source: actor, width: Math.round(actor.width * sc), height: Math.round(actor.height * sc) }));
            holder.add_child(card);
        });
        const app = Shell.WindowTracker.get_default().get_window_app(win);
        if (app) {
            const badge = new St.Bin({ style_class: 'mby-sd-badge', x_align: Clutter.ActorAlign.START, y_align: Clutter.ActorAlign.END, x_expand: true, y_expand: true });
            badge.set_child(app.create_icon_texture(30));
            holder.add_child(badge);
        }
        const close = new St.Button({ label: '✕', style_class: 'mby-sd-close', x_align: Clutter.ActorAlign.END, y_align: Clutter.ActorAlign.START, x_expand: true, y_expand: true, opacity: 0 });
        close.connect('clicked', () => dock._groupOf(win).forEach(w => w.delete(global.get_current_time())));
        holder.add_child(close);
        holder.set_pivot_point(0, 0.5);
        holder.rotation_angle_y = 16;                // Stage Manager tilt
        this._holder = holder;
        this.add_child(holder);
        const label = new St.Label({ text: (app ? app.get_name() : win.get_title() || 'Window') + (group.length > 1 ? `  +${dock._groupOf(win).length - 1}` : ''),
            style_class: 'mby-sd-label', x_align: Clutter.ActorAlign.START });
        label.clutter_text.ellipsize = 3;
        this.add_child(label);
        this.connect('notify::hover', () => {
            close.opacity = this.hover ? 255 : 0;
            holder.ease({ rotation_angle_y: this.hover ? 0 : 16, scale_x: this.hover ? 1.06 : 1, scale_y: this.hover ? 1.06 : 1,
                duration: 180, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
        });
        this.connect('button-release-event', (a, e) => {
            if (e.get_button() === 3) { dock._split(win); return Clutter.EVENT_STOP; }
            if (e.get_button() === 1 && !this._dragged) dock._bring(win);
            this._dragged = false; return Clutter.EVENT_STOP;
        });
        this._draggable = DND.makeDraggable(this, { restoreOnSuccess: true, manualMode: false, dragActorMaxSize: 160, dragActorOpacity: 220 });
        this._draggable.connect('drag-begin', () => { this._dragged = true; });
        // dropped outside the dock (on the desktop / centre) -> join the windows in the centre
        this._draggable.connect('drag-cancelled', () => {
            const [px] = global.get_pointer();
            if (px > dock._strip.x + dock._strip.width) GLib.idle_add(GLib.PRIORITY_DEFAULT, () => { dock._addToStage(win); return GLib.SOURCE_REMOVE; });
        });
    }
    getDragActor() { return new Clutter.Clone({ source: this._holder, reactive: false }); }
    getDragActorSource() { return this._holder; }
    containsPointer() {
        const [px, py] = global.get_pointer(), [x, y] = this.get_transformed_position(), [w, h] = this.get_transformed_size();
        return px >= x && px <= x + w && py >= y && py <= y + h;
    }
    handleDragOver(source) {
        if (source === this || !source.metaWindow) return DND.DragMotionResult.NO_DROP;
        this.add_style_class_name('mby-sd-drop');
        if (!this._leaveId) this._leaveId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, () => { this.remove_style_class_name('mby-sd-drop'); this._leaveId = 0; return GLib.SOURCE_REMOVE; });
        return DND.DragMotionResult.MOVE_DROP;
    }
    acceptDrop(source) {
        this.remove_style_class_name('mby-sd-drop');
        if (source === this || !source.metaWindow) return false;
        this._dock._join(this.metaWindow, source.metaWindow);
        return true;
    }
});

class SideDock {
    constructor(settings) {
        this._settings = settings; this._groups = new Map(); this._next = 1; this._ids = [];
        this._strip = new St.BoxLayout({ vertical: true, style_class: 'mby-sd-strip', reactive: true });
        this._scroll = new St.ScrollView({ hscrollbar_policy: St.PolicyType.NEVER, vscrollbar_policy: St.PolicyType.AUTOMATIC, overlay_scrollbars: true, x_expand: true, y_expand: true });
        this._list = new St.BoxLayout({ vertical: true, style: 'spacing: 14px;' });
        this._scroll.add_actor(this._list);
        this._strip.add_child(this._scroll);
        Main.layoutManager.addChrome(this._strip, { affectsStruts: true, trackFullscreen: true });
        this._place();
        const d = global.display, wm = global.workspace_manager;
        this._ids.push([d, d.connect('notify::focus-window', () => this._onFocus())]);
        this._ids.push([d, d.connect('window-created', () => this._queue())]);
        this._ids.push([d, d.connect('grab-op-end', (_d, win) => this._onDragEnd(win))]);
        this._ids.push([wm, wm.connect('active-workspace-changed', () => this._queue())]);
        this._ids.push([Main.layoutManager, Main.layoutManager.connect('monitors-changed', () => { this._place(); this._queue(); })]);
        this._ids.push([global.window_manager, global.window_manager.connect('minimize', () => this._queue())]);
        this._ids.push([global.window_manager, global.window_manager.connect('unminimize', () => this._queue())]);
        this._ids.push([global.window_manager, global.window_manager.connect('destroy', () => this._queue())]);
        this._onFocus();
    }
    _place() {
        const m = Main.layoutManager.primaryMonitor; if (!m) return;
        const top = Main.panel.height + MARGIN, bottom = 90;      // leave room for the bottom dock
        this._strip.set_position(m.x + MARGIN, m.y + top);
        this._strip.set_size(STRIP_W, m.height - top - bottom);
    }
    _groupOf(win) {
        const id = this._groups.get(win);
        return id ? normalWindows().filter(w => this._groups.get(w) === id) : [win];
    }
    _join(a, b) {
        const id = this._groups.get(a) || this._groups.get(b) || this._next++;
        this._groups.set(a, id); this._groups.set(b, id);
        this._queue();
    }
    _split(win) {                                // right-click: take the group apart again
        const g = this._groupOf(win); if (g.length < 2) return;
        g.forEach(w => this._groups.delete(w));
        Main.notify('Side Dock', 'Group split - each window has its own thumbnail again.');
        this._queue();
    }
    _addToStage(win) {                           // thumbnail dragged out -> joins the centre
        const f = global.display.focus_window;
        if (f && normalWindows().includes(f) && f !== win) this._join(f, win);
        this._bring(win);
    }
    _onFocus() {
        const w = global.display.focus_window;
        if (w && normalWindows().includes(w)) this._stage(w);
        this._queue();
    }
    _stage(win) {
        const keep = this._groupOf(win);
        for (const w of normalWindows()) if (!keep.includes(w) && !w.minimized) w.minimize();
        if (keep.length > 1) this._tile(keep);
    }
    _bring(win) {
        const group = this._groupOf(win);
        for (const w of group) { w.unminimize(); }
        Main.activateWindow(win);
        if (group.length > 1) this._tile(group);
    }
    _tile(wins) {                                // side by side inside the work area
        const wa = Main.layoutManager.getWorkAreaForMonitor(Main.layoutManager.primaryIndex);
        const n = wins.length, w = Math.floor(wa.width / n);
        wins.forEach((win, i) => {
            if (win.get_maximized()) win.unmaximize(Meta.MaximizeFlags.BOTH);
            win.move_resize_frame(true, wa.x + i * w, wa.y, w, wa.height);
        });
    }
    _onDragEnd(win) {                            // window dropped at the far left -> to the side dock
        if (!win || !normalWindows().includes(win)) return;
        const m = Main.layoutManager.primaryMonitor, r = win.get_frame_rect();
        const [px] = global.get_pointer();
        // dropped ON a thumbnail -> the window goes inside that group
        const target = this._list.get_children().find(t => t.metaWindow && t.metaWindow !== win && t.containsPointer && t.containsPointer());
        if (target) {
            this._join(target.metaWindow, win);
            win.minimize();
            const next = normalWindows().filter(w => !w.minimized).sort((a, b) => b.get_user_time() - a.get_user_time())[0];
            if (next) Main.activateWindow(next);
            return;
        }
        if (px <= m.x + STRIP_W + MARGIN && r.x < m.x + STRIP_W) {
            this._groups.delete(win);
            win.minimize();
            const next = normalWindows().filter(w => !w.minimized).sort((a, b) => b.get_user_time() - a.get_user_time())[0];
            if (next) Main.activateWindow(next);
        }
    }
    _queue() {
        if (this._refreshId) return;
        this._refreshId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 120, () => { this._refreshId = 0; this._refresh(); return GLib.SOURCE_REMOVE; });
    }
    _refresh() {
        this._list.destroy_all_children();
        const focus = global.display.focus_window;
        const stage = focus ? this._groupOf(focus) : [];
        const seen = new Set();
        const side = normalWindows().filter(w => !stage.includes(w)).sort((a, b) => b.get_user_time() - a.get_user_time());
        for (const w of side) {
            if (seen.has(w)) continue;
            this._groupOf(w).forEach(x => seen.add(x));      // one thumbnail per group
            try { this._list.add_child(new Thumb(this, w)); } catch (e) { logError(e, 'mby-side-dock'); }
        }
        if (!side.length) this._list.add_child(new St.Label({ text: 'Other open windows\nwill wait here', style_class: 'mby-sd-empty', x_align: Clutter.ActorAlign.CENTER }));
    }
    destroy() {
        if (this._refreshId) GLib.source_remove(this._refreshId);
        for (const [obj, id] of this._ids) { try { obj.disconnect(id); } catch (e) {} }
        Main.layoutManager.removeChrome(this._strip);
        this._strip.destroy();
        // give every window back
        for (const w of normalWindows()) if (w.minimized) w.unminimize();
    }
}

const SideDockToggle = GObject.registerClass(
class SideDockToggle extends QuickSettings.QuickToggle {
    _init(settings) {
        super._init({ label: 'Side Dock', iconName: 'view-sidebar-start-symbolic', toggleMode: true });
        try { this.title = 'Side Dock'; } catch (e) {}
        settings.bind('enabled', this, 'checked', 0);
    }
});
const Indicator = GObject.registerClass(
class Indicator extends QuickSettings.SystemIndicator {
    _init(settings) {
        super._init();
        this.quickSettingsItems.push(new SideDockToggle(settings));
        Main.panel.statusArea.quickSettings._addItems(this.quickSettingsItems);
    }
    destroy() { this.quickSettingsItems.forEach(i => i.destroy()); super.destroy(); }
});

class Extension {
    enable() {
        this._settings = ExtensionUtils.getSettings();
        this._indicator = new Indicator(this._settings);
        this._sid = this._settings.connect('changed::enabled', () => this._sync());
        Main.wm.addKeybinding('toggle-key', this._settings, Meta.KeyBindingFlags.NONE, Shell.ActionMode.NORMAL,
            () => this._settings.set_boolean('enabled', !this._settings.get_boolean('enabled')));
        this._sync();
    }
    _sync() {
        const on = this._settings.get_boolean('enabled');
        if (on && !this._dock) {
            this._dock = new SideDock(this._settings);
            Main.notify('Side Dock is on', 'The window you use stays in the centre; the others wait on the left. Win+W turns it off.');
        } else if (!on && this._dock) { this._dock.destroy(); this._dock = null; }
    }
    disable() {
        Main.wm.removeKeybinding('toggle-key');
        if (this._sid) this._settings.disconnect(this._sid);
        if (this._dock) this._dock.destroy();
        if (this._indicator) this._indicator.destroy();
        this._dock = null; this._indicator = null; this._settings = null;
    }
}

function init() { return new Extension(); }
