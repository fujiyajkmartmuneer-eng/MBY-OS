/* MBY Side Dock - Stage Manager-style window organiser for GNOME 43/44.
 *
 * On:  the window you are using (and its group) stays in the centre; every other
 *      window on this workspace is minimised and waits on the left as a thumbnail.
 *  - click a thumbnail      -> it comes to the centre, the current one goes to the side
 *  - ✕ on a thumbnail       -> closes that window
 *  - drop a thumbnail on another thumbnail -> the two become a group (opened side by side)
 *  - drag a window to the far left edge   -> it goes to the side dock
 *  - Win+W or Quick Settings "Side Dock"  -> on / off
 */
const { Clutter, GLib, GObject, Meta, Shell, St } = imports.gi;
const Main = imports.ui.main;
const DND = imports.ui.dnd;
const QuickSettings = imports.ui.quickSettings;
const ExtensionUtils = imports.misc.extensionUtils;

const STRIP_W = 212, MARGIN = 10;

function normalWindows() {
    const ws = global.workspace_manager.get_active_workspace();
    return ws.list_windows().filter(w =>
        w.get_window_type() === Meta.WindowType.NORMAL && !w.skip_taskbar && !w.get_transient_for() &&
        !w.is_on_all_workspaces() && w.get_monitor() === Main.layoutManager.primaryIndex);
}

const Thumb = GObject.registerClass(
class Thumb extends St.BoxLayout {
    _init(dock, win) {
        super._init({ vertical: true, reactive: true, track_hover: true, style_class: 'mby-sd-item', x_align: Clutter.ActorAlign.CENTER });
        this._dock = dock; this.metaWindow = win; this._delegate = this;
        const tw = dock._settings.get_int('thumb-width');
        const actor = win.get_compositor_private();
        const r = win.get_frame_rect();
        const scale = Math.min(tw / Math.max(r.width, 1), (tw * 0.68) / Math.max(r.height, 1));
        const holder = new St.Widget({ layout_manager: new Clutter.BinLayout(), width: tw, height: Math.round(tw * 0.68) });
        if (actor) {
            const clone = new Clutter.Clone({ source: actor, width: Math.round(actor.width * scale), height: Math.round(actor.height * scale),
                x_align: Clutter.ActorAlign.CENTER, y_align: Clutter.ActorAlign.CENTER, x_expand: true, y_expand: true });
            holder.add_child(clone);
        }
        const close = new St.Button({ label: '✕', style_class: 'mby-sd-close', x_align: Clutter.ActorAlign.END, y_align: Clutter.ActorAlign.START, x_expand: true, y_expand: true, opacity: 0 });
        close.connect('clicked', () => win.delete(global.get_current_time()));
        holder.add_child(close);
        this.add_child(holder);
        const app = Shell.WindowTracker.get_default().get_window_app(win);
        const label = new St.Label({ text: win.get_title() || (app ? app.get_name() : 'Window'), style_class: 'mby-sd-label', x_align: Clutter.ActorAlign.CENTER });
        label.clutter_text.ellipsize = 3;
        this.add_child(label);
        const g = dock._groupOf(win);
        if (g.length > 1) this.add_child(new St.Label({ text: `▣ group of ${g.length}`, style_class: 'mby-sd-group', x_align: Clutter.ActorAlign.CENTER }));
        this.connect('notify::hover', () => {
            close.opacity = this.hover ? 255 : 0;
            this.ease({ scale_x: this.hover ? 1.05 : 1, scale_y: this.hover ? 1.05 : 1, duration: 120, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
        });
        this.set_pivot_point(0.5, 0.5);
        this.connect('button-release-event', (a, e) => { if (e.get_button() === 1 && !this._dragged) dock._bring(win); this._dragged = false; return Clutter.EVENT_STOP; });
        this._draggable = DND.makeDraggable(this, { restoreOnSuccess: true, manualMode: false, dragActorMaxSize: 140, dragActorOpacity: 200 });
        this._draggable.connect('drag-begin', () => { this._dragged = true; });
    }
    getDragActor() { const c = new Clutter.Clone({ source: this, reactive: false }); return c; }
    getDragActorSource() { return this; }
    handleDragOver(source) {
        if (source === this || !source.metaWindow) return DND.DragMotionResult.NO_DROP;
        this.add_style_class_name('mby-sd-drop');
        if (!this._leaveId) this._leaveId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, () => { this.remove_style_class_name('mby-sd-drop'); this._leaveId = 0; return GLib.SOURCE_REMOVE; });
        return DND.DragMotionResult.MOVE_DROP;
    }
    acceptDrop(source) {
        this.remove_style_class_name('mby-sd-drop');
        if (source === this || !source.metaWindow) return false;
        this._dock._join(this.metaWindow, source.metaWindow);
        return true;
    }
});

class SideDock {
    constructor(settings) {
        this._settings = settings; this._groups = new Map(); this._next = 1; this._ids = [];
        this._strip = new St.BoxLayout({ vertical: true, style_class: 'mby-sd-strip', reactive: true });
        try { this._strip.add_effect(new Shell.BlurEffect({ brightness: 0.85, sigma: 30, mode: Shell.BlurMode.BACKGROUND })); } catch (e) {}
        this._scroll = new St.ScrollView({ hscrollbar_policy: St.PolicyType.NEVER, vscrollbar_policy: St.PolicyType.AUTOMATIC, overlay_scrollbars: true, x_expand: true, y_expand: true });
        this._list = new St.BoxLayout({ vertical: true, style: 'spacing: 14px;' });
        this._scroll.add_actor(this._list);
        this._strip.add_child(new St.Label({ text: 'SIDE DOCK', style_class: 'mby-sd-title' }));
        this._strip.add_child(this._scroll);
        Main.layoutManager.addChrome(this._strip, { affectsStruts: true, trackFullscreen: true });
        this._place();
        const d = global.display, wm = global.workspace_manager;
        this._ids.push([d, d.connect('notify::focus-window', () => this._onFocus())]);
        this._ids.push([d, d.connect('window-created', () => this._queue())]);
        this._ids.push([d, d.connect('grab-op-end', (_d, win) => this._onDragEnd(win))]);
        this._ids.push([wm, wm.connect('active-workspace-changed', () => this._queue())]);
        this._ids.push([Main.layoutManager, Main.layoutManager.connect('monitors-changed', () => { this._place(); this._queue(); })]);
        this._ids.push([global.window_manager, global.window_manager.connect('minimize', () => this._queue())]);
        this._ids.push([global.window_manager, global.window_manager.connect('unminimize', () => this._queue())]);
        this._ids.push([global.window_manager, global.window_manager.connect('destroy', () => this._queue())]);
        this._onFocus();
    }
    _place() {
        const m = Main.layoutManager.primaryMonitor; if (!m) return;
        const top = Main.panel.height + MARGIN, bottom = 90;      // leave room for the bottom dock
        this._strip.set_position(m.x + MARGIN, m.y + top);
        this._strip.set_size(STRIP_W, m.height - top - bottom);
    }
    _groupOf(win) {
        const id = this._groups.get(win);
        return id ? normalWindows().filter(w => this._groups.get(w) === id) : [win];
    }
    _join(a, b) {
        const id = this._groups.get(a) || this._groups.get(b) || this._next++;
        this._groups.set(a, id); this._groups.set(b, id);
        this._queue();
    }
    _onFocus() {
        const w = global.display.focus_window;
        if (w && normalWindows().includes(w)) this._stage(w);
        this._queue();
    }
    _stage(win) {
        const keep = this._groupOf(win);
        for (const w of normalWindows()) if (!keep.includes(w) && !w.minimized) w.minimize();
        if (keep.length > 1) this._tile(keep);
    }
    _bring(win) {
        const group = this._groupOf(win);
        for (const w of group) { w.unminimize(); }
        Main.activateWindow(win);
        if (group.length > 1) this._tile(group);
    }
    _tile(wins) {                                // side by side inside the work area
        const wa = Main.layoutManager.getWorkAreaForMonitor(Main.layoutManager.primaryIndex);
        const n = wins.length, w = Math.floor(wa.width / n);
        wins.forEach((win, i) => {
            if (win.get_maximized()) win.unmaximize(Meta.MaximizeFlags.BOTH);
            win.move_resize_frame(true, wa.x + i * w, wa.y, w, wa.height);
        });
    }
    _onDragEnd(win) {                            // window dropped at the far left -> to the side dock
        if (!win || !normalWindows().includes(win)) return;
        const m = Main.layoutManager.primaryMonitor, r = win.get_frame_rect();
        const [px] = global.get_pointer();
        if (px <= m.x + STRIP_W + MARGIN && r.x < m.x + STRIP_W) {
            this._groups.delete(win);
            win.minimize();
            const next = normalWindows().filter(w => !w.minimized).sort((a, b) => b.get_user_time() - a.get_user_time())[0];
            if (next) Main.activateWindow(next);
        }
    }
    _queue() {
        if (this._refreshId) return;
        this._refreshId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 120, () => { this._refreshId = 0; this._refresh(); return GLib.SOURCE_REMOVE; });
    }
    _refresh() {
        this._list.destroy_all_children();
        const focus = global.display.focus_window;
        const stage = focus ? this._groupOf(focus) : [];
        const seen = new Set();
        const side = normalWindows().filter(w => !stage.includes(w)).sort((a, b) => b.get_user_time() - a.get_user_time());
        for (const w of side) {
            if (seen.has(w)) continue;
            this._groupOf(w).forEach(x => seen.add(x));      // one thumbnail per group
            try { this._list.add_child(new Thumb(this, w)); } catch (e) { logError(e, 'mby-side-dock'); }
        }
        if (!side.length) this._list.add_child(new St.Label({ text: 'Other open windows\nwill wait here', style_class: 'mby-sd-empty', x_align: Clutter.ActorAlign.CENTER }));
    }
    destroy() {
        if (this._refreshId) GLib.source_remove(this._refreshId);
        for (const [obj, id] of this._ids) { try { obj.disconnect(id); } catch (e) {} }
        Main.layoutManager.removeChrome(this._strip);
        this._strip.destroy();
        // give every window back
        for (const w of normalWindows()) if (w.minimized) w.unminimize();
    }
}

const SideDockToggle = GObject.registerClass(
class SideDockToggle extends QuickSettings.QuickToggle {
    _init(settings) {
        super._init({ label: 'Side Dock', iconName: 'view-sidebar-start-symbolic', toggleMode: true });
        try { this.title = 'Side Dock'; } catch (e) {}
        settings.bind('enabled', this, 'checked', 0);
    }
});
const Indicator = GObject.registerClass(
class Indicator extends QuickSettings.SystemIndicator {
    _init(settings) {
        super._init();
        this.quickSettingsItems.push(new SideDockToggle(settings));
        Main.panel.statusArea.quickSettings._addItems(this.quickSettingsItems);
    }
    destroy() { this.quickSettingsItems.forEach(i => i.destroy()); super.destroy(); }
});

class Extension {
    enable() {
        this._settings = ExtensionUtils.getSettings();
        this._indicator = new Indicator(this._settings);
        this._sid = this._settings.connect('changed::enabled', () => this._sync());
        Main.wm.addKeybinding('toggle-key', this._settings, Meta.KeyBindingFlags.NONE, Shell.ActionMode.NORMAL,
            () => this._settings.set_boolean('enabled', !this._settings.get_boolean('enabled')));
        this._sync();
    }
    _sync() {
        const on = this._settings.get_boolean('enabled');
        if (on && !this._dock) {
            this._dock = new SideDock(this._settings);
            Main.notify('Side Dock is on', 'The window you use stays in the centre; the others wait on the left. Win+W turns it off.');
        } else if (!on && this._dock) { this._dock.destroy(); this._dock = null; }
    }
    disable() {
        Main.wm.removeKeybinding('toggle-key');
        if (this._sid) this._settings.disconnect(this._sid);
        if (this._dock) this._dock.destroy();
        if (this._indicator) this._indicator.destroy();
        this._dock = null; this._indicator = null; this._settings = null;
    }
}

function init() { return new Extension(); }
