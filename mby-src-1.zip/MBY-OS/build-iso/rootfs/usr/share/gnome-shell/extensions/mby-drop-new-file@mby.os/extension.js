/* MBY Drop to Create - drag an office app from the dock (or the app grid) and drop it on a
 * Files window: a new blank file of that kind is made in that folder,
 * e.g. MBY Sheet -> "New Excel Sheet.xlsx", "New Excel Sheet 2.xlsx", ...
 *
 * Shell drags are internal to GNOME Shell, so Files never sees them. Window actors get a
 * small drop "delegate"; the folder a Files window shows comes from Nautilus over D-Bus
 * (org.freedesktop.FileManager1 OpenWindowsWithLocations), matched to the window by its
 * GTK object path, then by its title. */
const { Gio, GLib } = imports.gi;
const Main = imports.ui.main;
const DND = imports.ui.dnd;

const TEMPLATE_DIRS = () => [GLib.build_filenamev([GLib.get_home_dir(), 'Templates']), '/etc/skel/Templates'];
// app id (lower case) -> template file name
const KINDS = [
    [/sheet|excel|calc|spreadsheet/, 'New Excel Sheet.xlsx'],
    [/powerpoint|impress|presentation|slides/, 'New PowerPoint.pptx'],
    [/word|writer/, 'New Word Document.docx'],
    [/notepad|text-?editor|gedit|geany/, 'New Text File.txt'],
];

function templateFor(app) {
    if (!app || !app.get_id) return null;
    const id = (app.get_id() || '').toLowerCase();
    for (const [re, name] of KINDS) {
        if (!re.test(id)) continue;
        for (const d of TEMPLATE_DIRS()) {
            const p = GLib.build_filenamev([d, name]);
            if (GLib.file_test(p, GLib.FileTest.EXISTS)) return p;
        }
    }
    return null;
}

function appOf(source) {
    if (!source) return null;
    return source.app || (source._delegate && source._delegate.app) || null;
}

function isFiles(win) {
    const c = ((win.get_wm_class && win.get_wm_class()) || '') + ' ' + ((win.get_gtk_application_id && win.get_gtk_application_id()) || '');
    return /nautilus/i.test(c);
}

function isDesktop(win) {
    const c = ((win.get_wm_class && win.get_wm_class()) || '') + ' ' + ((win.get_gtk_application_id && win.get_gtk_application_id()) || '');
    // the desktop-icons window: app id com.rastersoft.ding, title starts with "@!" (its position marker)
    if (/ding|rastersoft/i.test(c) || /^@!/.test(win.get_title() || '')) return true;
    // On Wayland the desktop-icons window carries neither: it is hidden from the window list
    // and covers its whole monitor.
    try {
        if (win.is_skip_taskbar() && !win.get_transient_for()) {
            const r = win.get_frame_rect(), m = global.display.get_monitor_geometry(win.get_monitor());
            if (r.width >= m.width * 0.9 && r.height >= m.height * 0.8) return true;
        }
    } catch (e) {}
    return false;
}

function folderOf(win) {
    if (isDesktop(win)) {
        const d = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP);
        return d ? Gio.File.new_for_path(d) : null;
    }
    let map = {};
    try {
        const r = Gio.DBus.session.call_sync('org.freedesktop.FileManager1', '/org/freedesktop/FileManager1',
            'org.freedesktop.DBus.Properties', 'Get',
            new GLib.Variant('(ss)', ['org.freedesktop.FileManager1', 'OpenWindowsWithLocations']),
            null, Gio.DBusCallFlags.NONE, 1500, null);
        map = r.deepUnpack()[0].deepUnpack();
    } catch (e) { return null; }
    const entries = Object.entries(map).filter(([, locs]) => locs && locs.length);
    const path = win.get_gtk_window_object_path && win.get_gtk_window_object_path();
    let uri = null;
    if (path && map[path] && map[path].length) uri = map[path][0];
    if (!uri) {      // match by title (Files shows the folder name)
        const title = win.get_title() || '';
        const hit = entries.find(([, locs]) => {
            const n = Gio.File.new_for_uri(locs[0]).get_basename();
            return n && (title === n || title.startsWith(n + ' '));
        });
        if (hit) uri = hit[1][0];
    }
    if (!uri && entries.length === 1) uri = entries[0][1][0];
    if (!uri) return null;
    const f = Gio.File.new_for_uri(uri);
    return f.get_path() ? f : null;     // local folders only (not trash:/// or network://)
}

function createIn(folder, templatePath) {
    const tpl = Gio.File.new_for_path(templatePath);
    const base = tpl.get_basename();
    const dot = base.lastIndexOf('.');
    const stem = dot > 0 ? base.slice(0, dot) : base, ext = dot > 0 ? base.slice(dot) : '';
    for (let i = 1; i < 1000; i++) {
        const name = i === 1 ? base : `${stem} ${i}${ext}`;
        const dest = folder.get_child(name);
        if (dest.query_exists(null)) continue;
        tpl.copy(dest, Gio.FileCopyFlags.NONE, null, null);
        return name;
    }
    return null;
}

class Extension {
    enable() {
        this._monitor = { dragMotion: this._onMotion.bind(this) };
        DND.addDragMonitor(this._monitor);
    }

    disable() {
        if (this._monitor) DND.removeDragMonitor(this._monitor);
        this._monitor = null;
        for (const a of global.get_window_actors()) if (a._delegate && a._delegate._mbyDrop) delete a._delegate;
    }

    // while a drag is moving, give the window actor under it a drop handler (only once)
    _onMotion(ev) {
        if (!templateFor(appOf(ev.source))) return DND.DragMotionResult.CONTINUE;
        for (let a = ev.targetActor; a; a = a.get_parent()) {
            if (a.meta_window !== undefined && a.get_meta_window) {
                if (!a._delegate) a._delegate = this._delegate(a);
                break;
            }
        }
        return DND.DragMotionResult.CONTINUE;
    }

    _delegate(actor) {
        const ok = source => {
            const win = actor.get_meta_window && actor.get_meta_window();
            return win && (isFiles(win) || isDesktop(win)) && templateFor(appOf(source)) ? win : null;
        };
        return {
            _mbyDrop: true,
            handleDragOver: source => ok(source) ? DND.DragMotionResult.COPY_DROP : DND.DragMotionResult.CONTINUE,
            acceptDrop: source => {
                const win = ok(source);
                if (!win) return false;
                const tpl = templateFor(appOf(source));
                const folder = folderOf(win);
                if (!folder) {
                    Main.notify('Could not find the folder', 'Open the folder in Files and drop the app onto its window.');
                    return true;
                }
                try {
                    const name = createIn(folder, tpl);
                    if (name) Main.notify(`${name} created`, `in ${folder.get_basename()}`);
                } catch (e) {
                    Main.notify('Could not create the file', e.message);
                }
                return true;
            },
        };
    }
}

function init() { return new Extension(); }
