/* MBY Data Usage: internet data used today / this month (from vnStat) + speed test. GNOME Shell 43/44 */
const { GObject, St, Gio, GLib, Clutter } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;
const Me = imports.misc.extensionUtils.getCurrentExtension();

// virtual / tunnel interfaces would count the same data twice
const SKIP = /^(lo|waydroid|docker|veth|virbr|br-|tun|tap|wg|vboxnet|vmnet|lxc|anbox)/;
const LABEL_MIN_WIDTH = 1300;

function fmt(b) {
    if (b >= 1e12) return (b / 1e12).toFixed(2) + ' TB';
    if (b >= 1e9) return (b / 1e9).toFixed(b >= 1e10 ? 0 : 1) + ' GB';
    if (b >= 1e6) return Math.round(b / 1e6) + ' MB';
    return Math.max(0, Math.round(b / 1e3)) + ' KB';
}

function kind(name) {
    if (/^wl/.test(name)) return 'Wi-Fi';
    if (/^ww/.test(name)) return 'Mobile data';
    if (/^(usb|enx|rndis)/.test(name)) return 'Phone / USB';
    if (/^(en|eth)/.test(name)) return 'Cable (Ethernet)';
    return name;
}

const MbyDataIndicator = GObject.registerClass(
class MbyDataIndicator extends PanelMenu.Button {
    _init() {
        super._init(0.5, 'MBY Data Usage');
        const box = new St.BoxLayout({ style_class: 'panel-status-menu-box' });
        box.add_child(new St.Icon({ gicon: Gio.icon_new_for_string(Me.path + '/data-symbolic.svg'), style_class: 'system-status-icon' }));
        this._label = new St.Label({ text: '', y_align: Clutter.ActorAlign.CENTER, style_class: 'mby-data-label' });
        box.add_child(this._label);
        this.add_child(box);

        const title = new PopupMenu.PopupMenuItem('Internet data used', { reactive: false });
        title.label.add_style_class_name('mby-data-title');
        this.menu.addMenuItem(title);
        this._today = new PopupMenu.PopupMenuItem('Today: …', { reactive: false });
        this._today.label.add_style_class_name('mby-data-big');
        this.menu.addMenuItem(this._today);
        this._todayDetail = new PopupMenu.PopupMenuItem('', { reactive: false });
        this._todayDetail.label.add_style_class_name('mby-data-dim');
        this.menu.addMenuItem(this._todayDetail);
        this._month = new PopupMenu.PopupMenuItem('This month: …', { reactive: false });
        this._month.label.add_style_class_name('mby-data-big');
        this.menu.addMenuItem(this._month);
        this._monthDetail = new PopupMenu.PopupMenuItem('', { reactive: false });
        this._monthDetail.label.add_style_class_name('mby-data-dim');
        this.menu.addMenuItem(this._monthDetail);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._perIf = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._perIf);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const speed = new PopupMenu.PopupImageMenuItem('Internet speed test', 'mby-speedtest');
        speed.connect('activate', () => this._spawn(['/usr/local/bin/mby-speedtest']));
        this.menu.addMenuItem(speed);

        this.menu.connect('open-state-changed', (m, open) => { if (open) this._refresh(); });
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 120, () => {
            this._refresh();
            return GLib.SOURCE_CONTINUE;
        });
        this._monitorsId = Main.layoutManager.connect('monitors-changed', () => this._fitLabel());
        this._fitLabel();
        this._refresh();
    }

    _fitLabel() {
        const m = Main.layoutManager.primaryMonitor;
        this._label.visible = !!m && m.width >= LABEL_MIN_WIDTH;
    }

    _spawn(argv) {
        try {
            Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE);
        } catch (e) {
            logError(e, 'MBY data usage');
        }
    }

    _refresh() {
        let proc;
        try {
            proc = Gio.Subprocess.new(['vnstat', '--json'],
                Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE);
        } catch (e) {
            this._notReady();
            return;
        }
        proc.communicate_utf8_async(null, null, (p, res) => {
            try {
                const [, out] = p.communicate_utf8_finish(res);
                this._show(JSON.parse(out));
            } catch (e) {
                this._notReady();
            }
        });
    }

    _notReady() {
        if (!this._label) return;
        this._label.text = '';
        this._today.label.text = 'Counting has started';
        this._todayDetail.label.text = 'Numbers appear within 5 minutes';
        this._month.label.text = '';
        this._monthDetail.label.text = '';
        this._perIf.removeAll();
    }

    _show(j) {
        if (!this._label) return;
        const now = new Date();
        const y = now.getFullYear(), mo = now.getMonth() + 1, d = now.getDate();
        const td = [0, 0], tm = [0, 0];
        const rows = [];
        for (const i of (j.interfaces || [])) {
            if (!i.name || SKIP.test(i.name)) continue;
            const t = i.traffic || {};
            let a = [0, 0], b = [0, 0];
            for (const x of (t.day || []))
                if (x.date && x.date.year === y && x.date.month === mo && x.date.day === d) a = [x.rx || 0, x.tx || 0];
            for (const x of (t.month || []))
                if (x.date && x.date.year === y && x.date.month === mo) b = [x.rx || 0, x.tx || 0];
            td[0] += a[0]; td[1] += a[1]; tm[0] += b[0]; tm[1] += b[1];
            if (b[0] + b[1] > 0) rows.push([kind(i.name), a[0] + a[1], b[0] + b[1]]);
        }
        this._label.text = fmt(td[0] + td[1]);
        this._today.label.text = 'Today: ' + fmt(td[0] + td[1]);
        this._todayDetail.label.text = '↓ ' + fmt(td[0]) + ' downloaded   ↑ ' + fmt(td[1]) + ' uploaded';
        this._month.label.text = 'This month: ' + fmt(tm[0] + tm[1]);
        this._monthDetail.label.text = '↓ ' + fmt(tm[0]) + ' downloaded   ↑ ' + fmt(tm[1]) + ' uploaded';
        this._perIf.removeAll();
        rows.sort((p, q) => q[2] - p[2]);
        for (const r of rows) {
            const it = new PopupMenu.PopupMenuItem(r[0] + ':  today ' + fmt(r[1]) + ',  month ' + fmt(r[2]), { reactive: false });
            it.label.add_style_class_name('mby-data-dim');
            this._perIf.addMenuItem(it);
        }
    }

    destroy() {
        if (this._timer) {
            GLib.source_remove(this._timer);
            this._timer = 0;
        }
        if (this._monitorsId) {
            Main.layoutManager.disconnect(this._monitorsId);
            this._monitorsId = 0;
        }
        this._label = null;
        super.destroy();
    }
});

class Extension {
    enable() {
        this._ind = new MbyDataIndicator();
        Main.panel.addToStatusArea('mby-data-usage', this._ind, 0, 'right');
    }
    disable() {
        if (this._ind) {
            this._ind.destroy();
            this._ind = null;
        }
    }
}

function init() {
    return new Extension();
}
