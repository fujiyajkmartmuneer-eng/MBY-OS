/* MBY Dock Zoom - macOS-style magnification for the bottom dock (Dash to Dock).
 * The icon under the mouse grows to 160 %, its neighbours to 125 % and 108 %,
 * growing upwards from the dock, with a smooth animation.
 *
 * Dash to Dock clips and offscreen-renders its icon row to the dock's own box, so an icon
 * scaled in place gets its top cut off. Instead, each grown icon is drawn as a Clutter.Clone
 * on an overlay layer just above the dock (nothing clips it there) while the real icon is
 * made invisible underneath. The clones are not reactive, so the mouse still talks to the
 * real dock buttons (clicks, menus, tooltips, drag and drop are unchanged). */
const { GLib, Clutter, St } = imports.gi;
const Main = imports.ui.main;

const SCALES = [1.6, 1.25, 1.08];   // hovered, next, next-but-one
const TIME = 140;                   // ms

class Extension {
    enable() {
        this._items = new Set();
        this._clones = new Map();     // icon -> clone
        this._layer = new St.Widget({ name: 'mbyDockZoomLayer', reactive: false, x: 0, y: 0 });
        Main.layoutManager.uiGroup.add_child(this._layer);
        this._scan();
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => { this._scan(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        if (this._resetId) GLib.source_remove(this._resetId);
        this._timer = 0; this._resetId = 0;
        for (const it of this._items) {
            try {
                it.child.disconnect(it._mbyEnter); it.child.disconnect(it._mbyLeave);
                delete it._mbyEnter; delete it._mbyLeave;
            } catch (e) {}
        }
        this._items.clear();
        for (const icon of [...this._clones.keys()]) this._drop(icon);
        this._layer.destroy();
        this._layer = null;
    }

    _docks() {
        return Main.layoutManager.uiGroup.get_children().filter(a => a.name === 'dashtodockContainer' && a.dash);
    }

    _icon(item) {                     // the picture inside a dock item
        const btn = item.child;
        return btn && btn.icon && btn.icon.icon ? btn.icon.icon : (btn && btn.icon) || null;
    }

    _scan() {
        for (const dock of this._docks()) {
            const box = dock.dash._box;
            if (!box) continue;
            // keep the zoom layer just above the dock (below menus and tooltips added later)
            const ui = Main.layoutManager.uiGroup;
            if (this._layer.get_parent() === ui) ui.set_child_above_sibling(this._layer, dock);
            const items = box.get_children();
            if (dock.dash._showAppsIcon) items.push(dock.dash._showAppsIcon);
            for (const it of items) {
                if (this._items.has(it) || !it.child) continue;
                const btn = it.child;
                it._mbyEnter = btn.connect('enter-event', () => this._zoom(dock, it));
                it._mbyLeave = btn.connect('leave-event', () => this._reset(dock));
                this._items.add(it);
                it.connect('destroy', () => this._items.delete(it));
            }
        }
    }

    _row(dock) {
        const row = dock.dash._box.get_children().filter(c => c.visible && c.child);
        if (dock.dash._showAppsIcon) row.push(dock.dash._showAppsIcon);
        return row;
    }

    // the clone that shows `icon` on the zoom layer, created on first use at the icon's place
    _clone(icon) {
        let c = this._clones.get(icon);
        if (!c) {
            c = new Clutter.Clone({ source: icon, reactive: false });
            c.set_pivot_point(0.5, 1.0);
            this._layer.add_child(c);
            this._clones.set(icon, c);
            c._mbyDestroyId = icon.connect('destroy', () => this._drop(icon));
        }
        const [x, y] = icon.get_transformed_position();
        const [w, h] = icon.get_transformed_size();
        if (w > 0 && h > 0) { c.set_position(Math.round(x), Math.round(y)); c.set_size(w, h); }
        icon.opacity = 0;             // the clone draws it instead
        return c;
    }

    _drop(icon) {
        const c = this._clones.get(icon);
        if (!c) return;
        this._clones.delete(icon);
        try { icon.disconnect(c._mbyDestroyId); } catch (e) {}
        try { icon.opacity = 255; } catch (e) {}
        try { c.remove_all_transitions(); c.destroy(); } catch (e) {}
    }

    _set(item, s) {
        const icon = this._icon(item);
        if (!icon) return;
        if (s === 1.0 && !this._clones.has(icon)) return;
        const c = this._clone(icon);
        c.remove_all_transitions();
        c.ease({
            scale_x: s, scale_y: s, duration: TIME, mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onComplete: () => { if (s === 1.0 && this._clones.get(icon) === c) this._drop(icon); },
        });
    }

    _zoom(dock, hovered) {
        if (this._resetId) { GLib.source_remove(this._resetId); this._resetId = 0; }
        const row = this._row(dock), i = row.indexOf(hovered);
        row.forEach((it, j) => {
            const d = Math.abs(j - i);
            this._set(it, d < SCALES.length ? SCALES[d] : 1.0);
        });
    }

    _reset(dock) {
        // small delay so moving between two icons does not flicker
        if (this._resetId) GLib.source_remove(this._resetId);
        this._resetId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 90, () => {
            this._resetId = 0;
            this._row(dock).forEach(it => this._set(it, 1.0));
            return GLib.SOURCE_REMOVE;
        });
    }
}

function init() { return new Extension(); }
