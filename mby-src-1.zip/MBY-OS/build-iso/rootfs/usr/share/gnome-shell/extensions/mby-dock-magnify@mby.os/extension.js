/* MBY Dock Zoom - macOS-style magnification for the bottom dock (Dash to Dock).
 * The icon under the mouse grows to 160 %, its neighbours to 125 % and 108 %,
 * growing upwards from the dock, with a smooth animation. */
const { GLib, Clutter } = imports.gi;
const Main = imports.ui.main;

const SCALES = [1.6, 1.25, 1.08];   // hovered, next, next-but-one
const TIME = 140;                   // ms

class Extension {
    enable() {
        this._items = new Set();
        this._clipped = new Set();
        this._scan();
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => { this._scan(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        if (this._resetId) GLib.source_remove(this._resetId);
        this._timer = 0; this._resetId = 0;
        for (const it of this._items) {
            try {
                it.disconnect(it._mbyEnter); it.disconnect(it._mbyLeave);
                const icon = this._icon(it); if (icon) { icon.remove_all_transitions(); icon.set_scale(1, 1); }
                delete it._mbyEnter; delete it._mbyLeave;
            } catch (e) {}
        }
        this._items.clear();
        for (const sl of this._clipped) {
            try { for (const [o, id] of sl._mbyClipIds) o.disconnect(id); } catch (e) {}
            delete sl._mbyClipIds;
            try { sl.queue_relayout(); } catch (e) {}      // Dash to Dock puts its clip back
        }
        this._clipped.clear();
    }

    _docks() {
        return Main.layoutManager.uiGroup.get_children().filter(a => a.name === 'dashtodockContainer' && a.dash);
    }

    _icon(item) {                     // the picture inside a dock item
        const btn = item.child;
        return btn && btn.icon && btn.icon.icon ? btn.icon.icon : (btn && btn.icon) || null;
    }

    _scan() {
        for (const dock of this._docks()) {
            const box = dock.dash._box;
            if (!box) continue;
            // let the grown icons draw outside the dock instead of being cut off at the top:
            // every actor from the icon row up to the dock may clip in three ways - clip-to-allocation,
            // an explicit clip rectangle, and (St.Viewport / St.BoxLayout / St.ScrollView) clip-to-view.
            const unclip = a => {
                try { a.clip_to_allocation = false; } catch (e) {}
                try { if (a.has_clip) a.remove_clip(); } catch (e) {}
                try { if ('clip_to_view' in a) a.clip_to_view = false; } catch (e) {}
            };
            for (let a = box; a && a !== dock.get_parent(); a = a.get_parent()) unclip(a);
            // Dash to Dock's slide container clips its child to the dock's own box on every
            // allocation (docking.js: this.child.set_clip(...)) - that is what cut the top off a
            // grown icon. While the dock is fully shown, take that clip off again each time it is set.
            const sl = dock._slider;
            if (sl && sl.child && !sl._mbyClipIds) {
                const child = sl.child;
                const free = () => {
                    const x = sl.slide_x ?? sl.slideX ?? 1;
                    if (child.has_clip && x >= 0.999) child.remove_clip();
                };
                sl._mbyClipIds = [[child, child.connect('notify::has-clip', free)],
                                  [child, child.connect('notify::clip-rect', free)]];
                this._clipped.add(sl);
                free();
            }
            if (dock.dash._scrollView) unclip(dock.dash._scrollView);
            for (const it of box.get_children()) { unclip(it); if (it.child) unclip(it.child); }
            const items = box.get_children();
            if (dock.dash._showAppsIcon) items.push(dock.dash._showAppsIcon);
            for (const it of items) {
                if (this._items.has(it) || !it.child) continue;
                const btn = it.child;
                it._mbyEnter = btn.connect('enter-event', () => this._zoom(dock, it));
                it._mbyLeave = btn.connect('leave-event', () => this._reset(dock));
                this._items.add(it);
                it.connect('destroy', () => this._items.delete(it));
            }
        }
    }

    _row(dock) {
        const row = dock.dash._box.get_children().filter(c => c.visible && c.child);
        if (dock.dash._showAppsIcon) row.push(dock.dash._showAppsIcon);
        return row;
    }

    _set(item, s) {
        const icon = this._icon(item);
        if (!icon) return;
        icon.set_pivot_point(0.5, 1.0);
        icon.ease({ scale_x: s, scale_y: s, duration: TIME, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
    }

    _zoom(dock, hovered) {
        if (this._resetId) { GLib.source_remove(this._resetId); this._resetId = 0; }
        const row = this._row(dock), i = row.indexOf(hovered);
        row.forEach((it, j) => {
            const d = Math.abs(j - i);
            this._set(it, d < SCALES.length ? SCALES[d] : 1.0);
        });
    }

    _reset(dock) {
        // small delay so moving between two icons does not flicker
        if (this._resetId) GLib.source_remove(this._resetId);
        this._resetId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 90, () => {
            this._resetId = 0;
            this._row(dock).forEach(it => this._set(it, 1.0));
            return GLib.SOURCE_REMOVE;
        });
    }
}

function init() { return new Extension(); }
