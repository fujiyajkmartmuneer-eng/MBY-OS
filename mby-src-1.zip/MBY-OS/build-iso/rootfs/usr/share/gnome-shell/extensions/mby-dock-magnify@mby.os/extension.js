/* MBY Dock Zoom - macOS-style magnification for the bottom dock (Dash to Dock).
 * The icon under the mouse grows, its neighbours a little less, with a smooth animation.
 *
 * Dash to Dock draws its icons only inside the dock bar: whatever sticks out above the bar
 * is never painted (tested in the VM with clones and with a separate full-screen layer -
 * both were cut at the bar's top edge). So the zoom is fitted to the bar: for every icon
 * it measures the free room above and below it inside the bar, grows it at most that much,
 * and anchors the growth so it uses the room above first. Nothing is ever cut off, on any
 * dock size or icon size. */
const { GLib, Clutter } = imports.gi;
const Main = imports.ui.main;

const SCALES = [1.6, 1.25, 1.08];   // wished size: hovered, next, next-but-one (capped to fit)
const TIME = 140;                   // ms
const MARGIN = 2;                   // px kept free between a grown icon and the bar's edge

class Extension {
    enable() {
        this._items = new Set();
        this._scan();
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => { this._scan(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        if (this._resetId) GLib.source_remove(this._resetId);
        this._timer = 0; this._resetId = 0;
        for (const it of this._items) {
            try {
                it.child.disconnect(it._mbyEnter); it.child.disconnect(it._mbyLeave);
                const icon = this._icon(it);
                if (icon) { icon.remove_all_transitions(); icon.set_scale(1, 1); }
                delete it._mbyEnter; delete it._mbyLeave;
            } catch (e) {}
        }
        this._items.clear();
    }

    _docks() {
        return Main.layoutManager.uiGroup.get_children().filter(a => a.name === 'dashtodockContainer' && a.dash);
    }

    _icon(item) {                     // the picture inside a dock item
        const btn = item.child;
        return btn && btn.icon && btn.icon.icon ? btn.icon.icon : (btn && btn.icon) || null;
    }

    _scan() {
        for (const dock of this._docks()) {
            const box = dock.dash._box;
            if (!box) continue;
            const items = box.get_children();
            if (dock.dash._showAppsIcon) items.push(dock.dash._showAppsIcon);
            for (const it of items) {
                if (this._items.has(it) || !it.child) continue;
                const btn = it.child;
                it._mbyEnter = btn.connect('enter-event', () => this._zoom(dock, it));
                it._mbyLeave = btn.connect('leave-event', () => this._reset(dock));
                this._items.add(it);
                it.connect('destroy', () => this._items.delete(it));
            }
        }
    }

    _row(dock) {
        const row = dock.dash._box.get_children().filter(c => c.visible && c.child);
        if (dock.dash._showAppsIcon) row.push(dock.dash._showAppsIcon);
        return row;
    }

    // top and bottom of the visible dock bar, in screen pixels
    _bar(dock) {
        const bar = dock.dash._background || dock.dash;
        const [, y] = bar.get_transformed_position();
        const [, h] = bar.get_transformed_size();
        return h > 0 ? [y, y + h] : null;
    }

    // how far `icon` may grow inside the bar, and where to anchor it (0 = top, 1 = bottom)
    _room(icon, bar) {
        // measure the icon at rest: undo its current scale around its current pivot
        const [, y] = icon.get_transformed_position();
        const [, th] = icon.get_transformed_size();
        const s = icon.scale_y || 1, h = th / s;
        const py = icon.pivot_point ? icon.pivot_point.y : 1;
        const top = y + (s - 1) * h * py;      // un-scaled top edge
        const up = Math.max(0, top - bar[0] - MARGIN);
        const down = Math.max(0, bar[1] - (top + h) - MARGIN);
        if (!(h > 0) || up + down <= 0) return { max: 1, pivot: 1 };
        return { max: 1 + (up + down) / h, pivot: up / (up + down) };
    }

    _set(item, s, bar) {
        const icon = this._icon(item);
        if (!icon) return;
        if (s > 1 && bar) {
            const r = this._room(icon, bar);
            s = Math.min(s, r.max);
            icon.set_pivot_point(0.5, r.pivot);
        }
        icon.ease({ scale_x: s, scale_y: s, duration: TIME, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
    }

    _zoom(dock, hovered) {
        if (this._resetId) { GLib.source_remove(this._resetId); this._resetId = 0; }
        const row = this._row(dock), i = row.indexOf(hovered), bar = this._bar(dock);
        row.forEach((it, j) => {
            const d = Math.abs(j - i);
            try { this._set(it, d < SCALES.length ? SCALES[d] : 1.0, bar); } catch (e) { logError(e, 'mby-dock-magnify'); }
        });
    }

    _reset(dock) {
        // small delay so moving between two icons does not flicker
        if (this._resetId) GLib.source_remove(this._resetId);
        this._resetId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 90, () => {
            this._resetId = 0;
            this._row(dock).forEach(it => { try { this._set(it, 1.0, null); } catch (e) {} });
            return GLib.SOURCE_REMOVE;
        });
    }
}

function init() { return new Extension(); }
