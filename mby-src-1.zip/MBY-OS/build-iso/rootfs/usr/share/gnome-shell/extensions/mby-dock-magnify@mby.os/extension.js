/* MBY Dock Zoom - macOS-style magnification for the bottom dock (Dash to Dock).
 * The icon under the mouse grows to 160 %, its neighbours to 125 % and 108 %,
 * growing upwards from the dock, with a smooth animation. */
const { GLib, Clutter } = imports.gi;
const Main = imports.ui.main;

const SCALES = [1.6, 1.25, 1.08];   // hovered, next, next-but-one
const TIME = 140;                   // ms

class Extension {
    enable() {
        this._items = new Set();
        this._scan();
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => { this._scan(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        if (this._resetId) GLib.source_remove(this._resetId);
        this._timer = 0; this._resetId = 0;
        for (const it of this._items) {
            try {
                it.disconnect(it._mbyEnter); it.disconnect(it._mbyLeave);
                const icon = this._icon(it); if (icon) { icon.remove_all_transitions(); icon.set_scale(1, 1); }
                delete it._mbyEnter; delete it._mbyLeave;
            } catch (e) {}
        }
        this._items.clear();
    }

    _docks() {
        return Main.layoutManager.uiGroup.get_children().filter(a => a.name === 'dashtodockContainer' && a.dash);
    }

    _icon(item) {                     // the picture inside a dock item
        const btn = item.child;
        return btn && btn.icon && btn.icon.icon ? btn.icon.icon : (btn && btn.icon) || null;
    }

    _scan() {
        for (const dock of this._docks()) {
            const box = dock.dash._box;
            if (!box) continue;
            // let the grown icons draw outside the dock instead of being cut off
            for (let a = box; a && a !== dock.get_parent(); a = a.get_parent()) a.clip_to_allocation = false;
            if (dock.dash._scrollView) dock.dash._scrollView.clip_to_allocation = false;
            const items = box.get_children();
            if (dock.dash._showAppsIcon) items.push(dock.dash._showAppsIcon);
            for (const it of items) {
                if (this._items.has(it) || !it.child) continue;
                const btn = it.child;
                it._mbyEnter = btn.connect('enter-event', () => this._zoom(dock, it));
                it._mbyLeave = btn.connect('leave-event', () => this._reset(dock));
                this._items.add(it);
                it.connect('destroy', () => this._items.delete(it));
            }
        }
    }

    _row(dock) {
        const row = dock.dash._box.get_children().filter(c => c.visible && c.child);
        if (dock.dash._showAppsIcon) row.push(dock.dash._showAppsIcon);
        return row;
    }

    _set(item, s) {
        const icon = this._icon(item);
        if (!icon) return;
        icon.set_pivot_point(0.5, 1.0);
        icon.ease({ scale_x: s, scale_y: s, duration: TIME, mode: Clutter.AnimationMode.EASE_OUT_QUAD });
    }

    _zoom(dock, hovered) {
        if (this._resetId) { GLib.source_remove(this._resetId); this._resetId = 0; }
        const row = this._row(dock), i = row.indexOf(hovered);
        row.forEach((it, j) => {
            const d = Math.abs(j - i);
            this._set(it, d < SCALES.length ? SCALES[d] : 1.0);
        });
    }

    _reset(dock) {
        // small delay so moving between two icons does not flicker
        if (this._resetId) GLib.source_remove(this._resetId);
        this._resetId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 90, () => {
            this._resetId = 0;
            this._row(dock).forEach(it => this._set(it, 1.0));
            return GLib.SOURCE_REMOVE;
        });
    }
}

function init() { return new Extension(); }
