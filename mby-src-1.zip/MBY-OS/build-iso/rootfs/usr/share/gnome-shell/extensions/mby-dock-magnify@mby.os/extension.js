/* MBY Dock Zoom - macOS-style magnification for the bottom dock (Dash to Dock).
 * The icon under the mouse grows to 160 %, its neighbours to 125 % and 108 %,
 * growing upwards from the dock, with a smooth animation.
 *
 * Dash to Dock clips and offscreen-renders its icon row to the dock's own box, so an icon
 * scaled in place gets its top cut off. Instead, each grown icon is drawn as its own St.Icon
 * on a full-screen overlay layer above the dock (nothing clips it there) while the real icon is
 * made invisible underneath. The stand-ins are not reactive, so the mouse still talks to the
 * real dock buttons (clicks, menus, tooltips, drag and drop are unchanged). */
const { GLib, Clutter, St } = imports.gi;
const Main = imports.ui.main;

const SCALES = [1.6, 1.25, 1.08];   // hovered, next, next-but-one
const TIME = 140;                   // ms

class Extension {
    enable() {
        this._items = new Set();
        this._clones = new Map();     // icon -> clone
        // a full-screen, non-reactive layer: GNOME only repaints the parts of the screen an actor
        // says it covers, so a 0x0 layer (or the dock itself) left the grown icon's top unpainted
        this._layer = new St.Widget({ name: 'mbyDockZoomLayer', reactive: false, x: 0, y: 0 });
        this._layer.add_constraint(new Clutter.BindConstraint({ source: global.stage, coordinate: Clutter.BindCoordinate.SIZE }));
        Main.layoutManager.uiGroup.add_child(this._layer);
        this._scan();
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => { this._scan(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        if (this._resetId) GLib.source_remove(this._resetId);
        this._timer = 0; this._resetId = 0;
        for (const it of this._items) {
            try {
                it.child.disconnect(it._mbyEnter); it.child.disconnect(it._mbyLeave);
                delete it._mbyEnter; delete it._mbyLeave;
            } catch (e) {}
        }
        this._items.clear();
        for (const icon of [...this._clones.keys()]) this._drop(icon);
        this._layer.destroy();
        this._layer = null;
    }

    _docks() {
        return Main.layoutManager.uiGroup.get_children().filter(a => a.name === 'dashtodockContainer' && a.dash);
    }

    _icon(item) {                     // the picture inside a dock item
        const btn = item.child;
        return btn && btn.icon && btn.icon.icon ? btn.icon.icon : (btn && btn.icon) || null;
    }

    _scan() {
        for (const dock of this._docks()) {
            const box = dock.dash._box;
            if (!box) continue;
            // keep the zoom layer just above the dock (below menus and tooltips added later)
            const ui = Main.layoutManager.uiGroup;
            if (this._layer.get_parent() === ui) ui.set_child_above_sibling(this._layer, dock);
            const items = box.get_children();
            if (dock.dash._showAppsIcon) items.push(dock.dash._showAppsIcon);
            for (const it of items) {
                if (this._items.has(it) || !it.child) continue;
                const btn = it.child;
                it._mbyEnter = btn.connect('enter-event', () => this._zoom(dock, it));
                it._mbyLeave = btn.connect('leave-event', () => this._reset(dock));
                this._items.add(it);
                it.connect('destroy', () => this._items.delete(it));
            }
        }
    }

    _row(dock) {
        const row = dock.dash._box.get_children().filter(c => c.visible && c.child);
        if (dock.dash._showAppsIcon) row.push(dock.dash._showAppsIcon);
        return row;
    }

    // the stand-in that shows `icon` grown on the zoom layer. It is a new St.Icon with the same
    // picture, drawn at the largest zoom size (so it stays sharp) and scaled down to fit. It is not
    // a Clutter.Clone: Dash to Dock renders its icon row into an off-screen buffer the size of the
    // dock, and a clone of an icon inside it still ended up cut off at the dock's top edge.
    _clone(icon) {
        const big = SCALES[0];
        let c = this._clones.get(icon);
        const [x, y] = icon.get_transformed_position();
        const [w, h] = icon.get_transformed_size();
        if (!c) {
            if (!(w > 0 && h > 0) || (!icon.gicon && !icon.icon_name)) return null;
            c = new St.Icon({ icon_size: Math.round(Math.max(w, h) * big), reactive: false, style: 'border: 3px solid red;' });
            if (icon.gicon) c.gicon = icon.gicon; else c.icon_name = icon.icon_name;
            c.set_pivot_point(0.5, 1.0);
            c.set_scale(1 / big, 1 / big);
            this._layer.add_child(c);
            this._clones.set(icon, c);
            c._mbyDestroyId = icon.connect('destroy', () => this._drop(icon));
            c.connect('notify::scale-x', () => this._layer && this._layer.queue_redraw());
        }
        if (w > 0 && h > 0) {           // grown size, bottom-centre on the real icon
            c.set_size(Math.round(w * big), Math.round(h * big));
            c.set_position(Math.round(x - (w * big - w) / 2), Math.round(y - (h * big - h)));
        }
        icon.opacity = 0;             // the stand-in draws it instead
        return c;
    }

    _drop(icon) {
        const c = this._clones.get(icon);
        if (!c) return;
        this._clones.delete(icon);
        try { icon.disconnect(c._mbyDestroyId); } catch (e) {}
        try { icon.opacity = 255; } catch (e) {}
        try { c.remove_all_transitions(); c.destroy(); } catch (e) {}
        if (this._layer) this._layer.queue_redraw();
    }

    _set(item, s) {
        const icon = this._icon(item);
        if (!icon) return;
        if (s === 1.0 && !this._clones.has(icon)) return;
        const c = this._clone(icon);
        if (!c) return;
        c.remove_all_transitions();
        c.ease({
            scale_x: s / SCALES[0], scale_y: s / SCALES[0], duration: TIME, mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onComplete: () => { if (s === 1.0 && this._clones.get(icon) === c) this._drop(icon); },
        });
    }

    _zoom(dock, hovered) {
        if (this._resetId) { GLib.source_remove(this._resetId); this._resetId = 0; }
        // the zoom layer always sits on top of the whole shell UI while icons are grown
        const ui = Main.layoutManager.uiGroup;
        if (this._layer.get_parent() === ui) ui.set_child_above_sibling(this._layer, null);
        const row = this._row(dock), i = row.indexOf(hovered);
        row.forEach((it, j) => {
            const d = Math.abs(j - i);
            try { this._set(it, d < SCALES.length ? SCALES[d] : 1.0); } catch (e) { logError(e, 'mby-dock-magnify'); }
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, () => {
            try {
                global.stage.queue_redraw();
                const icon = this._icon(hovered), c = icon && this._clones.get(icon);
                const kids = ui.get_children(), li = kids.indexOf(this._layer);
                const msg = `stand=${!!c} ` + (c ? `tpos=${c.get_transformed_position()} tsize=${c.get_transformed_size()} op=${c.get_paint_opacity()} mapped=${c.mapped} gicon=${!!c.gicon} ` : '') +
                    `layer=${li}/${kids.length} lsize=${this._layer.width}x${this._layer.height} above=${kids.slice(li + 1).map(k => k.name || k.constructor.name).join(',')} ` +
                    `stage=${global.stage.width}x${global.stage.height} top5=${kids.slice(-5).map(k => (k.name || k.constructor.name) + ':' + k.visible).join(',')}`;
                GLib.file_set_contents('/tmp/mby-zoom.txt', msg + '\n');
            } catch (e) { GLib.file_set_contents('/tmp/mby-zoom.txt', 'ERR ' + e + '\n'); }
            return GLib.SOURCE_REMOVE;
        });
    }

    _reset(dock) {
        // small delay so moving between two icons does not flicker
        if (this._resetId) GLib.source_remove(this._resetId);
        this._resetId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 90, () => {
            this._resetId = 0;
            this._row(dock).forEach(it => this._set(it, 1.0));
            return GLib.SOURCE_REMOVE;
        });
    }
}

function init() { return new Extension(); }
