/* MBY Panic Key - one key for privacy: when a customer or a child walks up, press Super+Escape.
   Every window is minimised, notification banners are silenced and the Private Folder is locked.
   Press it again and the same windows come back where they were. */
const { Gio, GLib, Meta, Shell } = imports.gi;
const Main = imports.ui.main;
const ExtensionUtils = imports.misc.extensionUtils;

class Extension {
    enable() {
        this._settings = ExtensionUtils.getSettings();
        this._hidden = null;
        Main.wm.addKeybinding('panic-key', this._settings, Meta.KeyBindingFlags.NONE,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => this._toggle());
    }
    _toggle() {
        const notif = new Gio.Settings({ schema_id: 'org.gnome.desktop.notifications' });
        if (this._hidden === null) {
            const wins = global.get_window_actors().map(a => a.meta_window)
                .filter(w => w && !w.minimized && w.get_window_type() === Meta.WindowType.NORMAL);
            this._banners = notif.get_boolean('show-banners');
            wins.forEach(w => w.minimize());
            this._hidden = wins;
            notif.set_boolean('show-banners', false);
            try { Gio.Subprocess.new(['/usr/local/bin/mby-private', 'lock'], Gio.SubprocessFlags.NONE); } catch (e) {}
            if (Main.overview.visible) Main.overview.hide();
        } else {
            const t = global.get_current_time();
            this._hidden.forEach(w => { try { w.unminimize(); } catch (e) {} });
            if (this._hidden.length) try { this._hidden[this._hidden.length - 1].activate(t); } catch (e) {}
            notif.set_boolean('show-banners', this._banners !== false);
            this._hidden = null;
        }
    }
    disable() {
        Main.wm.removeKeybinding('panic-key');
        if (this._hidden) this._toggle();
        this._settings = null;
    }
}
function init() { return new Extension(); }
