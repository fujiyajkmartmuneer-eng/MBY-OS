/* MBY Brightness - always show a brightness slider in Quick Settings.
 * - Laptop with a backlight: GNOME already shows its own slider, so this
 *   extension stays out of the way.
 * - Desktop monitor with DDC/CI: the monitor's real brightness is changed
 *   (through /usr/local/bin/mby-brightness, which uses ddcutil).
 * - Anything else (VirtualBox, old monitors): the screen is dimmed in software.
 */
const { Gio, GLib, GObject, Clutter } = imports.gi;
const Main = imports.ui.main;
const QuickSettings = imports.ui.quickSettings;

const HELPER = '/usr/local/bin/mby-brightness';

function hasBacklight() {
    try {
        const r = Gio.DBus.session.call_sync('org.gnome.SettingsDaemon.Power',
            '/org/gnome/SettingsDaemon/Power', 'org.freedesktop.DBus.Properties', 'Get',
            new GLib.Variant('(ss)', ['org.gnome.SettingsDaemon.Power.Screen', 'Brightness']),
            null, Gio.DBusCallFlags.NONE, 2000, null);
        return r.deepUnpack()[0].deepUnpack() >= 0;
    } catch (e) {
        return false;
    }
}

function run(args, cb) {
    try {
        const p = Gio.Subprocess.new([HELPER, ...args],
            Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE);
        p.communicate_utf8_async(null, null, (proc, res) => {
            let out = '';
            try { [, out] = proc.communicate_utf8_finish(res); } catch (e) {}
            if (cb) cb((out || '').trim());
        });
    } catch (e) { if (cb) cb(''); }
}

const BrightnessSlider = GObject.registerClass(
class BrightnessSlider extends QuickSettings.QuickSlider {
    _init() {
        super._init({ iconName: 'display-brightness-symbolic' });
        this._mode = 'soft';          // 'ddc' or 'soft'
        this._timer = 0;
        this._effect = null;
        this.slider.accessible_name = 'Brightness';
        this.slider.value = 1.0;
        this._changedId = this.slider.connect('notify::value', () => this._onChanged());
        run(['detect'], out => {
            if (!out.startsWith('ddc')) return;
            this._mode = 'ddc';
            run(['get'], v => {
                const n = parseInt(v);
                if (!isNaN(n)) {
                    this.slider.block_signal_handler(this._changedId);
                    this.slider.value = Math.max(0, Math.min(1, n / 100));
                    this.slider.unblock_signal_handler(this._changedId);
                }
            });
        });
    }

    _onChanged() {
        const v = this.slider.value;
        if (this._mode === 'ddc') {
            // monitors are slow: send only the last value after a short pause
            if (this._timer) GLib.source_remove(this._timer);
            this._timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 250, () => {
                this._timer = 0;
                run(['set', String(Math.round(Math.max(v, 0.05) * 100))]);
                return GLib.SOURCE_REMOVE;
            });
        } else {
            this._soft(v);
        }
    }

    _soft(v) {
        // never go fully black: 20 % brightness is the minimum
        const b = -0.8 * (1 - v);
        if (!this._effect) {
            this._effect = new Clutter.BrightnessContrastEffect();
            Main.layoutManager.uiGroup.add_effect_with_name('mby-brightness', this._effect);
        }
        this._effect.set_brightness_full(b, b, b);
        if (v >= 0.999) this._removeEffect();
    }

    _removeEffect() {
        if (this._effect) {
            Main.layoutManager.uiGroup.remove_effect_by_name('mby-brightness');
            this._effect = null;
        }
    }

    destroy() {
        if (this._timer) GLib.source_remove(this._timer);
        this._removeEffect();
        super.destroy();
    }
});

const Indicator = GObject.registerClass(
class Indicator extends QuickSettings.SystemIndicator {
    _init() {
        super._init();
        this.quickSettingsItems.push(new BrightnessSlider());
        const qs = Main.panel.statusArea.quickSettings;
        qs._addItems(this.quickSettingsItems, 2);
        // put it right under the volume slider
        const grid = qs.menu._grid;
        const item = this.quickSettingsItems[0];
        const vol = qs._volume && qs._volume.quickSettingsItems[0];
        if (vol && grid.get_children().includes(vol))
            grid.set_child_above_sibling(item, vol);
    }
    destroy() {
        this.quickSettingsItems.forEach(i => i.destroy());
        super.destroy();
    }
});

class Extension {
    enable() {
        this._wait = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => {
            this._wait = 0;
            if (!hasBacklight()) this._indicator = new Indicator();
            return GLib.SOURCE_REMOVE;
        });
    }
    disable() {
        if (this._wait) GLib.source_remove(this._wait);
        this._wait = 0;
        if (this._indicator) this._indicator.destroy();
        this._indicator = null;
    }
}

function init() { return new Extension(); }
