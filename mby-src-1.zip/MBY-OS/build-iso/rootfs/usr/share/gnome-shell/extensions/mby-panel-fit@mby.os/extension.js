/* MBY Panel Fit - when the right side of the top bar is too full (items get cut, like "₹…" or "8…"),
 * the least important items are hidden one by one and listed in a small "⋯" menu instead.
 * Clicking an entry in that menu shows the item again for 20 seconds and opens it.
 * Checked when the screen size changes and every few seconds (labels like the rate change width). */
const { St, Clutter, GLib } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

// hidden first -> hidden last
const ORDER = [
    ['mby-radio', 'Radio'],
    ['mby-rate', 'BD → ₹ rate'],
    ['mby-world-clock', 'World clock'],
    ['mby-data-usage', 'Data usage'],
    ['mby-reminders', 'Reminders'],
    ['clipboardIndicator', 'Clipboard'],
];
const SLACK = 8;

class Extension {
    enable() {
        this._hidden = [];
        this._peek = null;
        this._more = new PanelMenu.Button(0.5, 'MBY More');
        this._more.add_child(new St.Label({ text: '⋯', style_class: 'mby-fit-more', y_align: Clutter.ActorAlign.CENTER }));
        this._more.menu.connect('open-state-changed', (m, open) => { if (open) this._fillMenu(); });
        Main.panel.addToStatusArea('mby-panel-fit', this._more, 0, 'right');
        this._more.container.hide();
        this._monId = Main.layoutManager.connect('monitors-changed', () => this._queue());
        this._first = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 3, () => { this._first = 0; this._fit(); return GLib.SOURCE_REMOVE; });
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT_IDLE, 6, () => { this._fit(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        for (const id of [this._first, this._timer, this._idle, this._peekId]) if (id) GLib.source_remove(id);
        this._first = this._timer = this._idle = this._peekId = 0;
        if (this._monId) Main.layoutManager.disconnect(this._monId);
        this._monId = 0;
        for (const [n] of ORDER) Main.panel.statusArea[n]?.container.show();
        this._more?.destroy();
        this._more = null;
    }

    _queue() {
        if (this._idle) return;
        this._idle = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => { this._idle = 0; this._fit(); return GLib.SOURCE_REMOVE; });
    }

    _over() {
        const p = Main.panel, right = p._rightBox, center = p._centerBox;
        const [, cw] = center.get_preferred_width(-1);
        const [, rw] = right.get_preferred_width(-1);
        const room = Math.floor((p.width - cw) / 2) - SLACK;
        return rw > room;
    }

    _fit() {
        if (!this._more || !Main.panel.width || Main.panel.menuManager.activeMenu) return;
        const items = ORDER.filter(([n]) => Main.panel.statusArea[n] && n !== this._peek);
        for (const [n] of items) Main.panel.statusArea[n].container.show();
        this._more.container.hide();
        const hidden = [];
        for (const [n, label] of items) {
            if (!this._over()) break;
            if (!hidden.length) this._more.container.show();
            Main.panel.statusArea[n].container.hide();
            hidden.push([n, label]);
        }
        this._hidden = hidden;
    }

    _fillMenu() {
        const m = this._more.menu;
        m.removeAll();
        if (!this._hidden.length) { const i = new PopupMenu.PopupMenuItem('Everything fits'); i.setSensitive(false); m.addMenuItem(i); return; }
        for (const [n, label] of this._hidden) m.addAction(label, () => this._show(n));
    }

    // show one hidden item for 20 seconds and open its menu
    _show(n) {
        const b = Main.panel.statusArea[n];
        if (!b) return;
        this._peek = n;
        b.container.show();
        if (this._peekId) GLib.source_remove(this._peekId);
        this._peekId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 150, () => {
            b.menu?.open?.();
            this._peekId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 20, () => {
                this._peekId = 0;
                if (b.menu?.isOpen) return GLib.SOURCE_CONTINUE;   // still in use
                this._peek = null;
                this._fit();
                return GLib.SOURCE_REMOVE;
            });
            return GLib.SOURCE_REMOVE;
        });
    }
}

function init() { return new Extension(); }
