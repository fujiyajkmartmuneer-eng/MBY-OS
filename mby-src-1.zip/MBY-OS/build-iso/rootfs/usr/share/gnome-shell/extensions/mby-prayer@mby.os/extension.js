/* MBY Prayer Times - "Asr 14:58" (the next prayer) in the middle of the top bar.
 * Menu: time left, today's five times, city, Adhan sound and Prayer Focus switches,
 * play the adhan, choose your own adhan file, refresh.
 * The times are fetched by mby-prayer-focus (aladhan.com, Gulf method) into ~/.cache/mby-prayer-times.json. */
const { GLib, Gio, St, Clutter } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

const NAMES = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
const CACHE = GLib.build_filenamev([GLib.get_user_cache_dir(), 'mby-prayer-times.json']);
const CONF = GLib.build_filenamev([GLib.get_user_config_dir(), 'mby']);
const FOCUS_OFF = GLib.build_filenamev([GLib.get_user_config_dir(), 'mby-prayer-focus.off']);
const NOSOUND = GLib.build_filenamev([CONF, 'no-adhan-sound']);
const CMD = '/usr/local/bin/mby-prayer-focus';

const run = argv => { try { Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE); } catch (e) { logError(e); } };
const exists = f => GLib.file_test(f, GLib.FileTest.EXISTS);
const pad = n => String(n).padStart(2, '0');

function load() {
    try {
        const [ok, d] = GLib.file_get_contents(CACHE);
        if (ok) return JSON.parse(new TextDecoder().decode(d));
    } catch (e) {}
    return null;
}


// Fixed order in the centre of the top bar, whichever extension loads first:
// clock, Hijri date (mby-calendars), next prayer (mby-prayer).
function mbyOrderCentre() {
    const box = Main.panel._centerBox, sa = Main.panel.statusArea;
    let prev = Main.panel.statusArea.dateMenu ? Main.panel.statusArea.dateMenu.container : null;
    for (const id of ['mby-calendars', 'mby-prayer']) {
        const c = sa[id] && sa[id].container;
        if (!c || c.get_parent() !== box) continue;
        if (prev && prev.get_parent() === box) box.set_child_above_sibling(c, prev);
        prev = c;
    }
}

class Extension {
    enable() {
        this._btn = new PanelMenu.Button(0.5, 'MBY Prayer Times');
        this._label = new St.Label({ text: '🕌', y_align: Clutter.ActorAlign.CENTER });
        this._btn.add_child(this._label);
        this._btn.menu.connect('open-state-changed', (m, open) => { if (open) this._fill(); });
        Main.panel.addToStatusArea('mby-prayer', this._btn, 3, 'center');
        mbyOrderCentre();
        this._asked = 0;
        this._update();
        this._fill();
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 30, () => { this._update(); return GLib.SOURCE_CONTINUE; });
    }

    disable() {
        if (this._timer) GLib.source_remove(this._timer);
        this._timer = 0;
        this._btn?.destroy();
        this._btn = null;
    }

    // next prayer today, or tomorrow's Fajr (today's time is close enough) after Isha
    _next() {
        const c = load();
        const now = GLib.DateTime.new_now_local();
        const today = now.format('%Y-%m-%d');
        if (!c || c.date !== today) {
            if (GLib.get_monotonic_time() - this._asked > 10 * 60 * 1e6) {   // fetch at most every 10 min
                this._asked = GLib.get_monotonic_time();
                run([CMD, 'status']);
            }
        }
        if (!c || !c.times) return null;
        const mins = now.get_hour() * 60 + now.get_minute();
        for (const n of NAMES) {
            const t = c.times[n];
            if (!t) continue;
            const [h, m] = t.split(':').map(Number);
            if (h * 60 + m > mins) return { name: n, time: t, left: h * 60 + m - mins, c };
        }
        const [h, m] = (c.times.Fajr || '05:00').split(':').map(Number);
        return { name: 'Fajr', time: c.times.Fajr, left: 24 * 60 - mins + h * 60 + m, c };
    }

    _update() {
        if (!this._btn) return;
        const n = this._next();
        this._label.text = n ? `🕌 ${n.name} ${n.time}` : '🕌';
        if (this._btn.menu.isOpen) this._fill();
    }

    _fill() {
        const m = this._btn.menu;
        m.removeAll();
        const n = this._next();
        if (!n) {
            const i = new PopupMenu.PopupMenuItem('Prayer times are loading… (needs internet the first time)');
            i.setSensitive(false); m.addMenuItem(i);
        } else {
            const left = n.left >= 60 ? `${Math.floor(n.left / 60)} h ${n.left % 60} min` : `${n.left} min`;
            const head = new PopupMenu.PopupMenuItem(`Next: ${n.name} at ${n.time}  ·  in ${left}`);
            head.setSensitive(false); m.addMenuItem(head);
            m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem(n.c.city ? `Today in ${n.c.city}` : 'Today'));
            for (const p of NAMES) {
                const i = new PopupMenu.PopupMenuItem(`${p.padEnd(8)}  ${n.c.times[p] || '--:--'}`);
                if (p === n.name) i.setOrnament(PopupMenu.Ornament.DOT);
                i.setSensitive(false);
                m.addMenuItem(i);
            }
        }
        m.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const snd = new PopupMenu.PopupSwitchMenuItem('Adhan sound', !exists(NOSOUND));
        snd.connect('toggled', (it, on) => run([CMD, 'sound', on ? 'on' : 'off']));
        m.addMenuItem(snd);
        const foc = new PopupMenu.PopupSwitchMenuItem('Prayer Focus (pause music, quiet 15 min)', !exists(FOCUS_OFF));
        foc.connect('toggled', (it, on) => run([CMD, on ? 'on' : 'off']));
        m.addMenuItem(foc);
        m.addAction('Play the adhan now', () => run([CMD, 'test']));
        m.addAction('Choose my own adhan sound…', () => run(['/usr/local/bin/mby-adhan-pick']));
        m.addAction('Refresh prayer times', () => { run([CMD, 'refresh']); GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 8, () => { this._update(); return GLib.SOURCE_REMOVE; }); });
    }
}

function init() { return new Extension(); }
