/* MBY Private Folder indicator - 🔓 in the top bar while the folder is unlocked. */
const { GLib, Gio, GObject, St, Clutter } = imports.gi;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

const MNT = GLib.build_filenamev([GLib.get_user_runtime_dir(), 'mby-private']);
const TOOL = '/usr/local/bin/mby-private';

function isOpen() {
    try {
        const [ok, data] = GLib.file_get_contents('/proc/self/mountinfo');
        return ok && new TextDecoder().decode(data).split('\n').some(l => l.split(' ')[4] === MNT);
    } catch (e) { return false; }
}

function run(arg) {
    try { Gio.Subprocess.new([TOOL, arg], Gio.SubprocessFlags.NONE); } catch (e) { logError(e); }
}

const Indicator = GObject.registerClass(
class Indicator extends PanelMenu.Button {
    _init() {
        super._init(0.5, 'Private Folder');
        const box = new St.BoxLayout({ style_class: 'panel-status-menu-box' });
        box.add_child(new St.Icon({ icon_name: 'changes-allow-symbolic', style_class: 'system-status-icon' }));
        box.add_child(new St.Label({ text: 'Private', y_align: Clutter.ActorAlign.CENTER, style: 'margin-left: 3px; font-size: 0.9em;' }));
        this.add_child(box);
        const title = new PopupMenu.PopupMenuItem('🔓 Private Folder is unlocked', { reactive: false });
        this.menu.addMenuItem(title);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        const open = new PopupMenu.PopupMenuItem('📂 Open Private Folder');
        open.connect('activate', () => run('open'));
        this.menu.addMenuItem(open);
        const lock = new PopupMenu.PopupMenuItem('🔒 Lock now');
        lock.connect('activate', () => run('lock'));
        this.menu.addMenuItem(lock);
    }
});

class Extension {
    enable() {
        this._button = new Indicator();
        Main.panel.addToStatusArea('mby-private-indicator', this._button, 0, 'right');
        this._update();
        this._monitor = Gio.UnixMountMonitor.get();
        this._monId = this._monitor.connect('mounts-changed', () => this._update());
        // FUSE mounts are not always announced: also check every few seconds
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 3, () => { this._update(); return GLib.SOURCE_CONTINUE; });
    }
    _update() {
        if (this._button) this._button.visible = isOpen();
    }
    disable() {
        if (this._monId) this._monitor.disconnect(this._monId);
        if (this._timer) GLib.source_remove(this._timer);
        this._monId = 0; this._timer = 0;
        if (this._button) this._button.destroy();
        this._button = null;
    }
}

function init() { return new Extension(); }
